﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Quartz;
using BigBlue2.Web.Mailers;
using BigBlue2.Data;
using Mvc.Mailer;
using System.Net;
using System.Configuration;

namespace BigBlue2.Web.ScheduledJobs
{
    public class DoNotFinalizeProjectsEmail : IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            using (var client = new WebClient())
            {
                client.Headers.Add(HttpRequestHeader.Authorization, String.Format("Basic {0}",
                    ConfigurationManager.AppSettings["WebApiAuthorizationToken"]));

                client.DownloadData(ConfigurationManager.AppSettings["WebApiUrl"] + "email/DoNotFinalizeProjectsEmail");
            }
        }
    }
}