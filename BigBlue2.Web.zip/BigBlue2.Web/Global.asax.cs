﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Castle.Windsor;
using BigBlue2.Web.Infrastructure;
using Castle.MicroKernel.Registration;
using BigBlue2.Data;
using BigBlue2.Services.Account;
using BigBlue2.Data.Queries;
using BigBlue2.Services.Email;
using System.Web.Http;
using BigBlue2.Web.App_Start;
using Quartz;
using Quartz.Impl;
using BigBlue2.Web.ScheduledJobs;
using System.Web.Security;

namespace BigBlue2.Web
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }

        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                "Default", // Route name
                "{controller}/{action}/{id}", // URL with parameters
                new { controller = "Home", action = "Index", id = UrlParameter.Optional } // Parameter defaults
            );

        }

        protected void Application_Start()
        {
            WebApiConfig.Register(GlobalConfiguration.Configuration);

            AreaRegistration.RegisterAllAreas();

            RegisterGlobalFilters(GlobalFilters.Filters);
            RegisterRoutes(RouteTable.Routes);

            
            var container = new WindsorContainer();

            container.Register(AllTypes.FromThisAssembly().BasedOn<Controller>().LifestyleTransient());
            container.Register(AllTypes.FromThisAssembly().BasedOn<ApiController>().LifestyleTransient());
            container.Register(Component.For<BigBlueEntities>().LifestylePerWebRequest());
            container.Register(Component.For<SmtpBoyEntities>().LifestylePerWebRequest());

            container.Register(AllTypes.FromThisAssembly().InNamespace("BigBlue2.Web.Mailers").WithServiceAllInterfaces().LifestyleTransient());

            container.Register(AllTypes.FromAssemblyNamed("BigBlue2.Services").Pick().WithServiceAllInterfaces()
                .LifestyleTransient());

            container.Register(Component.For<IProjectSummariesByEmployee>().ImplementedBy<ProjectSummariesByEmployee>().LifestyleTransient());

            container.Register(Component.For<IMembershipService>().ImplementedBy<BigBlueMembershipService>());
            container.Register(Component.For<IRoleService>().ImplementedBy<BigBlueRoleService>());
            container.Register(Component.For<IUrlService>().ImplementedBy<UrlService>());
            container.Register(Component.For<IEmployeeUrl>().ImplementedBy<UrlService>().Named("EmployeeUrl"));

            container.Kernel.ReleasePolicy = new Castle.MicroKernel.Releasers.NoTrackingReleasePolicy();

            var dependencyResolver = new WindsorDependencyResolver(container);

            DependencyResolver.SetResolver(dependencyResolver);

            GlobalConfiguration.Configuration.DependencyResolver = dependencyResolver;

            //ConfigureQuartzScheduling();
             
        }

        private void ConfigureQuartzScheduling()
        {
            ISchedulerFactory schedFactory = new StdSchedulerFactory();
            IScheduler scheduler = schedFactory.GetScheduler();

            scheduler.Start();

            IJobDetail doNotFinalizeJob = JobBuilder.Create().WithIdentity("DoNotFinalizeProjectsEmail")
                .OfType<DoNotFinalizeProjectsEmail>().Build();

            ITrigger doNotFinalizeTrigger = TriggerBuilder.Create().StartAt(DateBuilder.TodayAt(8, 0, 0))
                .WithSimpleSchedule(x => x.WithIntervalInHours(24).RepeatForever()).Build();

            scheduler.ScheduleJob(doNotFinalizeJob, doNotFinalizeTrigger);
        }

        void Session_Start(object sender, EventArgs e)
        {
            //CreateUser 
            //User.Identity.Name

            //Membership.GetUser(
            //    Membership.CreateUser(input.Username, input.Password);

        }
    }
}