﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Services.Account;
using BigBlue2.Data;
using BigBlue2.Web.Models.SafetyAudits;
using System.Diagnostics.Contracts;
using System.Data.Entity.Validation;
using BigBlue2.Services.Email;
using System.Web.Security;
using BigBlue2.Services;
using BigBlue2.Web.Models;
using BigBlue2.Services.Config;
using BigBlue2.Web.Models.Projects;

namespace BigBlue2.Web.Controllers
{
    [Authorize(Roles = "SafetyAudits")]
    public class SafetyAuditsController : Controller
    {
        private readonly BigBlueEntities _entities;
        private readonly IMembershipService _membershipService;
        private readonly SafetyAuditMessageFactory _messageFactory;
        private readonly IEmailer _emailer;
        public readonly ISafetyAuditEmailConfig _emailConfig;

        public SafetyAuditsController(BigBlueEntities entities, IMembershipService membershipService, 
            SafetyAuditMessageFactory messageFactory, IEmailer emailer, ISafetyAuditEmailConfig emailConfig)
        {
            _entities = entities;
            _membershipService = membershipService;
            _messageFactory = messageFactory;
            _emailer = emailer;
            _emailConfig = emailConfig;
        }

        [HttpGet]
        public ActionResult Index(Guid? employeeId, Guid? customerId, string user, DateTime? startDate, DateTime? endDate,
            string sort = "DateOfAudit", string sortDir = "DESC", int pageSize = 25)
        {
            var audits = _entities.SafetyAudits as IQueryable<SafetyAudit>;

            if (Request.IsAjaxRequest())
            {
                if (employeeId.HasValue)
                {
                    audits = audits.Where(a => a.EmployeeId == employeeId.Value);
                }

                if (customerId.HasValue)
                {
                    audits = audits.Where(a => a.Project.CustomerId == customerId.Value);
                }

                if (!String.IsNullOrWhiteSpace(user))
                {
                    audits = audits.Where(a => a.CreatedBy == user);
                }

                if (startDate.HasValue)
                {
                    audits = audits.Where(a => a.DateTime >= startDate.Value);
                }

                if (endDate.HasValue)
                {
                    endDate = endDate.Value.EndOfDay();
                    audits = audits.Where(a => a.DateTime <= endDate.Value);
                }

                if (!endDate.HasValue && !startDate.HasValue)
                {
                    startDate = getDefaultStartDate();
                    endDate = DateTime.Now.AddYears(50); // some data has been future data (incorrectly) so this handles this for now
                }

                var gridItems = from a in audits.AsEnumerable()
                                select new GridItem(a);

                var model = new GridModel<GridItem>(gridItems, pageSize, sort, sortDir);

                return PartialView("Grid", model);
            }
            else
            {

                var employees = _entities.SafetyAudits.Select(a => a.Employee).Distinct()
                    .OrderBy(e => e.Contact.LastName).ThenBy(e => e.Contact.FirstName);

                var customers = _entities.SafetyAudits.Select(e => e.Project.Customer).Distinct().OrderBy(c => c.Name);

                var users = _entities.SafetyAudits.OrderBy(a => a.CreatedBy).Select(a => a.CreatedBy).Distinct();

                startDate = getDefaultStartDate();
                endDate = DateTime.Now.AddYears(50); // some data has been future data (incorrectly) so this handles this for now

                audits = audits.Where(a => a.DateCreated >= startDate);

                var model = new IndexModel(audits.OrderByDescending(a => a.DateTime), employees, customers, users, pageSize, sort, 
                    sortDir);

                return View(model);
            }
        }

        private DateTime getDefaultStartDate()
        {
            return DateTime.Now.AddDays(-30);
        }
      
        [HttpGet]
        public ActionResult Create(Guid? employeeId, string projectNo)
        {
            var employees = _entities.EmployeeSummaries.Active();

            if (employeeId.HasValue && !String.IsNullOrWhiteSpace(projectNo))
            {
                var projects = _entities.EmployeeToProjects.ProjectsByEmployee(employeeId.Value);
                var project = _entities.ProjectSummaries.SingleOrDefault(p => p.ProjectNo == projectNo);

                return View(new CreateModel(employees, projects, project));
            }
            else
            {
                return View(new CreateModel(employees));
            }
        }

        [HttpPost]
        public ActionResult Create()
        {
            var audit = _entities.SafetyAudits.Create();
            audit.CreatedBy = User.Identity.Name;

            TryUpdateModel(audit);

            if (ModelState.IsValid)
            {
                _entities.SafetyAudits.Add(audit);
                _entities.SaveChanges();

                if (_emailConfig.SendEmail)
                {
                    _emailer.Send(_messageFactory.BuildMessage(audit));
                }

                return RedirectToAction("Index");
            }

            return Create(audit.EmployeeId, audit.ProjectNo);
        }

        [HttpPost]
        public ActionResult ProjectInfo(string projectNo)
        {
            var project = _entities.ProjectSummaries.SingleOrDefault(p => p.ProjectNo == projectNo);

            Contract.Requires(project != null);

            var model = new ProjectInfoModel();

            if (project != null)
            {
                model.Barge = project.BargeName;
                model.Facility = project.Facility;
                model.Operation = project.Operation;
            }

            return PartialView(model);
        }
    }
}
