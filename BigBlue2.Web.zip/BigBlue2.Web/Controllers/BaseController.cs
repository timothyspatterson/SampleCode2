﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using System.Web.Security;
using BigBlue2.Web.Models.Admin;

namespace BigBlue2.Web.Controllers
{
    public class BaseController : Controller
    {

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            // check for new policies
            // enforce once per session however to reduce calls to db
            /*
            if (Session["PolicyCheck"] != null && Convert.ToBoolean(Session["PolicyCheck"]))
            {

            }
            */
            base.OnActionExecuting(filterContext);
        }


    }

    public class PolicyCheck : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext.HttpContext.Session["PolicyCheck"] == null)
            {
                var entities = new BigBlue2.Data.BigBlueEntities();
                string username = filterContext.HttpContext.User.Identity.Name;
                if (username == "cody2") username = "bforet";
                var eobj = entities.Employees.GetByUserName(username);
                if (eobj != null && eobj.EmployeeRequirePolicy(1)) filterContext.Result = new RedirectResult("Policy/ANTS");
                /*
                if (eobj.EmployeeRequirePolicy(1)) filterContext.Result = new RedirectResult("Policy/ANTS");
                // todo:  check to see if need to sign policy
                if (filterContext.HttpContext.User.Identity.Name == "bforet" || filterContext.HttpContext.User.Identity.Name == "cody2")
                {
                    var entities = new BigBlue2.Data.BigBlueEntities();
                    string username = filterContext.HttpContext.User.Identity.Name;
                    if (username == "cody2") username = "bforet";
                    var eobj = entities.Employees.GetByUserName(username);

                    if (eobj.EmployeeRequirePolicy(1)) filterContext.Result = new RedirectResult("Policy/ANTS");
                }
                */
            }
            base.OnActionExecuting(filterContext);
        }
    }



}