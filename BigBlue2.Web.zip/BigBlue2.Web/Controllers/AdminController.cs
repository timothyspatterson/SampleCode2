﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using System.Web.Security;
using BigBlue2.Web.Models.Admin;
using System.Collections.Specialized;
using System.Net;
using System.Text;

namespace BigBlue2.Web.Controllers
{
    [Authorize(Roles = "Administrator")]
    public class AdminController : Controller
    {
        private readonly BigBlueEntities _entities;
        private readonly SmtpBoyEntities _smtpentities;

        public AdminController(BigBlueEntities entities)
        {
            _entities = entities;
        }

        public ActionResult ChangePassword(string userName)
        {
            ViewBag.UserName = userName;
            return View();
        }

        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordInput input)
        {
            if (ModelState.IsValid)
            {
                bool ischanged = false;
                var mu = Membership.GetUser(input.UserName);
                if (input.AdminReset) ischanged = mu.ChangePassword(mu.ResetPassword(), input.NewPassword);
                else ischanged = mu.ChangePassword(input.CurrentPassword, input.NewPassword);

                if (ischanged)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("CurrentPassword", "Current password is incorrect.");
                }
            }

            return ChangePassword(input.UserName);
        }

        public ActionResult CreateUser()
        {
            var employees = _entities.Employees.Active().Where(e => String.IsNullOrEmpty(e.UserName));

            var model = new CreateUserModel(employees);

            return View(model);
        }

        [HttpPost]
        public ActionResult CreateUser(CreateUserInput input)
        {
            if (ModelState.IsValid)
            {
                if (Membership.GetUser(input.Username) != null)
                {
                    ModelState.AddModelError("Username", "Username is already taken.");
                }
                else
                {
                    Membership.CreateUser(input.Username, input.Password);

                    var employee = _entities.Employees.Find(input.EmployeeId);
                    employee.UserName = input.Username;

                    _entities.SaveChanges();

                    return RedirectToAction("Index");
                }
            }

            return CreateUser();
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Edit(string user)
        {
            var employee = _entities.Employees.SingleOrDefault(e => e.UserName == user);

            var model = new EditModel(Membership.GetUser(user), employee, Roles.GetRolesForUser(user), Roles.GetAllRoles());

            return View(model);
        }

        [HttpPost]
        public ActionResult Edit(string userName, string emailAddress, bool isApproved, string[] roles)
        {
            // remove all roles
            if (System.Web.Security.Roles.GetRolesForUser(userName).Count() > 0)
            {

                System.Web.Security.Roles.RemoveUserFromRoles(userName,
                    System.Web.Security.Roles.GetRolesForUser(userName));
            }

            // only add the ones checked back in
            System.Web.Security.Roles.AddUserToRoles(userName, roles);

            // update other user data
            var u = System.Web.Security.Membership.GetUser(userName);
            u.IsApproved = isApproved;
            u.Email = emailAddress;
            System.Web.Security.Membership.UpdateUser(u);

            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Delete(string userName)
        {
            var employee = _entities.Employees.SingleOrDefault(e => e.UserName == userName);

            if (employee != null)
            {
                employee.UserName = null;
                _entities.SaveChanges();
            }

            Membership.DeleteUser(userName);

            return RedirectToAction("Index");
        }

        

    }
}
