﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using BigBlue2.Services.Payroll;
using BigBlue2.Web.Models.Payroll;

namespace BigBlue2.Web.Controllers
{
    [Authorize]
    public class PayrollController : Controller
    {
        private readonly BigBlueEntities _entities;

        public PayrollController(BigBlueEntities entities)
        {
            _entities = entities;
        }

        [HttpGet]
        public ActionResult Employee()
        {
            var employee = _entities.Employees.GetByUserName(User.Identity.Name);

            if (employee == null)
            {
                return RedirectToAction("Index", "Home");
            }

            var firstPosting = _entities.LaborPostings.Where(l => l.EmployeeId == employee.Id).Min(l => l.ArrivalDate);

            int weeks = (int)DateTime.Now.Subtract(firstPosting).TotalDays / 7;

            var workWeeks = new WorkWeekGenerator().Generate(DayOfWeek.Monday, weeks);

            BigBlue2.Services.Payroll.PayrollEngine pe = new PayrollEngine();
            DateTime pay_dt = pe.getPayDate(System.DateTime.Now, "DOESNTMATTER");

            var model = new EmployeeModel(pay_dt, employee.Id, workWeeks);
            return View(model);
        }

        [HttpPost]
        public ActionResult LaborPostingsGrid(DateTime startDate)
        {
            var employee = _entities.Employees.GetByUserName(User.Identity.Name);

            DateTime endDate = startDate.AddDays(7);

            BigBlue2.Services.Payroll.PayrollEngine pe = new PayrollEngine();
            DateTime pay_dt = pe.getPayDate(startDate, "DOESNTMATTER");

            EmployeeModel em = new EmployeeModel();

            return PartialView(em.getPayDetails(employee.Id, pay_dt));
        }
    }
}