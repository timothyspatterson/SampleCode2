﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using System.Diagnostics.Contracts;
using BigBlue2.Data.Queries;
using BigBlue2.Web.Models.Projects;
using BigBlue2.Services.Projects;

namespace BigBlue2.Web.Controllers
{
    [Authorize]
    public class ProjectsController : Controller
    {
        private readonly BigBlueEntities _entities;
        private readonly IProjectSummariesByEmployee _projectSummariesByEmployee;

        public ProjectsController(BigBlueEntities entities, IProjectSummariesByEmployee projectSummariesByEmployee)
        {
            _entities = entities;
            _projectSummariesByEmployee = projectSummariesByEmployee;
        }

        [HttpPost]
        public ActionResult DropDownListByEmployee(Guid employeeId, DateTime? startdt)
        {
            if (!startdt.HasValue) startdt = new DateTime(1990, 1, 1);  // if no date is ch
            var projects = _projectSummariesByEmployee.Query(employeeId, startdt.Value).OrderByDescending(p => p.EstimatedStartDate);

            var selectList = new SelectList(projects, "ProjectNo", "DisplayName");

            return PartialView("DropDownList", selectList);
        }

        [HttpGet]
        [Authorize(Roles = "BigBoard")]
        public ActionResult Pending()
        {
            var model = new PendingModel();

            DateTime startDate = DateTime.Now.Subtract(new TimeSpan(7, 0, 0, 0));

            //New code. (MAS) Basicly replaced the project with the view. Brandon wanted the BB view of pending projects to match up.
            model.Projects = _entities.ProjectSummaries.Where(q1 => q1.ProjectStatus == 100).GroupBy(q1 => q1.ProjectLocationName);

            //Pervious code. 
            //model.Projects = _entities.Projects.Where(p => p.StatusId == ProjectStatusId.Pending && 
            //                        p.IsActive.HasValue && p.IsActive.Value && 
            //                        p.CanDisplay.HasValue && p.CanDisplay.Value)
            //                        .GroupBy(p => p.ProjectLocation.Name);

            model.Total = model.Projects.SelectMany(p => p).Count();

            var totalsByGroup = new Dictionary<string, int>();

            foreach (var group in model.Projects)
            {
                totalsByGroup.Add(group.Key, group.Count());
            }

            model.TotalsByGroup = totalsByGroup;

            return View(model);
        }

        [HttpPost]
        public ActionResult ProjectInfo(string projectNo)
        {
            var project = _entities.ProjectSummaries.SingleOrDefault(p => p.ProjectNo == projectNo);

            Contract.Requires(project != null);

            var model = new ProjectInfoModel();

            if (project != null)
            {
                model.Barge = project.BargeName;
                model.Facility = project.Facility;
                model.Operation = project.Operation;
            }

            return PartialView(model);
        }
    }
}
