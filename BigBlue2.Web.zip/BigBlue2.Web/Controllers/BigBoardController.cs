﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Web.Models.BigBoard;
using BigBlue2.Data;

namespace BigBlue2.Web.Controllers
{
    [Authorize]
    [Authorize(Roles = "BigBoard, BBWA_ShiftSupervisor")]
    public class BigBoardController : Controller
    {
 
        public BigBoardController()
        {
           
        }

        [HttpPost]
        public ActionResult Grid(string tankermanGroup)
        {
            List<BigBoardLive> itemlist = null;
            using (BigBlueEntities ent = new BigBlueEntities())
            {
                string username = User.Identity.Name;
                var emprowid = ent.Employees.Where(e => e.UserName == username).Select(x => x.Id);
                
                IGrouping<string, BigBoardLive> items = ent.BigBoardLives
                    .Where(i => i.TankermanGroup == tankermanGroup).OrderBy(i => i.EmployeeSchedule)
                    .GroupBy(i => i.TankermanGroup).First();

                itemlist = items.ToList();
            }


            //ViewBag.TankermanGroup = tankermanGroup;
            return PartialView(itemlist);
        }

        public ActionResult Index()
        {
            var model = new IndexModel();

            using (BigBlueEntities ent = new BigBlueEntities())
            {
                
                if (!User.IsInRole("BigBoard"))
                {
                    string username = User.Identity.Name;
                    Guid emprowid = new Guid(ent.Employees.Where(e => e.UserName == username).Select(x => x.Id).First().ToString());
                    //Guid emprowid = new Guid("5D6772B3-0E90-4A0C-AA53-11FAA94B9827");
                    List<Guid> list = ent.Supervisors.Where(x => x.employee_row_id == emprowid).Select(x => x.schedule_row_id).ToList();
                    model.BigBoardLiveData = ent.BigBoardLives.Where(x=>x.EmployeeScheduleId.HasValue && list.Contains(x.EmployeeScheduleId.Value))
                        .GroupBy(b => b.TankermanGroup).OrderBy(g => g.Key).ToList();
                }
                else
                {
                    model.BigBoardLiveData = ent.BigBoardLives
                        .GroupBy(b => b.TankermanGroup).OrderBy(g => g.Key).ToList();
                }
                model.TotalJobsWorking = ent.BigBoardLives.Where(x => !String.IsNullOrEmpty(x.ProjectNo))
                    .Select(x => x.ProjectNo).Distinct().Count();

                var totals = new Dictionary<string, int>();

                foreach (var group in model.BigBoardLiveData)
                {
                    totals.Add(group.Key, group.Where(x => !String.IsNullOrEmpty(x.ProjectNo))
                                                            .Select(x => x.ProjectNo).Distinct().Count());
                }

                model.TotalJobWorkingByGroup = totals;
            }
            return View(model);
        }

    }
}
