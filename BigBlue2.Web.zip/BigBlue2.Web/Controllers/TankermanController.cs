﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using System.Web.Security;
using BigBlue2.Web.Models.Tankerman;
using BigBlue2.Services.Email;
using BigBlue2.Web.Models;
using BigBlue2.Web.Mailers;
using Mvc.Mailer;

namespace BigBlue2.Web.Controllers
{
    [Authorize(Roles = "Tankerman")]
    public class TankermanController : Controller
    {
        private readonly BigBlueEntities _entities;
        private readonly IEmailer _emailer;
        private readonly NewTransitionQueueItemMessageFactory _messageFactory;
        private readonly ITransitionQueueMailer _transitionQueueMailer;

        public TankermanController(BigBlueEntities entities, IEmailer emailer,
            NewTransitionQueueItemMessageFactory messageFactory, ITransitionQueueMailer transitionQueueMailer)
        {
            _entities = entities;
            _emailer = emailer;
            _messageFactory = messageFactory;
            _transitionQueueMailer = transitionQueueMailer;
        }

        [HttpPost]
        public ActionResult AddDelay(AddDelayInput input)
        {
            var model = new ValidatedPartialViewModel();

            model.IsValid = false;

            if (ModelState.IsValid)
            {
                var delayRowModel = new DelayRowModel()
                {
                    DelayTypeId = input.DelayTypeId,
                    Description = input.DelayDescription,
                    StartTime = input.DelayStartDate.Value.Date.Add(input.DelayStartTime.Value.TimeOfDay),
                    EndTime = input.DelayEndDate.Value.Date.Add(input.DelayEndTime.Value.TimeOfDay)
                };

                if (String.IsNullOrEmpty(delayRowModel.Description))
                {
                    delayRowModel.Description = _entities.DelayTypes.Find(delayRowModel.DelayTypeId).Name;
                }

                model.IsValid = true;

                model.Html = ControllerContext.RenderPartialAsString("DelayRow", delayRowModel);
            }
            else
            {
                model.Html = ControllerContext.RenderPartialAsString("AddDelay",
                    new SelectList(_entities.DelayTypes.Active(), "Id", "Name"));
            }

            return Json(model);
        }

        [HttpPost]
        public ActionResult ConfirmBarge(string projectNo, Guid bargeId)
        {
            var userName = Membership.GetUser().UserName;
            var employee = _entities.Employees.SingleOrDefault(e => e.UserName == userName);

            if (employee == null)
            {
                return RedirectToAction("Index", "Home");
            }

            var entry = new TransitionQueueEntry();

            entry.EmployeeId = employee.Id;
            entry.ProjectNo = projectNo;
            entry.PrimaryBargeId = bargeId;
            entry.DateSubmitted = DateTime.Now;

            var project = _entities.Projects.Single(p => p.No == projectNo);
            var barge = _entities.Barges.Single(b => b.Id == bargeId);

            _emailer.Send(_messageFactory.BuildMessage(employee, project, barge));

            var alert = new TransitionQueueAlert();

            alert.CreatedBy = User.Identity.Name;
            alert.DatedCreated = DateTime.Now;
            alert.InitialAlertTime = DateTime.Now;
            alert.TransitionQueueEntry = entry;
            _entities.Alerts.Add(alert);

            _entities.TransitionQueueEntries.Add(entry);
            _entities.SaveChanges();

            return RedirectToAction("Status");
        }

        [HttpGet]
        public ActionResult EnterTimes(string projectNo, IEnumerable<TransitionQueueDelayEntry> delays)
        {
            var project = _entities.Projects.SingleOrDefault(p => p.No == projectNo);

            if (project == null)
            {
                return RedirectToAction("Status");
            }

            var employee = _entities.Employees.GetByUserName(User.Identity.Name);
            var chart = _entities.PortToMileageCharts.GetChartFor(project.PortId.Value, employee);
            decimal mileage = 0;

            if (chart != null)
            {
                mileage = chart.MileageDollarAmount;
            }

            var model = new EnterTimesModel(project, _entities.DelayTypes.Active(), mileage);

            if (delays != null)
            {
                model.Delays = delays;
            }

            return View(model);
        }

        [HttpPost]
        public ActionResult EnterTimes(EnterTimesInput input)
        {
            if (ModelState.IsValid)
            {
                var userName = User.Identity.Name;
                var employee = _entities.Employees.Single(e => e.UserName == userName);

                var entry = _entities.TransitionQueueEntries.Create();

                entry.ProjectNo = input.ProjectNo;
                entry.EmployeeId = employee.Id;
                entry.DateSubmitted = DateTime.Now;

                entry.ArrivedDate = input.Arrive;
                entry.BargeReleasedDate = input.BargeReleased;
                entry.ConnectDate = input.Connect;
                entry.ConnectVaporDate = input.ConnectVapor;
                entry.ConnectXOverDate = input.ConnectXOver;
                entry.DisconnectDate = input.Disconnect;
                entry.DisconnectVaporDate = input.DisconnectVapor;
                entry.DisconnectXOverDate = input.DisconnectXOver;
                entry.DockDate = input.Dock;
                entry.FinishTransferDate = input.FinishTransfer;
                entry.StartTransferDate = input.StartTransfer;

                entry.DraftsClosedBP = input.DraftsClosedBP;
                entry.DraftsClosedBS = input.DraftsClosedBS;
                entry.DraftsClosedSP = input.DraftsClosedSP;
                entry.DraftsClosedSS = input.DraftsClosedSS;
                entry.DraftsOpenedBP = input.DraftsOpenedBP;
                entry.DraftsOpenedBS = input.DraftsOpenedBS;
                entry.DraftsOpenedSP = input.DraftsOpenedSP;
                entry.DraftsOpenedSS = input.DraftsOpenedSS;

                entry.COI = input.COI;
                entry.CFR = input.CFR;
                entry.Pipe = input.Pipe;
                entry.Vapor = input.Vapor;
                entry.XOver = input.XOver;
                entry.FuelLevel = input.FuelLevel;
                entry.OilLevel = input.OilLevel;
                entry.RPM = input.RPM;
                entry.OilPressure = input.OilPressure;
                entry.DischargePressure = input.DischargePressure;
                entry.Temp = input.Temp;

                entry.TankermanArrived = input.TankermanArrive;
                entry.TankermanDeparted = input.TankermanDepart;

                entry.Comments = input.Comments;

                var alert = _entities.Alerts.Create<TransitionQueueAlert>();

                alert.CreatedBy = User.Identity.Name;
                alert.DatedCreated = DateTime.Now;
                alert.InitialAlertTime = DateTime.Now;
                alert.TransitionQueueEntry = entry;

                _entities.TransitionQueueEntries.Add(entry);
                _entities.Alerts.Add(alert);
                _entities.SaveChanges();

                foreach (var delay in input.Delays)
                {
                    delay.TransitionQueueEntryId = entry.Id;
                    _entities.TransitionQueueDelayEntries.Add(delay);
                }

                _entities.SaveChanges();
                MvcMailerSmtpExtension ext = new MvcMailerSmtpExtension(new SmtpBoyEntities());
                _transitionQueueMailer.TransitionQueueEntrySubmitted(entry).Send(ext);

                return RedirectToAction("Status");
            }

            return EnterTimes(input.ProjectNo, input.Delays);
        }

        [HttpGet]
        public ActionResult Schedule()
        {
            return View();
        }

        [HttpPost]
        public ActionResult GetSchedule()
        {
            var employee = _entities.Employees.SingleOrDefault(e => e.UserName == User.Identity.Name);

            var schedule = _entities.Schedules.OrderByDescending(s => s.DateUpdated).First(s => s.IsActive.HasValue &&
                s.IsActive.Value && s.Id == employee.ScheduleId);

            return Json(schedule.ScheduleDefinition);
        }

        //
        // GET: /Employees/
        [HttpGet]
        public ActionResult Status()
        {
            var userName = Membership.GetUser().UserName;

            if (userName == "cody2")
            {
                userName = "AHayner";
            }

            var employee = _entities.Employees.SingleOrDefault(e => e.UserName == userName);

            if (employee == null)
            {
                return RedirectToAction("Index", "Home");
            }

            var bigBoard = _entities.BigBoardLives.SingleOrDefault(b => b.EmployeeId == employee.Id);

            var model = new StatusModel();

            model.EmployeeRowId = employee.Id;
            model.EmployeeName = employee.FullName;
            if (bigBoard != null)
            {
                if (String.IsNullOrEmpty(bigBoard.ProjectNo))
                {
                    model.AssignedToProject = false;
                    model.RotationNo = bigBoard.RotationNo;

                    if (bigBoard.RotationNo == "800")
                    {
                        model.StatusMessage = "You are not currently assigned to a project. You are off.";
                    }
                    else
                    {
                        model.StatusMessage = String.Format("You are not currently assigned to a project. You are #{0} in the rotation.",
                            bigBoard.RotationNo);
                    }
                }
                else
                {
                    var project = _entities.Projects.Single(p => p.No == bigBoard.ProjectNo);

                    var ldDetail = project.ProjectWorkOrders.First().LDDetails.First();

                    var bargeIds = ldDetail.Barges.Select(b => b.Id).ToArray();

                    var projectdispatches = employee.EmployeeToProjects.Where(p => p.ProjectNo == bigBoard.ProjectNo);

                    model.StatusMessage = String.Format("You are currently assigned to {0}", project.ProjectName);

                    var notifications = _entities.Notifications.OfType<ProjectNotification>().Where(n =>
                            n.IsActive &&
                            (n.BargeId.HasValue && bargeIds.Contains(n.BargeId.Value)) ||
                            (n.BoatId.HasValue && n.BoatId.Value == project.BoatId) ||
                            (n.CustomerId.HasValue && n.CustomerId.Value == project.CustomerId) ||
                            (n.LocationId.HasValue && n.LocationId.Value == project.LocationId) ||
                            (n.PortId.HasValue && n.PortId.Value == project.PortId) ||
                            (n.ProjectLocationId.HasValue && n.ProjectLocationId == project.ProjectLocationId.Value));

                    model.Notifications = notifications;

                    model.Boat = project.Boat.Name;
                    model.Location = project.Location.Name;
                    model.MaxDraft = ldDetail.MaxDraft;
                    model.Operation = ldDetail.ProjectWorkOrder.Operation.Name;
                    model.Port = project.Port.Name;
                    model.Product = project.Product;
                    model.ProjectNo = project.No;
                    model.Dock = project.DockNumber;

                    foreach (var i in projectdispatches)
                    {
                        if (i.StatusId == 100)
                        {
                            model.ProjectDispatchInfo = "Dispatched to project by " + i.UpdatedBy + " ";
                        }
                        else
                        {
                            model.ProjectDispatchInfo = "Released off project by " + i.UpdatedBy + " ";
                        }
                    }
                    model.AssignedToProject = true;
                    model.PrimaryBarge = ldDetail.PrimaryBarge;

                    var entry = _entities.TransitionQueueEntries.Where(t => t.EmployeeId == employee.Id &&
                        t.ProjectNo == project.No && t.PrimaryBargeId.HasValue).SingleOrDefault();

                    if (entry != null)
                    {
                        model.BargeConfirmed = true;
                        //model.PrimaryBarge = tankermanTime.PrimaryBarge;
                    }
                    else
                    {
                        model.BargeConfirmed = false;
                    }

                    var entries = _entities.TransitionQueueEntries.Where(t => t.EmployeeId == employee.Id &&
                        !t.PrimaryBargeId.HasValue);

                    if (entries.Any())
                    {
                        model.DateTimesLastSubmitted = entries.Max(e => e.DateSubmitted);
                    }

                    model.Barges = ldDetail.Barges;
                }
            }
            return View(model);
        }
    }
}
