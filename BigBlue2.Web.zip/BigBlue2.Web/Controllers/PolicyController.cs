﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using BigBlue2.Data;
using BigBlue2.Services.Account;
using BigBlue2.Web.Infrastructure;
namespace BigBlue2.Web.Controllers
{
    public class PolicyController : BaseController
    {
        private readonly BigBlue2.Data.BigBlueEntities _entities;
        private readonly IMembershipService _membershipService;

        public PolicyController(BigBlue2.Data.BigBlueEntities entities, IMembershipService membershipService)
        {
            _entities = entities;
            _membershipService = membershipService;
        }

        public ActionResult Index()
        {
            var policies = _entities.EmployeePolicies.OrderBy(x => x.policy);
            return View(new Models.Policy.IndexModel() { Policies = policies.ToList() });
        }

        public ActionResult Details(int id)
        {
            var p = _entities.EmployeePolicies.Where(x => x.id == id).FirstOrDefault();
            if (p.id >= 0)
            {
                var m = new Models.Policy.DetailModel()
                {
                    Id = p.id,
                    Name = p.policy,
                    EmployeeList = new List<Models.Policy.EmployeePolicyReviewModel>()
                };

                // get list of employees
                foreach (var epr in p.EmployeePolicyReviews)
                {
                    var eprmodel = new Models.Policy.EmployeePolicyReviewModel()
                    {
                        IsReviewed = true,
                        Id = epr.employee_row_id.Value,
                        Name = epr.Employee.FullName
                    };

                    if (epr.accept_flag.HasValue && epr.accept_flag == true)
                    {
                        eprmodel.IsAccepted = true;
                        eprmodel.AcceptDate = epr.review_dt.Value;
                        eprmodel.AcceptType = epr.accept_type;
                    }
                    else
                    {
                        eprmodel.IsAccepted = false;
                    }
                    if (epr.employee_row_id.HasValue)
                    {
                        eprmodel.Notes = getNotes(id, epr.employee_row_id.Value);
                        m.EmployeeList.Add(eprmodel);
                    }
                    else
                    {
                        // probably terminated, need to check
                        var empt = _entities.Employees.Where(x => x.Id == epr.employee_row_id);
                        if (empt != null && empt.Count() > 0)
                        {
                            var termrecord = empt.First();
                            if (termrecord.TermDate.HasValue)
                            {
                                eprmodel.Notes = "Terminated on " + termrecord.TermDate.Value.ToShortDateString();
                            }
                        }
                    }
                }

                return View(m);
            }
            else
                throw new Exception("No ID found for that policy");
        }

        private string getNotes(int policyid, Guid emprowid)
        {
            string notestxt = string.Empty;

            switch (policyid)
            {
                case 1:
                    var emp = _entities.Employees.Active().Where(x => x.Id == emprowid);
                    if (emp != null && emp.Count() > 0)
                    {
                        if (emp.First().Contact != null)
                            notestxt = "#" + emp.First().Contact.SmsPhone.FormattedPhoneNumber() + " (" + emp.First().Contact.nfoSMSCarrier.name + ")";
                        else
                            notestxt = "No contact info found";
                    }
                    else
                        notestxt = "No emp info found";
                    ViewBag.NotesColumnName = "SMS Info";
                    break;
            }

            return notestxt;
        }

        

        public ActionResult ANTS()
        {
            // for now, can just store these in ViewBag
            var contobj = _entities.Employees.GetByUserName(_membershipService.CurrentUser).Contact;
            ViewBag.CurrentSMSPhoneNumber = contobj.SmsPhone;

            var displayedsms = _entities.nfoSMSCarriers.Where(x => x.display_flag == true).OrderBy(x => x.name);
            
            var selectlist = new SelectList(displayedsms, "id", "name", contobj.SmsPhoneCarrier);
            ViewBag.SmsProviderList = selectlist;

            return View();
        }

        public PartialViewResult PolicyPartial(int policyid)
        {
            Models.Policy.PolicyWidget m = new Models.Policy.PolicyWidget();
            var empobj = _entities.Employees.GetByUserName(_membershipService.CurrentUser);
            var policyobj = empobj.EmployeePolicyReviews.Where(x => x.policy_id == policyid).OrderByDescending(x => x.review_dt).Take(1);

            if (policyobj != null && policyobj.Count() > 0)
            {
                m.IsAccepted = policyobj.First().accept_flag.HasValue ? policyobj.First().accept_flag.Value : false ;
                m.ReviewDate = policyobj.First().review_dt;
                if (m.IsAccepted) m.StatusMessage = "ACCEPTED"; else m.StatusMessage = "DECLINED";
            }
            else
            {
                m.IsAccepted = false;
                m.StatusMessage = "Not reviewed";
            }

            if (policyid == 1)
            {
                m.Info1Label = "SMS #";
                m.Info2Label = "Carrier";
                if (empobj.Contact.SmsPhone != null && empobj.Contact.SmsPhone.Length>=9)
                    m.Info1Value = empobj.Contact.SmsPhone.Substring(0, 3) + "-" + empobj.Contact.SmsPhone.Substring(3, 3) + "-" + empobj.Contact.SmsPhone.Substring(6, 4);
                if (empobj.Contact.SmsPhoneCarrier != null)
                    m.Info2Value = _entities.nfoSMSCarriers.Where(x => x.id == empobj.Contact.SmsPhoneCarrier).FirstOrDefault().name;
                m.PolicyChangeAction = "ANTS";
                m.PolicyName = "Text Messaging (ANTS)";
                m.PolicyIcon = "Text-Bubble-Icon.png";
            }
            m.PolicyId = policyid;
            return PartialView("controls/partialPolicy", m);
        }

        [HttpPost]
        public ActionResult ANTS(string smsnumber, string smsprovider, string consent)
        {
            // todo:  save to db as policy accepted
            if (consent == "0" || consent == "1")
                Session["PolicyCheck"] = true;

            var emp =  _entities.Employees.GetByUserName(_membershipService.CurrentUser);
            var c = emp.Contact;
            c.SmsPhone = smsnumber;
            c.SmsPhoneCarrier = Convert.ToInt16(smsprovider);


            var p = new EmployeePolicyReview() { accept_type = "WEB", employee_row_id = emp.Id, policy_id = 1, review_dt = DateTime.Now };

            if (consent == "1") p.accept_flag = true; else p.accept_flag = false;

            _entities.EmployeePolicyReviews.Add(p);

            _entities.SaveChanges();

            return RedirectToAction("Index", "Home");
        }

    }
}