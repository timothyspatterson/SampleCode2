﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using BigBlue2.Web.Models.Notifications;
using System.Data.Objects;
using System.IO;

namespace BigBlue2.Web.Controllers
{
    [Authorize]
    public class NotificationsController : Controller
    {
        private readonly BigBlueEntities _entities;

        public NotificationsController(BigBlueEntities entities)
        {
            _entities = entities;
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public JsonResult TankermanNotificationsGridData(string sidx, string sord, int page, int rows, bool inactive)
        {
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            int totalRecords = _entities.Notifications.OfType<ProjectNotification>().Count();
            int totalPages = (int)Math.Ceiling((float)totalRecords / (float)pageSize);

            var query = _entities.Notifications.OfType<TankermanNotification>();

            if (!inactive)
            {
                query = query.Where(n => n.IsActive);
            }

            if (sord == "asc")
            {
                if (sidx == "TankermanGroupId")
                {
                    query = query.OrderBy(n => n.TankermanGroup.Name);
                }
                else
                {
                    query = query.OrderBy(n => n.DateCreated);
                }
            }
            else
            {
                if (sidx == "TankermanGroupId")
                {
                    query = query.OrderByDescending(n => n.TankermanGroup.Name);
                }
                else
                {
                    query = query.OrderByDescending(n => n.DateCreated);
                }
            }

            var notifications = query
                .Skip(pageIndex * pageSize).Take(pageSize).ToList();

            var jsonData = new
            {
                total = totalPages,
                page,
                records = totalRecords,
                rows = (
                    from notification in notifications
                    select new
                    {
                        id = notification.Id,
                        cell = new string[] 
                        { 
                            notification.Message,
                            notification.TankermanGroupId.HasValue ? notification.TankermanGroup.Name : "",
                            notification.DateCreated.ToShortDateString(),
                            notification.Id.ToString(),
                            notification.IsActive.ToString(),
                            notification.AttachedFile != null ? "true" : "false"
                        }
                    }).ToArray()
            };

            return Json(jsonData);
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public JsonResult ProjectNotificationsGridData(string sidx, string sord, int page, int rows, string message,
            string customer, string boat, string barge, string location, string port, string projectLocation,
            DateTime? dateCreated, bool inactive)
        {
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            int totalRecords = _entities.Notifications.OfType<ProjectNotification>().Count();
            int totalPages = (int)Math.Ceiling((float)totalRecords / (float)pageSize);

            var query = _entities.Notifications.OfType<ProjectNotification>();

            if (!inactive)
            {
                query = query.Where(n => n.IsActive);
            }

            if (!String.IsNullOrEmpty(message))
            {
                query = query.Where(n => n.Message.Contains(message));
            }

            if (!String.IsNullOrEmpty(customer))
            {
                query = query.Where(n => n.Customer.Name.StartsWith(customer));
            }

            if (!String.IsNullOrEmpty(boat))
            {
                query = query.Where(n => n.Boat.Name.StartsWith(boat));
            }

            if (!String.IsNullOrEmpty(barge))
            {
                query = query.Where(n => n.Barge.Name.StartsWith(barge));
            }

            if (!String.IsNullOrEmpty(location))
            {
                query = query.Where(n => n.Location.Name.StartsWith(location));
            }

            if (!String.IsNullOrEmpty(port))
            {
                query = query.Where(n => n.Port.Name.StartsWith(port));
            }

            if (!String.IsNullOrEmpty(projectLocation))
            {
                query = query.Where(n => n.ProjectLocation.Name.StartsWith(projectLocation));
            }

            if (dateCreated.HasValue)
            {
                var date = dateCreated.Value.Date;
                query = query.Where(n => EntityFunctions.TruncateTime(n.DateCreated) == date);
            }

            if (sord == "asc")
            {
                if (sidx == "Customer")
                {
                    query = query.OrderBy(n => n.Customer.Name);
                }
                else if (sidx == "Boat")
                {
                    query = query.OrderBy(n => n.Boat.Name);
                }
                else if (sidx == "Barge")
                {
                    query = query.OrderBy(n => n.Barge.Name);
                }
                else if (sidx == "Location")
                {
                    query = query.OrderBy(n => n.Location.Name);
                }
                else if (sidx == "Port")
                {
                    query = query.OrderBy(n => n.Port.Name);
                }
                else if (sidx == "ProjectLocation")
                {
                    query = query.OrderBy(n => n.ProjectLocation.Name);
                }
                else
                {
                    query = query.OrderBy(n => n.DateCreated);
                }
            }
            else
            {
                if (sidx == "Customer")
                {
                    query = query.OrderByDescending(n => n.Customer.Name);
                }
                else if (sidx == "Boat")
                {
                    query = query.OrderByDescending(n => n.Boat.Name);
                }
                else if (sidx == "Barge")
                {
                    query = query.OrderByDescending(n => n.Barge.Name);
                }
                else if (sidx == "Location")
                {
                    query = query.OrderByDescending(n => n.Location.Name);
                }
                else if (sidx == "Port")
                {
                    query = query.OrderByDescending(n => n.Port.Name);
                }
                else if (sidx == "ProjectLocation")
                {
                    query = query.OrderByDescending(n => n.ProjectLocation.Name);
                }
                else
                {
                    query = query.OrderByDescending(n => n.DateCreated);
                }
            }

            var notifications = query
                .Skip(pageIndex * pageSize).Take(pageSize).ToList();

            var jsonData = new
            {
                total = totalPages,
                page,
                records = totalRecords,
                rows = (
                    from notification in notifications
                    select new
                    {
                        id = notification.Id,
                        cell = new string[] 
                        { 
                            notification.Message,
                            notification.Customer != null ? notification.Customer.Name : "",
                            notification.Boat != null ? notification.Boat.Name : "",
                            notification.Barge != null ? notification.Barge.Name : "",
                            notification.Location != null ? notification.Location.Name : "",
                            notification.Port != null ? notification.Port.Name : "",
                            notification.ProjectLocation != null ? notification.ProjectLocation.Name : "",
                            notification.DateCreated.ToShortDateString(),
                            notification.Id.ToString(),
                            notification.IsActive.ToString()
                        }
                    }).ToArray()
            };

            return Json(jsonData);
        }

        [HttpGet]
        [Authorize(Roles = "Administrator")]
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        [Authorize(Roles = "Administrator")]
        public ActionResult CreateForProject()
        {
            var boats = _entities.Boats.Active();
            var customers = _entities.Customers.Active();
            var locations = _entities.Locations.Active();
            var ports = _entities.Ports.Active();
            var barges = _entities.Barges.Active();
            var projectLocations = _entities.ProjectLocations.Active();

            var model = new CreateForProjectModel(boats, customers, ports, locations, projectLocations, barges);

            return View(model);
        }

        [HttpGet]
        [Authorize(Roles = "Administrator")]
        public ActionResult CreateForTankerman()
        {
            var groups = _entities.TankermanGroups.Active();

            var model = new CreateForTankermanModel(groups);

            return View(model);
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public ActionResult CreateForProject(CreateForProjectInput input)
        {
            if (ModelState.IsValid)
            {
                var notification = _entities.Notifications.Create<ProjectNotification>();

                notification.CreatedBy = User.Identity.Name;
                notification.DateCreated = DateTime.Now;
                notification.BargeId = input.BargeId;
                notification.BoatId = input.BoatId;
                notification.CustomerId = input.CustomerId;
                notification.LocationId = input.LocationId;
                notification.Message = input.Message;
                notification.PortId = input.PortId;
                notification.ProjectLocationId = input.ProjectLocationId;
                notification.IsActive = true;

                _entities.Notifications.Add(notification);
                _entities.SaveChanges();

                return RedirectToAction("Index");
            }

            return CreateForProject();
        }

        [HttpGet]
        public ActionResult Attachment(int id)
        {
            var notification = _entities.Notifications.OfType<TankermanNotification>().SingleOrDefault(n => n.Id == id);

            if (notification != null)
            {
                if (notification.AttachedFile != null)
                {
                    return new FileContentResult(notification.AttachedFile, notification.FileType);
                }
            }

            return RedirectToAction("Tankerman");
        }

        [HttpPost]
        public ActionResult CreateForTankerman(CreateForTankermanInput input)
        {
            if (ModelState.IsValid)
            {
                var notification = _entities.Notifications.Create<TankermanNotification>();
 
                if (Request.Files.Count > 0)
                {
                    var file = Request.Files[0];

                    byte[] buffer = new byte[16 * 1024];

                    using (MemoryStream ms = new MemoryStream())
                    {
                        int read;
                        while ((read = file.InputStream.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            ms.Write(buffer, 0, read);
                        }

                        notification.AttachedFile = ms.ToArray();
                        notification.FileType = file.ContentType;
                    }
                }

                notification.CreatedBy = User.Identity.Name;
                notification.DateCreated = DateTime.Now;
                notification.Message = input.Message;
                notification.TankermanGroupId = input.TankermanGroupId;
                notification.IsActive = true;

                _entities.Notifications.Add(notification);
                _entities.SaveChanges();

                return RedirectToAction("Index");
            }

            return CreateForTankerman();
        }

        [HttpPost]
        public ContentResult UpdateActiveStatus(int id, bool active)
        {
            var notification = _entities.Notifications.Find(id);

            notification.IsActive = active;

            _entities.SaveChanges();

            return Content("true");
        }

        [HttpGet]
        public ActionResult Tankerman()
        {
            var employee = _entities.Employees.GetByUserName(User.Identity.Name);

            var acceptedNotifications = _entities.AcceptedNotifications
                .Where(n => n.AcceptedBy == User.Identity.Name && n.TankermanNotification.IsActive)
                .OrderByDescending(n => n.DateAccepted);

            var model = new TankermanModel();

            model.AcceptedNotifications = acceptedNotifications;

            if (employee != null)
            {
                model.NotAcceptedNotifications = _entities.Notifications.OfType<TankermanNotification>()
                    .Where(n => n.IsActive)
                    .NotAcceptedBy(employee);
            }

            return View(model);
        }

        [HttpPost]
        public ActionResult AcceptTankermanNotification(int id)
        {
            if (!_entities.AcceptedNotifications.Any(n => n.AcceptedBy == User.Identity.Name &&
                n.TankermanNotificationId == id) && _entities.Notifications.Find(id) != null)
            {
                var acceptedNotification = _entities.AcceptedNotifications.Create();

                acceptedNotification.AcceptedBy = User.Identity.Name;
                acceptedNotification.DateAccepted = DateTime.Now;
                acceptedNotification.TankermanNotificationId = id;

                _entities.AcceptedNotifications.Add(acceptedNotification);
                _entities.SaveChanges();


            }

            return Content(id.ToString());
        }

        [HttpPost]
        public ActionResult Accepted(int id)
        {
            var accepted = _entities.AcceptedNotifications.Where(n => n.TankermanNotificationId == id)
                .OrderBy(n => n.AcceptedBy);

            return PartialView(accepted);
        }
    }
}
