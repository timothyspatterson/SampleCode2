﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using BigBlue2.Web.Models.TraineeReviews;
using BigBlue2.Services.Account;
using BigBlue2.Services;
using System.Data.Metadata.Edm;
using System.Data.Objects;
using BigBlue2.Web.Mailers;
using Mvc.Mailer;

namespace BigBlue2.Web.Controllers
{
    
    public class TraineeReviewsController : Controller
    {
        private readonly BigBlueEntities _entities;
        private readonly IMembershipService _membershipService;
        private readonly ITraineeReviewMailer _traineeReviewMailer;

        public TraineeReviewsController(BigBlueEntities entities, IMembershipService membershipService,
            ITraineeReviewMailer traineeReviewMailer)
        {
            _entities = entities;
            _membershipService = membershipService;
            _traineeReviewMailer = traineeReviewMailer;
        }

        [HttpGet]
        public ActionResult Create(Guid? employeeId, string projectNo)
        {
            var employees = _entities.EmployeeSummaries.Active();

            if (employeeId.HasValue && !String.IsNullOrWhiteSpace(projectNo))
            {
                var projects = _entities.EmployeeToProjects.ProjectsByEmployee(employeeId.Value);
                var project = _entities.ProjectSummaries.SingleOrDefault(p => p.ProjectNo == projectNo);

                return View(new CreateModel(employees, projects, project));
            }
            else
            {
                return View(new CreateModel(employees));
            }
        }

        [HttpPost]
        public ActionResult Create(CreateInput input)
        {
            if (ModelState.IsValid)
            {
                var review = _entities.TraineeReviews.Create();

                review.CreatedBy = _membershipService.CurrentUser;
                review.DateCreated = DateTime.Now;
                review.ProjectNo = input.ProjectNo;
                review.TraineeEmployeeId = input.TraineeEmployeeId;

                review.BargeDocumentation = (int)input.BargeDocumentation;
                review.BargeHousekeeping = (int)input.BargeHousekeeping;
                review.BlowingDraining = (int)input.BlowingDraining;
                review.BoltAlignment = (int)input.BoltAlignment;
                review.BreakingVacuum = (int)input.BreakingVacuum;
                review.Comments = input.Comments;
                review.ControllingN2AirFlow = (int)input.ControllingN2AirFlow;
                review.DateOfReview = input.DateOfReview;
                review.DemeanorComments = input.DemeanorComments;
                review.DeterminingRates = (int)input.DeterminingRates;
                review.DisconnectSequence = (int)input.DisconnectSequence;
                review.DOICompletion = (int)input.DOICompletion;
                review.DrainingClearingBlowingDockHose = (int)input.DrainingClearingBlowingDockHose;
                review.DriversLicense = (int)input.DriversLicense;
                review.EngineCheck = (int)input.EngineCheck;
                review.EngineOperations = (int)input.EngineOperations;
                review.EnsuringProperDrainage = (int)input.EnsuringProperDrainage;
                review.EstimatingCompletion = (int)input.EstimatingCompletion;
                review.EyeWashEmergencyShowerLocation = (int)input.EyeWashEmergencyShowerLocation;
                review.FireExtinguishers = (int)input.FireExtinguishers;
                review.FluidLevel = (int)input.FluidLevel;
                review.FoodDrink = (int)input.FoodDrink;
                review.GasketPlacement = (int)input.GasketPlacement;
                review.GaugeRodDeployment = (int)input.GaugeRodDeployment;
                review.HoseArmConnection = (int)input.HoseArmConnection;
                review.InitialRatesAndShutdown = (int)input.InitialRatesAndShutdown;
                review.JudgementComments = input.JudgementComments;
                review.KnowledgeComments = input.KnowledgeComments;
                review.LeakDetection = (int)input.LeakDetection;
                review.LocationOfESD = (int)input.LocationOfESD;
                review.MechanicsComments = input.MechanicsComments;
                review.MMD = (int)input.MMD;
                review.MonitoringLevels = (int)input.MonitoringLevels;
                review.MonitoringTankLevels = (int)input.MonitoringTankLevels;
                review.Pigging = (int)input.Pigging;
                review.PlacementOfDocumentation = (int)input.PlacementOfDocumentation;
                review.PPE = (int)input.PPE;
                review.PPEComments = input.PPEComments;
                review.PrimingRepriming = (int)input.PrimingRepriming;
                review.PumpBleedingOperations = (int)input.PumpBleedingOperations;
                review.RemovingBondingCable = (int)input.RemovingBondingCable;
                review.ReportingDelaysDiscrepancies = (int)input.ReportingDelaysDiscrepancies;
                review.ReprimingOperations = (int)input.ReprimingOperations;
                review.RetentionComments = input.RetentionComments;
                review.SafeAccessToVessel = (int)input.SafeAccessToVessel;
                review.SafetyCouncilCards = (int)input.SafetyCouncilCards;
                review.SecuringDripPanCovers = (int)input.SecuringDripPanCovers;
                review.SecuringGaugeRods = (int)input.SecuringValves;
                review.SecuringValves = (int)input.SecuringValvesHatches;
                review.SecuringValvesHatches = (int)input.SecuringVaporControlDevices;
                review.SecuringVaporControlDevices = (int)input.SecuringVaporControlDevices;
                review.ShutdownValveAlignment = (int)input.ShutDownValveAlignment;
                review.SkillLevelComments = input.SkillLevelComments;
                review.StandbyNotices = (int)input.StandbyNotices;
                review.StrippingOperations = (int)input.StrippingOperations;
                review.TallyRecordBook = (int)input.TallyRecordBook;
                review.ToolsEquipment = (int)input.ToolsEquipment;
                review.Uniform = (int)input.Uniform;
                review.ValveAlignment = (int)input.ValveAlignment;
                review.ValvesPlugsBleeder = (int)input.ValvesPlugsBleeder;
                review.VerifyCompareOrders = (int)input.VerifyCompareOrders;
                review.VerifyingOrdersPriorDisconnecting = (int)input.VerifyingOrdersPriorDisconnecting;
                review.VesselProperlySecuredMoored = (int)input.VesselProperlySecuredMoored;
                review.WorkEthicComments = input.WorkEthicComments;

                _entities.TraineeReviews.Add(review);
                _entities.SaveChanges();
                MvcMailerSmtpExtension ext = new MvcMailerSmtpExtension(new SmtpBoyEntities());
                _traineeReviewMailer.TraineeReviewCreated(review).Send(ext);

                return RedirectToAction("Index");
            }
            else
            {
                return Create(input.TraineeEmployeeId, input.ProjectNo);
            }
        }

        [HttpPost]
        [Authorize(Roles = "Administrator")]
        public void Delete(int[] ids)
        {
            foreach (int id in ids)
            {
                var review = new TraineeReview() { Id = id };
                _entities.Entry(review).State = System.Data.EntityState.Deleted;
            }

            _entities.SaveChanges();
        }

        [HttpGet]
        public ActionResult Index()
        {
            var reviews = _entities.TraineeReviews.OrderByDescending(r => r.DateOfReview);

            return View(reviews);
        }

        [HttpPost]
        public JsonResult GridData(string sidx, string sord, int page, int rows, string fullName, string projectNo,
            string facility, string operation, string product, DateTime? dateOfReview, string createdBy)
        {
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            int totalRecords = _entities.TraineeReviews.Count();
            int totalPages = (int)Math.Ceiling((float)totalRecords / (float)pageSize);

            var query = _entities.TraineeReviews.AsQueryable();

            if (!String.IsNullOrEmpty(fullName))
            {
                query = query.Where(r => r.Employee.Contact.FirstName.StartsWith(fullName) ||
                    r.Employee.Contact.LastName.StartsWith(fullName));
            }

            if (!String.IsNullOrEmpty(projectNo))
            {
                query = query.Where(r => r.ProjectNo.StartsWith(projectNo));
            }

            if (!String.IsNullOrEmpty(facility))
            {
                query = query.Where(r => r.Project.Location.Name.StartsWith(facility) ||
                    r.Project.Port.Name.StartsWith(facility));
            }

            if (!String.IsNullOrEmpty(operation))
            {
                query = query.Where(r => r.Project.Operation.Name.StartsWith(operation));
            }

            if (!String.IsNullOrEmpty(product))
            {
                query = query.Where(r => r.Project.Product.StartsWith(operation));
            }

            if (dateOfReview.HasValue)
            {
                var date = dateOfReview.Value.Date;
                query = query.Where(r => EntityFunctions.TruncateTime(r.DateOfReview) == date);
            }

            if (!String.IsNullOrEmpty(createdBy))
            {
                query = query.Where(r => r.CreatedBy == createdBy);
            }

            if (sord == "asc")
            {
                if (sidx == "FullName")
                {
                    query = query.OrderBy(r => r.Employee.Contact.LastName)
                        .ThenBy(r => r.Employee.Contact.FirstName)
                        .ThenBy(r => r.Employee.Contact.MiddleName);
                }
                else if (sidx == "ProjectNo")
                {
                    query = query.OrderBy(r => r.ProjectNo);
                }
                else if (sidx == "Facility")
                {
                    query = query.OrderBy(r => r.Project.Location.Name).ThenBy(r => r.Project.Port.Name);
                }
                else if (sidx == "Operation")
                {
                    query = query.OrderBy(r => r.Project.Operation);
                }
                else if (sidx == "Product")
                {
                    query = query.OrderBy(r => r.Project.Product);
                }
                else if (sidx == "CreatedBy")
                {
                    query = query.OrderBy(r => r.CreatedBy);
                }
                else
                {
                    query = query.OrderBy(r => r.DateOfReview);
                }
            }
            else
            {
                if (sidx == "FullName")
                {
                    query = query.OrderByDescending(r => r.Employee.Contact.LastName)
                        .ThenBy(r => r.Employee.Contact.FirstName)
                        .ThenBy(r => r.Employee.Contact.MiddleName);
                }
                else if (sidx == "ProjectNo")
                {
                    query = query.OrderByDescending(r => r.ProjectNo);
                }
                else if (sidx == "Facility")
                {
                    query = query.OrderByDescending(r => r.Project.Location.Name).ThenBy(r => r.Project.Port.Name);
                }
                else if (sidx == "Operation")
                {
                    query = query.OrderByDescending(r => r.Project.Operation);
                }
                else if (sidx == "Product")
                {
                    query = query.OrderByDescending(r => r.Project.Product);
                }
                else if (sidx == "CreatedBy")
                {
                    query = query.OrderByDescending(r => r.CreatedBy);
                }
                else
                {
                    query = query.OrderByDescending(r => r.DateOfReview);
                }
            }

            var reviews = query
                .Skip(pageIndex * pageSize).Take(pageSize).ToList();

            var jsonData = new
            {
                total = totalPages,
                page,
                records = totalRecords,
                rows = (
                    from review in reviews
                    select new
                    {
                        id = review.Id,
                        cell = new string[] 
                        { 
                            review.Employee.FullName,
                            review.ProjectNo,
                            review.Project.Facility,
                            review.Project.Operation.Name,
                            review.Project.Product,
                            review.DateOfReview.To24HourDateTimeString(),
                            review.CreatedBy,
                            review.Id.ToString()
                        }
                    }).ToArray()
            };
            return Json(jsonData);
        }
    }
}
