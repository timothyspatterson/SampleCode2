﻿using BigBlue2.Data;
using BigBlue2.Web.Models.Admin;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace BigBlue2.Web.Controllers
{
    public class TextController : Controller
    {
        private readonly BigBlueEntities _entities;
        private readonly SmtpBoyEntities _smtpentities;

        public TextController(BigBlueEntities entities)
        {
            _entities = entities;
        }

        public ActionResult ANTMound()
        {
            Models.Admin.ANTMoundIndexModel m = new ANTMoundIndexModel();

            // load locations
            m.Locations = new List<ANTRecipient>();


            foreach (var l in getgroups())
            {
                var newloc = new ANTRecipient() { Name = l.Name, Selected = false, Info = l.Id.ToString() };
                newloc.Employees = new List<ANTRecipient>();
                foreach (var ee in l.PermanentEmployees.Where(x => x.IsActive == true && x.TermDate == null).OrderBy(x => x.FullName))
                {
                    if (ee.EmployeeApprovePolicy(1))
                        newloc.Employees.Add(new ANTRecipient() { Name = ee.FullName, Info = ee.Id.ToString(), Selected = false, AcceptedPolicy = true });
                    else
                        newloc.Employees.Add(new ANTRecipient() { Name = ee.FullName, Info = ee.Id.ToString(), Selected = false, AcceptedPolicy = false });
                }

                m.Locations.Add(newloc);

            }

            return View(m);
        }
        public List<TankermanGroup> getgroups()
        {
            var list = _entities.TankermanGroups.Where(x => x.DisplayFlag == true).OrderBy(x => x.DisplayOrder).ToList();
            return list;
        }


        public List<TankermanGroup> getgroupstesting()
        {
            if (System.Web.HttpContext.Current.Cache["groups"] != new object())
                return (List<TankermanGroup>)System.Web.HttpContext.Current.Cache["groups"];
            else
            {
                var list = _entities.TankermanGroups.Where(x => x.DisplayFlag == true && x.Id == 8).OrderBy(x => x.DisplayOrder).ToList();
                if (User.Identity.Name == "cody2")
                    System.Web.HttpContext.Current.Cache.Insert("groups", list, null, System.Web.Caching.Cache.NoAbsoluteExpiration, new TimeSpan(0, 60, 0));
                return list;
            }

        }

        [HttpPost]
        public ActionResult ANTMound(FormCollection fc)
        {
            List<Guid> employeesToAdd = new List<Guid>();
            foreach (string keyname in fc.Keys)
            {

                if (keyname.Contains("Employee"))
                {
                    // add directly.

                    bool ischecked = Convert.ToBoolean(fc[keyname].Split(',')[0]);
                    if (ischecked)
                    {
                        string idwithoutprefix = keyname.Remove(0, 9);
                        if (!employeesToAdd.Contains(new Guid(idwithoutprefix)))
                            employeesToAdd.Add(new Guid(idwithoutprefix));
                    }
                }
            }

            string s = string.Empty;
            foreach (var empguid in employeesToAdd)
            {
                var emp = _entities.Employees.Where(x => x.Id == empguid).FirstOrDefault();
                sendTextMessage(empguid, emp.FullName, emp.Contact.SmsPhone, fc["message"]);
            }

            return RedirectToAction("AntMound");


        }

        private void sendTextMessage(Guid employeeId, string fullName, string smsnumber, string message)
        {
            WebClient client = new WebClient();
            client.Encoding = Encoding.UTF8;
            var values = new NameValueCollection();
            values.Add("PhoneTo", smsnumber);
            values.Add("Message", message);
            values.Add("EmployeeId", employeeId.ToString());
            values.Add("ProjectNo", string.Empty);
            values.Add("Name", fullName);
            try
            {
                byte[] retValue = client.UploadValues("https://apps.accutransinc.com/services/texter/Send", "POST", values);
                string tempStr = Encoding.ASCII.GetString(retValue);
            }
            catch (System.Exception ex)
            {
                throw new Exception("Error sending message: " + ex.Message);
            }
        }

    }
}
