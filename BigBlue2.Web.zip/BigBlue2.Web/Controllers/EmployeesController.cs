﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using System.Web.Security;
using BigBlue2.Web.Models.Employees;
using BigBlue2.Services.Email;
using BigBlue2.Web.Models;
using BigBlue2.Services.Employees;
using BigBlue2.Services.Validation;
using BigBlue2.Services;
using OfficeOpenXml;
using System.IO;
using System.Web.Caching;

namespace BigBlue2.Web.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly BigBlueEntities _entities;
        private readonly EmployeeSaver _employeeSaver;

        public EmployeesController(BigBlueEntities entities, EmployeeSaver employeeSaver)
        {
            _entities = entities;
            _employeeSaver = employeeSaver;
        }

        [HttpGet]
        [Authorize(Roles = "HR_CreateEmployee")]
        public ActionResult Create()
        {
            var employeeDto = new EmployeeDto();

            int maxEmployeeId = _entities.Employees.Max(e => e.EmployeeId);

            if (maxEmployeeId < 2000)
            {
                maxEmployeeId = 2000;
            }

            employeeDto.EmployeeId = maxEmployeeId + 1;

            var model = new FormFieldsModel(employeeDto, _entities);

            return View(model);
        }

        [HttpPost]
        [Authorize(Roles = "HR_CreateEmployee")]
        public ActionResult Create([Bind(Prefix = "Employee")]EmployeeDto dto)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _employeeSaver.SaveFromDto(dto);
                    return RedirectToAction("Index");
                }
                catch (ValidationException ex)
                {
                    ModelState.AddValidationErrors(ex);

                    return Create();
                }
            }

            return Create();
        }

        [HttpGet]
        [Authorize(Roles = "HR_EmployeeMaintenance")]
        public ActionResult Edit(Guid id)
        {
            var employee = _entities.Employees.SingleOrDefault(e => e.Id == id);

            if (employee == null)
            {
                return RedirectToAction("Index");
            }

            var dto = new EmployeeDto(employee);

            var model = new FormFieldsModel(dto, _entities);

            return View(model);
        }

        [HttpPost]
        [Authorize(Roles = "HR_EmployeeMaintenance")]
        public ActionResult Edit([Bind(Prefix = "Employee")]EmployeeDto dto)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var employee = _employeeSaver.SaveFromDto(dto);

                    //var nextEmployee = _entities.Employees.Where(e => !e.TermDate.HasValue && e.IsActive)
                    //.OrderBy(e => e.Contact.LastName).ThenBy(e => e.Contact.FirstName)
                    //.First(e => (e.Contact.LastName + (String.IsNullOrEmpty(e.Contact.Suffix) ? "" : e.Contact.Suffix) + ", " + e.Contact.FirstName + " " + e.Contact.MiddleName).CompareTo(employee.FullName) == 1);

                    return RedirectToAction("Index");
                }
                catch (ValidationException ex)
                {
                    ModelState.AddValidationErrors(ex);
                    return Edit(dto.Id.Value);
                }
            }

            return Edit(dto.Id.Value);
        }

        [HttpGet]
        [Authorize(Roles = "HR_EmployeeMaintenance")]
        public ActionResult GenerateExcelFile()
        {
            var package = new ExcelPackage();

            var worksheet = package.Workbook.Worksheets.Add("Employees");

            worksheet.Cells[1, 1].Value = "First Name";
            worksheet.Cells[1, 2].Value = "Middle Name";
            worksheet.Cells[1, 3].Value = "Last Name";
            worksheet.Cells[1, 4].Value = "Suffix";
            worksheet.Cells[1, 5].Value = "Employee ID";
            worksheet.Cells[1, 6].Value = "SSN";
            worksheet.Cells[1, 7].Value = "Date of Birth";
            worksheet.Cells[1, 8].Value = "DL Number";
            worksheet.Cells[1, 9].Value = "DL State";
            worksheet.Cells[1, 10].Value = "Hire Date";
            worksheet.Cells[1, 11].Value = "Street 1";
            worksheet.Cells[1, 12].Value = "Street 2";
            worksheet.Cells[1, 13].Value = "City";
            worksheet.Cells[1, 14].Value = "State";
            worksheet.Cells[1, 15].Value = "Zip";
            worksheet.Cells[1, 16].Value = "Phone 1";
            worksheet.Cells[1, 17].Value = "Phone 1 Label";
            worksheet.Cells[1, 18].Value = "Phone 2";
            worksheet.Cells[1, 19].Value = "Phone 2 Label";
            worksheet.Cells[1, 20].Value = "Phone 3";
            worksheet.Cells[1, 21].Value = "Phone 3 Label";
            worksheet.Cells[1, 22].Value = "Phone 4";
            worksheet.Cells[1, 23].Value = "Phone 4 Label";
            worksheet.Cells[1, 24].Value = "Email";
            worksheet.Cells[1, 25].Value = "Additional Condition Info";
            worksheet.Cells[1, 26].Value = "Company";
            worksheet.Cells[1, 27].Value = "Perm Tankerman Group";
            worksheet.Cells[1, 28].Value = "Current Tankerman Group";
            worksheet.Cells[1, 29].Value = "Department";
            worksheet.Cells[1, 30].Value = "Sub Location";
            worksheet.Cells[1, 31].Value = "Rotation";
            worksheet.Cells[1, 32].Value = "License Acquired";
            worksheet.Cells[1, 33].Value = "License Expired";
            worksheet.Cells[1, 34].Value = "50 Trans";
            worksheet.Cells[1, 35].Value = "Spills";
            worksheet.Cells[1, 36].Value = "Grade";
            worksheet.Cells[1, 37].Value = "2012 Vacation";
            worksheet.Cells[1, 38].Value = "Guaranteed Hours";
            worksheet.Cells[1, 39].Value = "Trainee";
            worksheet.Cells[1, 40].Value = "Portal UserName";

            var employees = _entities.Employees.Active().ToList();

            for (int i = 2; i <= employees.Count + 1; i++)
            {
                worksheet.Cells[i, 1].Value = employees[i - 2].Contact.FirstName;
                worksheet.Cells[i, 2].Value = employees[i - 2].Contact.MiddleName;
                worksheet.Cells[i, 3].Value = employees[i - 2].Contact.LastName;
                worksheet.Cells[i, 4].Value = employees[i - 2].Contact.Suffix;
                worksheet.Cells[i, 5].Value = employees[i - 2].EmployeeId;
                worksheet.Cells[i, 6].Value = employees[i - 2].Ssn;
                worksheet.Cells[i, 7].Value = employees[i - 2].DateOfBirth.Value.ToShortDateString();
                worksheet.Cells[i, 8].Value = employees[i - 2].DriversLicenseNo;
                worksheet.Cells[i, 9].Value = employees[i - 2].DriversLicenseState;
                worksheet.Cells[i, 10].Value = employees[i - 2].HireDate.Value.ToShortDateString();
                worksheet.Cells[i, 11].Value = employees[i - 2].EmployeeAddresses.First().Address.Address1;
                worksheet.Cells[i, 12].Value = employees[i - 2].EmployeeAddresses.First().Address.Address2;
                worksheet.Cells[i, 13].Value = employees[i - 2].EmployeeAddresses.First().Address.City;
                worksheet.Cells[i, 14].Value = employees[i - 2].EmployeeAddresses.First().Address.State;
                worksheet.Cells[i, 15].Value = employees[i - 2].EmployeeAddresses.First().Address.ZipCode;
                worksheet.Cells[i, 16].Value = employees[i - 2].Contact.Phone1;
                worksheet.Cells[i, 17].Value = employees[i - 2].Contact.Phone1Label;
                worksheet.Cells[i, 18].Value = employees[i - 2].Contact.Phone2;
                worksheet.Cells[i, 19].Value = employees[i - 2].Contact.Phone2Label;
                worksheet.Cells[i, 20].Value = employees[i - 2].Contact.Phone3;
                worksheet.Cells[i, 21].Value = employees[i - 2].Contact.Phone3Label;
                worksheet.Cells[i, 22].Value = employees[i - 2].Contact.Phone4;
                worksheet.Cells[i, 23].Value = employees[i - 2].Contact.Phone4Label;
                worksheet.Cells[i, 24].Value = employees[i - 2].Contact.EmailAddress;
                worksheet.Cells[i, 25].Value = employees[i - 2].Contact.AdditionalContactInfo;
                worksheet.Cells[i, 26].Value = employees[i - 2].Company.Name;
                try { worksheet.Cells[i, 27].Value = employees[i - 2].PermanentTankermanGroup.Name; }
                catch { worksheet.Cells[i, 27].Value = ""; }
                try { worksheet.Cells[i, 28].Value = employees[i - 2].CurrentTankermanGroup.Name;}
                catch { worksheet.Cells[i, 28].Value = ""; }
                try { worksheet.Cells[i, 29].Value = employees[i - 2].Department.Name;}
                catch { worksheet.Cells[i, 29].Value = ""; }
                try { worksheet.Cells[i, 30].Value = employees[i - 2].SubLocation.Name;}
                catch { worksheet.Cells[i, 30].Value = ""; }
                try { worksheet.Cells[i, 31].Value = employees[i - 2].Schedule != null ? employees[i - 2].Schedule.Name : String.Empty;}
                catch { worksheet.Cells[i, 31].Value = ""; }
                try { worksheet.Cells[i, 32].Value = employees[i - 2].DateLicenseAcquired; }
                catch { worksheet.Cells[i, 32].Value = ""; }
                try { worksheet.Cells[i, 33].Value = employees[i - 2].DateLicenseExpired;}
                catch { worksheet.Cells[i, 33].Value = ""; }
                try { worksheet.Cells[i, 34].Value = employees[i - 2].Trans50;}
                catch { worksheet.Cells[i, 34].Value = ""; }
                try { worksheet.Cells[i, 35].Value = employees[i - 2].Spills;}
                catch { worksheet.Cells[i, 35].Value = ""; }
                try { worksheet.Cells[i, 36].Value = employees[i - 2].Grade;}
                catch { worksheet.Cells[i, 36].Value = ""; }
                try { worksheet.Cells[i, 37].Value = employees[i - 2].CurrentYearVacation;}
                catch { worksheet.Cells[i, 37].Value = ""; }
                try { worksheet.Cells[i, 38].Value = employees[i - 2].GuaranteedHours;}
                catch { worksheet.Cells[i, 38].Value = ""; }
                try { worksheet.Cells[i, 39].Value = employees[i - 2].IsTrainee;}
                catch { worksheet.Cells[i, 39].Value = ""; }
                try { worksheet.Cells[i, 40].Value = employees[i - 2].UserName;}
                catch { worksheet.Cells[i, 40].Value = ""; }
            }

            worksheet.Cells.AutoFitColumns(0);

            return File(package.GetAsByteArray(), "application/vnd.ms-excel", "employees.xlsx");
        }

        [HttpGet]
        [Authorize(Roles = "HR_EmployeeMaintenance")]
        public ActionResult Index(string name, string tankermanGroup, string department, bool displayTerminated = false,
            string sort = "Name", string sortDir = "ASC")
        {
            IQueryable<Employee> query = _entities.Employees;

            if (User.Identity.Name == "cody2")
            {
                query = query.Where(x => x.IsActive == true && x.PermanentTankermanGroup.Name.ToLower() == "office");
            }
            else
            {
                if (!String.IsNullOrEmpty(name))
                {
                    query = query.Where(e => e.Contact.FirstName.Contains(name) || e.Contact.LastName.Contains(name));
                }

                if (!displayTerminated)
                {
                    query = query.Active();
                }

                if (!String.IsNullOrEmpty(tankermanGroup))
                {
                    query = query.Where(e => e.PermanentTankermanGroup.Name == tankermanGroup);
                }

                if (!String.IsNullOrEmpty(department))
                {
                    query = query.Where(e => e.DepartmentCode == department);
                }
            }

            var employees = from e in query.ToList()
                            select new IndexModel.GridItem(e);

            var gridModel = new GridModel<IndexModel.GridItem>(employees, 0, sort, sortDir);

            if (Request.IsAjaxRequest())
            {
                return PartialView("Grid", gridModel);
            }
            else
            {
                var model = new IndexModel()
                {
                    GridModel = gridModel,
                    TankermanGroups = new SelectList(gridModel.GridItems.OrderBy(g => g.PermanentGroup)
                        .Select(g => g.PermanentGroup).Distinct()),
                    Departments = new SelectList(_entities.Departments.Where(d => d.DisplayFlag)
                        .OrderBy(d => d.Name), "Code", "Name")
                };

                return View(model);
            }
        }

        private void CalculateTotals(int year, Guid employeeId, out int regBargeLoad, out int regBargeDischarge,
            out int pressureBargeLoad, out int pressureBargeDischarge)
        {
            DateTime lastYearStart = new DateTime(year, 1, 1);
            DateTime lastYearEnd = lastYearStart.AddYears(1).Subtract(new TimeSpan(1));

            var projectNos = _entities.LaborPostings.Where(p => p.EmployeeId == employeeId &&
                p.ArrivalDate >= lastYearStart &&
                p.ArrivalDate <= lastYearEnd &&
                p.VacationHours == 0).Select(p => p.ProjectNo).ToArray();

            var projects = _entities.Projects.Where(p => projectNos.Contains(p.No));

            regBargeLoad = 0;
            regBargeDischarge = 0; 
            pressureBargeLoad = 0; 
            pressureBargeDischarge = 0;

            foreach (var project in projects)
            {
                if (project.Operation.Name == "LOAD")
                {
                    //regular barges
                    if (project.LDDetail.RpType == "R")
                    {
                        regBargeLoad++;
                    }
                    else if (project.LDDetail.RpType == "P")
                    {
                        pressureBargeLoad++;
                    }
                }
                else if (project.Operation.Name == "DISCHARGE")
                {
                    //regular barges
                    if (project.LDDetail.RpType == "R")
                    {
                        regBargeDischarge++;
                    }
                    else if (project.LDDetail.RpType == "P")
                    {
                        pressureBargeDischarge++;
                    }
                }
            }
        }

        [HttpGet]
        [Authorize(Roles = "HR_EmployeeMaintenance")]
        public ActionResult Stats(Guid employeeId)
        {
            var model = new BigBlue2.Web.Models.Employees.StatsModel();

            int lastYear = DateTime.Now.Year - 1;

            var query = _entities.EmployeeLoadDischargeStats.Where(s => s.EmployeeId == employeeId);

            int? maxYear;

            if (query.Any())
            {
                maxYear = query.Max(s => s.Year);
            }
            else
            {
                maxYear = lastYear - 6;
            }

            int loadDlTotal, dischargeDlTotal, loadLfgTotal, dischargeLfgTotal;

            while (maxYear < lastYear)
            {
                var stat = _entities.EmployeeLoadDischargeStats.Create();

                maxYear++;

                CalculateTotals(maxYear.Value, employeeId, out loadDlTotal, out dischargeDlTotal,
                    out loadLfgTotal, out dischargeLfgTotal);

                stat.EmployeeId = employeeId;
                stat.Year = maxYear.Value;
                stat.FullName = _entities.Employees.Find(employeeId).FullName;
                stat.DischargeDlTotal = dischargeDlTotal;
                stat.DischargeLfgTotal = dischargeLfgTotal;
                stat.LoadDlTotal = loadDlTotal;
                stat.LoadLfgTotal = loadLfgTotal;
                stat.UpdatedBy = "BigBlue";

                _entities.EmployeeLoadDischargeStats.Add(stat);
            }
            _entities.SaveChanges();

            CalculateTotals(DateTime.Now.Year, employeeId, out loadDlTotal, out dischargeDlTotal,
                    out loadLfgTotal, out dischargeLfgTotal);

            model.CurrentYearDlDischarges = dischargeDlTotal;
            model.CurrentYearDlLoads = loadDlTotal;
            model.CurrentYearLfgDischarges = dischargeLfgTotal;
            model.CurrentYearLfgLoads = loadLfgTotal;
            model.CurrentYear = DateTime.Now.Year;

            model.Stats = query.OrderByDescending(s => s.Year);

            model.EmployeeName = query.First().FullName;

            return View(model);
        }

        [HttpGet]
        [Authorize(Roles = "HR_EmployeeMaintenance")]
        public ActionResult Terminate(Guid id)
        {
            var employee = _entities.Employees.SingleOrDefault(e => e.Id == id);

            employee.TermDate = DateTime.Now;
            

            if (employee == null)
            {
                return RedirectToAction("Index");
            }

            return View(employee);
        }

        [HttpPost]
        [Authorize(Roles = "HR_EmployeeMaintenance")]
        public ActionResult Terminate(TerminateInput input)
        {
            if (ModelState.IsValid)
            {
                var employee = _entities.Employees.Single(e => e.Id == input.Id);

                employee.TermDate = input.TermDate;
                employee.TermReason = input.TermReason;
                employee.DateUpdated = DateTime.Now;
                employee.UpdatedBy = User.Identity.Name;
                employee.IsActive = false;
                employee.GuaranteedHours = 0;
                _entities.SaveChanges();

                return RedirectToAction("Index");
            }

            return Terminate(input.Id);
        }

        public ActionResult Schedule()
        {
            return RedirectToAction("Schedule", "Tankerman");
        }

        public ActionResult Status()
        {
            return RedirectToAction("Status", "Tankerman");
        }

        //
        // GET: /Employees/
        //[HttpGet]
        //[Authorize(Roles = "Tankerman")]
        //public ActionResult Status()
        //{
        //    var userName = Membership.GetUser().UserName;
        //    var employee = _entities.Employees.SingleOrDefault(e => e.UserName == userName);

        //    if (employee == null)
        //    {
        //        return RedirectToAction("Index", "Home");
        //    }

        //    var bigBoard = _entities.BigBoardLives.SingleOrDefault(b => b.EmployeeId == employee.Id);

        //    var model = new StatusModel();

        //    model.EmployeeName = employee.FullName;

        //    if (String.IsNullOrEmpty(bigBoard.ProjectNo))
        //    {
        //        model.AssignedToProject = false;
        //        model.RotationNo = bigBoard.RotationNo;

        //        if (bigBoard.RotationNo == "800")
        //        {
        //            model.StatusMessage = "You are not currently assigned to a project. You are off.";
        //        }
        //        else
        //        {
        //            model.StatusMessage = String.Format("You are not currently assigned to a project. You are #{0} in the rotation.",
        //                bigBoard.RotationNo);
        //        }
        //    }
        //    else
        //    {
        //        var project = _entities.Projects.Single(p => p.No == bigBoard.ProjectNo);

        //        var ldDetail = project.ProjectWorkOrders.First().LDDetails.First();

        //        model.StatusMessage = String.Format("You are currently assigned to {0}", bigBoard.ProjectName);

        //        model.Boat = project.Boat.Name;
        //        model.Location = project.Location.Name;
        //        model.MaxDraft = ldDetail.MaxDraft;
        //        model.Operation = ldDetail.ProjectWorkOrder.Operation.Name;
        //        model.Port = project.Port.Name;
        //        model.Product = project.Product;
        //        model.ProjectNo = project.No;
        //        model.Dock = project.DockNumber;

        //        model.AssignedToProject = true;
        //        model.PrimaryBarge = ldDetail.PrimaryBarge;

        //        var tankermanTime = _entities.TankermanTimes.Where(t => t.EmployeeId == employee.Id &&
        //            t.ProjectNo == project.No).SingleOrDefault();

        //        if (tankermanTime != null)
        //        {
        //            model.BargeConfirmed = true;
        //            model.PrimaryBarge = tankermanTime.PrimaryBarge;
        //        }
        //        else
        //        {
        //            model.BargeConfirmed = false;
        //        }

        //        model.Barges = ldDetail.Barges;
        //    }

        //    return View(model);
        //}



        //[HttpPost]
        //[Authorize(Roles = "Tankerman")]
        //public ActionResult ConfirmBarge(string projectNo, Guid bargeId)
        //{
        //    var userName = Membership.GetUser().UserName;
        //    var employee = _entities.Employees.SingleOrDefault(e => e.UserName == userName);

        //    if (employee == null)
        //    {
        //        return RedirectToAction("Index", "Home");
        //    }

        //    var time = new TankermanTime();

        //    time.EmployeeId = employee.Id;
        //    time.ProjectNo = projectNo;
        //    time.PrimaryBargeId = bargeId;

        //    var project = _entities.Projects.Single(p => p.No == projectNo);
        //    var barge = _entities.Barges.Single(b => b.Id == bargeId);

        //    _emailer.Send(_messageFactory.BuildMessage(employee, project, barge));

        //    _entities.TankermanTimes.Add(time);
        //    _entities.SaveChanges();

        //    return RedirectToAction("Status");
        //}
    }
}
