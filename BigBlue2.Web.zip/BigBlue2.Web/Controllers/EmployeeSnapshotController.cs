﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using BigBlue2.Services.Account;

namespace BigBlue2.Web.Controllers
{
    public class EmployeeSnapshotController : Controller
    {

        public ActionResult Index()
        {
            //This view will contain a list of employees to run the snapshot against.
            //Models.EmployeeSnapshot.employeeList el = new Models.EmployeeSnapshot.employeeList();
            //using (BigBlueEntities bbe = new BigBlueEntities())
            //{
            //    el.employeeSummary = bbe.EmployeeSummaries.Where(q1 => (q1.DepartmentCode == "TANKERMAN" || q1.DepartmentCode == "LEAD") && q1.IsActive).ToList();
            //}
            //return View(el);

            Models.EmployeeSnapshot.employeeList el = new Models.EmployeeSnapshot.employeeList();

            BigBlueEntities bbe = new BigBlueEntities();
            
                el.tankerManGroups = bbe.EmployeeSummaries.Where(q1 => (q1.DepartmentCode == "TANKERMAN" || q1.DepartmentCode == "LEAD") && q1.IsActive).GroupBy(q1 => q1.TankermanGroup);
            
            return View(el);
        }

        public ActionResult Details(System.Guid Id, string start_dt, string end_dt)
        {
            //This should pull up the employee snap shot report.
            Models.EmployeeSnapshot.SnapshotDetails ssd = new Models.EmployeeSnapshot.SnapshotDetails();
            ssd.employeeId = Id;
            List<Models.EmployeeSnapshot.QPEStageData> qpeDataList = new List<Models.EmployeeSnapshot.QPEStageData>();
            ssd.QPEStages = new List<Models.EmployeeSnapshot.QPEStageData>();
            ssd.SafetyAudits = new List<Models.EmployeeSnapshot.safetyAudits>();
            ssd.startDate = System.DateTime.Now.AddYears(-1); ssd.endDate = System.DateTime.Now;
            if (start_dt == null)
                ssd.startDate = System.DateTime.Now.AddYears(-1);
            else
            {
                try
                {
                    ssd.startDate = Convert.ToDateTime(start_dt);
                }
                catch { ssd.startDate = System.DateTime.Now.AddYears(-1); }
            }
            if (end_dt == null)
                ssd.endDate = System.DateTime.Now;
            else{
                try
                {
                    ssd.endDate = Convert.ToDateTime(end_dt);
                }
                catch { ssd.endDate = System.DateTime.Now.AddYears(-1); }
            }

            using (BigBlueEntities bbe = new BigBlueEntities())
            {
                EmployeeSummary es = bbe.EmployeeSummaries.Where(q1 => q1.Id == Id).FirstOrDefault();

                if (es == null)
                    ssd.FullName = "NONE";
                else
                    ssd.FullName = es.FullName;
                List<BigBlue2.Data.NonConformance> ncList = bbe.NonConformances.Where(q1 => q1.EmployeeId == Id || q1.EmployeeId2 == Id || q1.EmployeeId3 == Id || q1.EmployeeId4 == Id).Where(q1 => q1.DateCreated>=ssd.startDate && q1.DateCreated <= ssd.endDate).ToList();
                foreach (BigBlue2.Data.NonConformance ncItem in ncList)
                {
                    
                    Models.EmployeeSnapshot.QPEStageData qpeItem = new Models.EmployeeSnapshot.QPEStageData();
                    qpeItem.QPEid = ncItem.Id;
                    qpeItem.createDate = ncItem.DateCreated;
                    if (ncItem.QPECategories.Count()>0 && ncItem.QPECategories.First().Stage1QPECategory != null)
                        qpeItem.QPEStage1 = ncItem.QPECategories.First().Stage1QPECategory.Name;
                    else
                        qpeItem.QPEStage1 = "NONE";
                    if (ncItem.QPECategories.Count() > 0 && ncItem.QPECategories.First().Stage2QPECategory != null)
                        qpeItem.QPEStage2 = ncItem.QPECategories.First().Stage2QPECategory.Name;
                    else
                        qpeItem.QPEStage2 = "NONE";
                    if (ncItem.QPECategories.Count() > 0 && ncItem.QPECategories.First().Stage3QPECategory != null)
                        qpeItem.QPEStage3 = ncItem.QPECategories.First().Stage3QPECategory.Name;
                    else
                        qpeItem.QPEStage3 = "NONE";
                    ssd.QPEStages.Add(qpeItem);
                }

                getSafetyAudits(ref ssd, Id, ssd.startDate, ssd.endDate);
                getAttaBoys(ref ssd, Id, ssd.startDate, ssd.endDate);
                getEmployeeOverrides(ref ssd, Id, ssd.startDate, ssd.endDate);
                getTraineeReviews(ref ssd, Id, ssd.startDate, ssd.endDate);
            }
            return View(ssd);
        }

        public ActionResult QPEDetails(int Id)
        {
            BigBlue2.Web.Models.EmployeeSnapshot.QPEDetails qpe = new Models.EmployeeSnapshot.QPEDetails();
            using (BigBlueEntities bbe = new BigBlueEntities())
            {
                //Display all the details associated with this QPEEvent
                BigBlue2.Data.NonConformance nc = bbe.NonConformances.Where(q1 => q1.Id == Id).FirstOrDefault();
                qpe.barge = nc.Barge.Name;
                qpe.boat = nc.Boat.Name;
                qpe.comments = new List<Models.EmployeeSnapshot.QPEComments>();
                foreach (var i in nc.Comments)
                    qpe.comments.Add(new Models.EmployeeSnapshot.QPEComments { comments = i.Comment, createdBy = i.CreatedBy, dateTime = i.DateCreated });
                //Going to have to punt on corrective actions. I don't see them being used just yet.
                qpe.correctiveActions = new List<Models.EmployeeSnapshot.QPECorrectiveActions>();
                qpe.createdBy = nc.CreatedBy;
                qpe.customer = nc.Customer.Name;
                qpe.customerComplaint = nc.CustomerComplaint;
                qpe.dateCreated = nc.DateCreated;
                qpe.dateTime = nc.Date;
                qpe.description = nc.Description;
                qpe.employee = nc.Employee.FullName;
                qpe.id = Id;
                //I don't see these being used. Immediate actions
                qpe.immediateActions = new List<Models.EmployeeSnapshot.QPEImmediateActions>();

                qpe.location = nc.Location.Name;
                if (nc.non_issue == null) 
                    qpe.nonIssue = false;
                else
                    qpe.nonIssue = nc.non_issue.Value;
                qpe.notifications = new List<Models.EmployeeSnapshot.QPENotifications>();
                foreach (var i in nc.Notifications)
                    qpe.notifications.Add(new Models.EmployeeSnapshot.QPENotifications { company = i.Company, dateNotified = i.DateNotified, notifiedBY = i.CreatedBy, personContacted = i.PersonContacted });
                qpe.operation = nc.Operation.Name;
                qpe.port = nc.Port.Name;
                qpe.product = nc.ProductName;
                qpe.project_no = nc.ProjectNo;
                qpe.projectLocation = nc.ProjectLocation.Name;
                qpe.routingList = new Models.EmployeeSnapshot.QPEroutingList();
                qpe.routingList.AccountingPayroll = nc.AccountingPayroll;
                qpe.routingList.dispatch = nc.Dispatch;
                qpe.routingList.ExeVP = nc.ExecVp;
                qpe.routingList.LAFieldSup = nc.ExecVp;
                qpe.routingList.OPSMgr = nc.OpsMgr;
                qpe.routingList.SafetyTraingComp = nc.SafetyTrainingComp;
                qpe.routingList.TXFieldSup = nc.TxFieldSup;
                qpe.routingList.VPAdmin = nc.VpAdmin;
                qpe.routingList.VPOps = nc.VpOps;
                if (nc.QPECategories.Count() > 0)
                {
                    qpe.stage1Categories = nc.QPECategories.First().Stage1QPECategory.Name;
                    qpe.stage2Categories = nc.QPECategories.First().Stage2QPECategory.Name;
                    qpe.stage3Categories = nc.QPECategories.First().Stage3QPECategory.Name;
                }
                else
                {
                    qpe.stage1Categories = "NONE"; qpe.stage2Categories = "NONE"; qpe.stage3Categories = "NONE";
                }
                qpe.IsClosed = nc.IsClosed;
                qpe.vendor = "None";
                if (nc.Vendor != null)
                    qpe.vendor = nc.Vendor.Name;
               
            }

            return View(qpe);
        }

        public ActionResult SAEDetails(int Id)
        {
            //Desplay all the details associated with this Safety Audit
            return View();
        }

        public ActionResult OREDetails(int Id)
        {
            //Desplay all the details associated with this Override details
            Models.EmployeeSnapshot.employeeOverridesDetails erd = new Models.EmployeeSnapshot.employeeOverridesDetails();
            using (BigBlueEntities bbe = new BigBlueEntities())
            {
                List<BigBlue2.Data.EmployeeScheduleOverride> eso = bbe.EmployeeScheduleOverrides.Where(q1 => q1.sch_auto_id == Id).ToList();

                if (eso.Count() > 0)
                {
                    erd.comments = eso.First().comments;
                    erd.created_by = eso.First().create_user;
                    erd.employee = eso.First().Employee.FullName;
                    erd.end_dt = eso.First().end_dt;
                    int? tempReasonId = eso.First().override_reason.Value;
                    if (tempReasonId != null)
                        erd.overrideType = bbe.EmployeeOverrideTypes.Where(q1 => q1.reason_id == tempReasonId).FirstOrDefault().reason_desc;
                    else
                        erd.overrideType = "NONE";
                    erd.start_dt = eso.First().start_dt;
                    erd.update_by = eso.First().update_user;
                    erd.rotation_override = eso.First().rotation_override;
                }

            }
            return View(erd);
        }

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //Safety Audit Details.
        public ActionResult SADetails(int id)
        {
            return View();
        }

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }


        public ActionResult Delete(int id)
        {
            return View();
        }

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        private void getAttaBoys(ref Models.EmployeeSnapshot.SnapshotDetails es, Guid emp_id, DateTime start_dt, DateTime end_dt)
        {
            es.Attaboys = new List<Models.EmployeeSnapshot.Attaboys>();

            using (BigBlue2.Data.BigBlueEntities bbe = new BigBlueEntities())
            {
                List<BigBlue2.Data.Attaboy> abList = bbe.Attaboys.Where(q1 => q1.EmployeeId == emp_id && q1.DateCreated >= start_dt && q1.DateCreated <= end_dt).ToList();

                foreach (BigBlue2.Data.Attaboy abItem in abList)
                {
                    Models.EmployeeSnapshot.Attaboys esItem = new Models.EmployeeSnapshot.Attaboys();
                    esItem.attaboyID = abItem.Id;
                    esItem.createDate = abItem.DateCreated;
                    esItem.createdBy = abItem.CreatedBy;
                    esItem.description = abItem.Description;

                    es.Attaboys.Add(esItem);
                }

            }
        }

        private void getSafetyAudits(ref Models.EmployeeSnapshot.SnapshotDetails es, Guid emp_id, DateTime start_dt, DateTime end_dt)
        {
            using (BigBlue2.Data.BigBlueEntities bbe = new BigBlueEntities())
            {
                List<BigBlue2.Data.SafetyAudit> saList = bbe.SafetyAudits.Where(q1 => q1.EmployeeId == emp_id && q1.DateCreated >= start_dt && q1.DateCreated <= end_dt).ToList();
                foreach (BigBlue2.Data.SafetyAudit saItem in saList)
                {

                    Models.EmployeeSnapshot.safetyAudits ssItem = new Models.EmployeeSnapshot.safetyAudits();
                    ssItem.safetyAuditID = saItem.Id;
                    BigBlue2.Data.Project p = bbe.Projects.Where(q1 => q1.No == saItem.ProjectNo).FirstOrDefault();
                    if (p != null)
                        ssItem.bargeName = p.PrimaryBarge.Name;
                    else
                        ssItem.bargeName = "Unknown project {" + saItem.ProjectNo + "}";
                    ssItem.createDate = saItem.DateCreated;
                    //Loop through all of the PPE Stuff.
                    ssItem.PPEUs = string.Empty;
                    SafetyAuditsProperPPE saItemPPE = bbe.SafetyAuditsProperPPEs.Where(q1 => q1.Id == saItem.ProperPPEId).FirstOrDefault();
                    ssItem.PPEUs = string.Empty;
                    bool anyUs = false;
                    if (saItemPPE.EyeFaceRating == "U")
                    { ssItem.PPEUs += "Eye Face "; anyUs = true; }
                    if (saItemPPE.FootRating == "U")
                    { ssItem.PPEUs += "Foot "; anyUs = true; }
                    if (saItemPPE.H2SRating == "U")
                    { ssItem.PPEUs += "H2S "; anyUs = true; }
                    if (saItemPPE.HandRating == "U")
                    { ssItem.PPEUs += " Hand "; anyUs = true; }
                    if (saItemPPE.HardHatRating == "U")
                    { ssItem.PPEUs += "Hard Hat "; anyUs = true; }
                    if (saItemPPE.HearingRating == "U")
                    { ssItem.PPEUs += "Hearing "; anyUs = true; }
                    if (saItemPPE.PfdRating == "U")
                    { ssItem.PPEUs += "PFD "; anyUs = true; }
                    if (saItemPPE.RespiratoryRating == "U")
                    { ssItem.PPEUs += "Respiratory "; anyUs = true; }
                    if (saItemPPE.SkinRating == "U")
                    { ssItem.PPEUs += "Skin "; anyUs = true; }
                    if (!anyUs)
                        ssItem.PPEUs = "NO Us";

                    //Transfer Opertions safety audit ratings
                    anyUs = false;
                    ssItem.TransferUs = string.Empty;
                    SafetyAuditsTransferOperation saItemTrans = bbe.SafetyAuditsTransferOperations.Where(q1 => q1.Id == saItem.TransferOperationId).FirstOrDefault();
                    ssItem.TransferUs = string.Empty;
                    if (saItemTrans.AccessLightingRating == "U")
                    { ssItem.TransferUs += "Access Lighting "; anyUs = true; }
                    if (saItemTrans.BargeTransferKnowledgeRating == "U")
                    { ssItem.TransferUs += "Barge Transfer Knowledge "; anyUs = true; }
                    if (saItemTrans.DoiDocumentationRating == "U")
                    { ssItem.TransferUs += "DOI Documentation "; anyUs = true; }
                    if (saItemTrans.FireExtinguishersRating == "U")
                    { ssItem.TransferUs += "Fire Extinguisher "; anyUs = true; }
                    if (saItemTrans.GroundCableRating == "U")
                    { ssItem.TransferUs += "Ground Cable "; anyUs = true; }
                    if (saItemTrans.MooringRating == "U")
                    { ssItem.TransferUs += "Mooring "; anyUs = true; }
                    if (saItemTrans.PlanOfActionRating == "U")
                    { ssItem.TransferUs += "Plan of action"; anyUs = true; }
                    if (saItemTrans.SpillContainmentKitRating == "U")
                    { ssItem.TransferUs += "Spill Containmentaion Kit "; anyUs = true; }
                    if (saItemTrans.TrimListStabilityRating == "U")
                    { ssItem.TransferUs += "Trim List Stability "; anyUs = true; }
                    if (!anyUs)
                        ssItem.TransferUs = "NO Us";

                    //Work practices safety audit ratings
                    ssItem.WorkPracticesUs = string.Empty;
                    SafetyAuditsWorkPractice saItemWP = bbe.SafetyAuditsWorkPractices.Where(q1 => q1.Id == saItem.WorkPracticeId).FirstOrDefault();
                    ssItem.WorkPracticesUs = string.Empty;
                    if (saItemWP.CredentialsTwicMmcRating == "U")
                    { ssItem.WorkPracticesUs += "Credentials TWIC MMC "; anyUs = true; }
                    if (saItemWP.FlashlightRating == "U")
                    { ssItem.WorkPracticesUs += "Flash Light "; anyUs = true; }
                    if (saItemWP.HouseKeepingRating == "U")
                    { ssItem.WorkPracticesUs += "House Keeping "; anyUs = true; }
                    if (saItemWP.PersonalAppearanceRating == "U")
                    { ssItem.WorkPracticesUs += "Personal Appearance "; anyUs = true; }
                    if (saItemWP.ProfessionalAttitudeRating == "U")
                    { ssItem.WorkPracticesUs += "Professional Attitude "; anyUs = true; }
                    if (saItemWP.SafeAttitudeRating == "U")
                    { ssItem.WorkPracticesUs += "Safe Attitude "; anyUs = true; }
                    if (saItemWP.SecurityAttentivenessRating == "U")
                    { ssItem.WorkPracticesUs += "Security Attentiveness "; anyUs = true; }
                    if (saItemWP.TankermanLogbookRating == "U")
                    { ssItem.WorkPracticesUs += "Tankerman Log Book "; anyUs = true; }
                    if (saItemWP.ToolsRating == "U")
                    { ssItem.WorkPracticesUs += "Tools "; anyUs = true; }
                    if (!anyUs)
                        ssItem.WorkPracticesUs = "NO Us";
                    es.SafetyAudits.Add(ssItem);
                }
            }

        }

        private void getEmployeeOverrides(ref Models.EmployeeSnapshot.SnapshotDetails es, Guid emp_id, DateTime start_dt, DateTime end_dt)
        {
            es.overrides = new List<Models.EmployeeSnapshot.OverRides>();

            using (BigBlueEntities bbe = new BigBlueEntities())
            {
                List<BigBlue2.Data.EmployeeScheduleOverride> esoList = bbe.EmployeeScheduleOverrides.Where(q1 => q1.employee_row_id == emp_id && q1.create_dt>= start_dt && q1.create_dt <= end_dt).ToList();

                foreach (BigBlue2.Data.EmployeeScheduleOverride esoItem in esoList)
                {
                    Models.EmployeeSnapshot.OverRides orItem = new Models.EmployeeSnapshot.OverRides();
                    orItem.details = esoItem.comments;
                    orItem.overrideID = esoItem.sch_auto_id;
                    orItem.createDate = esoItem.create_dt.GetValueOrDefault();
                    int? tempReasonId = esoItem.override_reason.Value;
                    if (tempReasonId != null)
                        orItem.overrideType = bbe.EmployeeOverrideTypes.Where(q1 => q1.reason_id == tempReasonId).FirstOrDefault().reason_desc;
                    else
                        orItem.overrideType = "NONE";
                    es.overrides.Add(orItem);
                }

            }
        }

        private void getTraineeReviews(ref Models.EmployeeSnapshot.SnapshotDetails es, Guid emp_id, DateTime start_dt, DateTime end_dt)
        {
            es.trainingReviews = new List<Models.EmployeeSnapshot.trainReviews>();
            using (BigBlueEntities bbe = new BigBlueEntities())
            {
                List<BigBlue2.Data.TraineeReview> trainingList = bbe.TraineeReviews.Where(q1 => q1.TraineeEmployeeId == emp_id && q1.DateOfReview >= start_dt && q1.DateOfReview <= end_dt).ToList();

                foreach (BigBlue2.Data.TraineeReview trainingItem in trainingList)
                {
                    Models.EmployeeSnapshot.trainReviews esTraining = new Models.EmployeeSnapshot.trainReviews();
                    esTraining.trainingReviewId = trainingItem.Id;
                    esTraining.created_by = trainingItem.CreatedBy;
                    esTraining.operation = trainingItem.Project.Operation.Name;
                    esTraining.product = trainingItem.Project.Product;
                    esTraining.project_no = trainingItem.ProjectNo;
                    esTraining.review_dt = trainingItem.DateOfReview;
                    esTraining.facility = trainingItem.Project.Facility;

                    es.trainingReviews.Add(esTraining);
                }

            }
        }
    }
}
