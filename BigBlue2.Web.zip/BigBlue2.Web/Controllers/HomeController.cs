﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using BigBlue2.Services.Email;

namespace BigBlue2.Web.Controllers
{
    [Authorize]
    [BigBlue2.Web.Controllers.PolicyCheck]
    public class HomeController : Controller
    {
        private readonly BigBlueEntities _entities;
        private readonly IEmailer _emailer;

        public HomeController(BigBlueEntities entities, IEmailer emailer)
        {
            _entities = entities;
             _emailer = emailer;
        }


        public ActionResult Index()
        {
            
            using (BigBlueEntities ent = new BigBlueEntities())
            {
                if (User.IsInRole("Tankerman") && ent.Employees.Any(e => e.UserName == User.Identity.Name))
                {
                    return RedirectToAction("Status", "Employees");
                }
            }
            
            

            return View();
        }

        [Authorize]
        public ActionResult Feedback()
        {
            return View();
        }

        [HttpPost]
        [Authorize]
        [ValidateInput(true)]
        public ActionResult Feedback(string type, string message)
        {
            if (ModelState.IsValid)
            {
                System.Net.Mail.MailMessage mm = new System.Net.Mail.MailMessage()
                {
                    Body = createFeedbackBody(type, message),
                    Subject = "Employee Portal Feedback from " + User.Identity.Name,
                    IsBodyHtml = true
                };
                var c = _entities.Configs.Where(x => x.Id == "FEEDBACK_EMAIL").FirstOrDefault();
                if (c != null && c.Value != null && c.Value == string.Empty)
                {
                    mm.To.Add("bforet@accutransinc.com");
                    mm.Subject += "<br /> No email address found...defaulting to bforet@accutransinc.com when nothing found";
                }
                else
                    mm.To.Add(c.Value);
                mm.From = new System.Net.Mail.MailAddress("Dispatch@accutransinc.com", User.Identity.Name + "@employees.accutransportal.com");

                if (message.Length > 0)
                    _emailer.Send(mm);
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return View();
            }
        }

        private string createFeedbackBody(string feedbacktype, string feedbackmessage)
        {
            return "<b>" + feedbacktype + "</b> feedback was sent by " + User.Identity.Name + " on " + DateTime.Now.ToString("MM/dd/yy HH:mm") + ".  The message is below  <br /><br />" +
                "''" + System.Net.WebUtility.HtmlDecode(feedbackmessage.Replace("<[^>]*(>|$)", "")) + "''";
        }

    }
}
