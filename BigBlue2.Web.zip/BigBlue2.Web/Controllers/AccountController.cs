﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Web.Models.Account;
using BigBlue2.Services.Account;
using System.Web.Security;
using BigBlue2.Data;
using BigBlue2.Services;

namespace BigBlue2.Web.Controllers
{
    public class AccountController : Controller
    {
        private readonly IMembershipService _membershipService;
        private readonly BigBlueEntities _entities;
        private readonly IEmployeeAccountCreator _accountCreator;

        public AccountController(IMembershipService membershipService, BigBlueEntities entities,
            IEmployeeAccountCreator accountCreator)
        {
            _membershipService = membershipService;
            _entities = entities;
            _accountCreator = accountCreator;
        }

        [HttpGet]
        [Authorize]
        public ActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        [Authorize]
        public ActionResult ChangePassword(ChangePasswordInput input)
        {
            if (ModelState.IsValid)
            {
                if (!Membership.GetUser().ChangePassword(input.CurrentPassword, input.NewPassword))
                {
                    ModelState.AddModelError("CurrentPassword", "Current password is incorrect");
                }
                else
                {
                    ViewBag.Message = "Password changed successfully!";
                }
            }
            return View();
        }

        public ActionResult ConfirmEmployee(Employee employee)
        {
            return View("ConfirmEmployee", employee);
        }

        [HttpGet]
        public ActionResult Create(Guid employeeId)
        {
            var employee = _entities.Employees.SingleOrDefault(e => e.Id == employeeId);

            if (employee == null)
            {
                return RedirectToAction("Login");
            }

            return View(employee);
        }

        [HttpPost]
        public ActionResult Create(CreateInput input)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var employee = _entities.Employees.Single(e => e.Id == input.EmployeeId);

                    if (String.IsNullOrEmpty(employee.UserName))
                    {
                        _accountCreator.Create(employee, input.UserName, input.Password);

                        Roles.AddUserToRole(input.UserName, "Tankerman");

                        return RedirectToAction("Login", new
                        {
                            message = "Account created successfully. You can now login with the user name and password you created."
                        });
                    }
                    else
                    {
                        _membershipService.ChangePassword(input.UserName, input.Password);

                        return RedirectToAction("Login", new
                        {
                            message = "Password changed successfully. You can now login with the new password you created."
                        });
                    }
                }
                catch (ValidationException ex)
                {
                    ModelState.AddValidationErrors(ex);
                }
            }

            return Create(input.EmployeeId);
        }

        //
        // GET: /Account/
        [HttpGet]
        public ActionResult Login(string message)
        {
            if (!String.IsNullOrEmpty(message))
            {
                ViewBag.Message = message;
            }

            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginInput input, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                if (_membershipService.ValidateUser(input.Username, input.Password))
                {
                    FormsAuthentication.SetAuthCookie(input.Username, input.StayLoggedIn);

                    var employee = _entities.Employees.GetByUserName(input.Username);

                    if (employee != null)
                    {

                        var notifications = _entities.Notifications.OfType<TankermanNotification>()
                            .Where(x=>x.IsActive)
                            .NotAcceptedBy(employee);

                        if (notifications.Any())
                        {
                            return RedirectToAction("Tankerman", "Notifications");
                        }
                    }

                    if (!String.IsNullOrEmpty(returnUrl))
                    {
                        return Redirect(returnUrl);
                    }
                    else if (Roles.IsUserInRole(input.Username, "Tankerman"))
                    {
                        return RedirectToAction("Status", "Tankerman");
                    }
                    else
                    {
                        return Redirect(FormsAuthentication.DefaultUrl);
                    }
                }
                else
                {
                    ModelState.AddModelError("Password", "Invalid username and/or password");
                }
            }

            return View();
        }

        [HttpGet]
        public ActionResult Logoff()
        {
            FormsAuthentication.SignOut();

            return RedirectToAction("Login");
        }

        [HttpGet]
        public ActionResult Register()
        {
            return View(States.Abbreviations);
        }

        [HttpPost]
        public ActionResult Register(RegisterInput input)
        {
            if (ModelState.IsValid)
            {
                var employee = _entities.Employees.SingleOrDefault(e => e.DriversLicenseNo == input.DlNumber &&
                    e.DriversLicenseState == e.DriversLicenseState
                    && e.Ssn.Substring(e.Ssn.Length - 4, 4) == input.SsnLast4 && e.TermDate == null);

                if (employee != null)
                {
                    return ConfirmEmployee(employee);
                }

                ModelState.AddModelError("", "No matching employee found. ");
            }

            return Register();
        }
    }
}
