﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using BigBlue2.Web.Models.NonConformances;
using BigBlue2.Web.Models;
using System.Web.Security;
using BigBlue2.Services;
using BigBlue2.Services.Email;
using BigBlue2.Web.Mailers;
using Mvc.Mailer;

namespace BigBlue2.Web.Controllers
{
    [Authorize(Roles = "NonConformance")]
    public class NonConformancesController : Controller
    {
        private readonly BigBlueEntities _entities;
        private readonly IQPEMailer _mailer;

        public NonConformancesController(BigBlueEntities entities, IQPEMailer mailer)
        {
            _entities = entities;
            _mailer = mailer;
        }

        [HttpPost]
        public ActionResult AddComment()
        {
            //automatical model binding not working corrrectly, binds fine with TryUpdateModel though UpdateModel throws an 
            //exception, will have to debug later
            var comment = new NonConformanceComment();
            TryUpdateModel(comment);

            _entities.NonConformanceComments.Add(comment);
            _entities.SaveChanges();

            var comments = _entities.NonConformanceComments.Where(c => c.NonConformanceId == comment.NonConformanceId &&
                c.Type == comment.Type)
                .OrderByDescending(c => c.DateCreated);

            return PartialView("Comments", comments);
        }

        [HttpPost]
        public ActionResult AddNotification()
        {
            ValidatedPartialViewModel model;

            var notification = _entities.NonConformanceNotifications.Create();

            TryUpdateModel(notification);

            if (ModelState.IsValid)
            {
                _entities.NonConformanceNotifications.Add(notification);
                _entities.SaveChanges();

                var notifications = _entities.NonConformanceNotifications
                    .Where(n => n.NonConformanceId == notification.NonConformanceId)
                    .OrderByDescending(n => n.DateCreated);

                var items = from n in notifications.ToList()
                            select new NotificationGridItem(n);

                model = new ValidatedPartialViewModel()
                {
                    IsValid = true,
                    Html = ControllerContext.RenderPartialAsString(
                        Url.Content("~/Views/NonConformances/NotificationGrid.cshtml"), items)
                };

                return Json(model);
            }

            var partialViewModel = new AddNotificationModel(notification.NonConformanceId, _entities.Customers.Active());

            model = new ValidatedPartialViewModel()
            {
                IsValid = false,
                Html = ControllerContext.RenderPartialAsString(
                    Url.Content("~/Views/NonConformances/AddNotification.cshtml"), partialViewModel)
            };

            return Json(model);
        }

        [HttpGet]
        public ActionResult Details(int id)
        {
            var nonConformance = _entities.NonConformances.SingleOrDefault(nc => nc.Id == id);
            var customers = _entities.Customers.Active();

            if (nonConformance == null)
            {
                return RedirectToAction("Index");
            }

            var stage1 = _entities.Stage1QPECategory.Active();
            var stage2 = _entities.Stage2QPECategory.Active();
            var stage3 = _entities.Stage3QPECategory.Active();
            var atfaultareas = _entities.NonConformanceFaultAreas.Where(x => x.is_active == true);
            var model = new DetailsModel(nonConformance, customers, stage1, stage2, stage3, atfaultareas);

            return View(model);
        }

        [HttpPost]
        //public ActionResult Details(int nonConformanceId, bool isClosed, bool opsMgr, bool vpOps, bool execVp, 
        //    bool vpAdmin, bool safetyTrainingComp, bool laFieldSup, bool txFieldSup, bool dispatch, 
        //    bool accountingPayroll, bool nonissue)
            public ActionResult Details(FormCollection fc)
        {
            bool sendemail = false;
            int ncId = Convert.ToInt32(fc["nonConformanceId"]);
            var nonConformance = _entities.NonConformances.Single(nc => nc.Id == ncId);

            nonConformance.OpsMgr = Convert.ToBoolean(fc["OpsMgr"]);
            nonConformance.VpOps = Convert.ToBoolean(fc["VpOps"]);
            nonConformance.ExecVp = Convert.ToBoolean(fc["ExecVp"]);
            nonConformance.VpAdmin = Convert.ToBoolean(fc["VpAdmin"]);
            nonConformance.SafetyTrainingComp = Convert.ToBoolean(fc["SafetyTrainingComp"]);
            nonConformance.LaFieldSup = Convert.ToBoolean(fc["LaFieldSup"]);
            nonConformance.TxFieldSup = Convert.ToBoolean(fc["TxFieldSup"]);
            nonConformance.Dispatch = Convert.ToBoolean(fc["Dispatch"]);
            nonConformance.AccountingPayroll = Convert.ToBoolean(fc["AccountingPayroll"]);
            nonConformance.non_issue = Convert.ToBoolean(fc["NonIssue"]);
            var currentUser = Membership.GetUser().UserName;
            var isClosed = Convert.ToBoolean(fc["IsClosed"]);
            if (nonConformance.IsClosed && isClosed == false)
            {
                nonConformance.IsClosed = false;
                nonConformance.ReopenedBy = currentUser;
                nonConformance.DateReopened = DateTime.Now;
            }
            else if (!nonConformance.IsClosed && isClosed == true)
            {
                nonConformance.IsClosed = true;
                nonConformance.ClosedBy = currentUser;
                nonConformance.DateClosed = DateTime.Now;
                sendemail = true;
            }
            var qpe = nonConformance.QPECategories;
            foreach (var q in qpe)
            {
                q.Stage1QPECategoryId = Convert.ToInt32(fc["Stage1Cat_" + q.Id]);
                q.Stage2QPECategoryId = Convert.ToInt32(fc["Stage2Cat_" + q.Id]);
                q.Stage3QPECategoryId = Convert.ToInt32(fc["Stage3Cat_" + q.Id]);
            }
            //insert any new qpe categories
            for (Int64 gennum = 10000000000; gennum < 10000000011; gennum++)
            {
                bool insert = false;
                int stage1id,stage2id,stage3id;
                stage3id = stage2id = stage1id = 0;
                foreach (var key in fc.AllKeys.Where(k => k.EndsWith(gennum.ToString())))
                {
                    insert = true;
                    if (key.Contains("Stage1") && !String.IsNullOrEmpty(fc[key]))
                        stage1id = Convert.ToInt16(fc[key]);
                    else if (key.Contains("Stage2") && !String.IsNullOrEmpty(fc[key]))
                        stage2id = Convert.ToInt16(fc[key]);
                    else if (key.Contains("Stage3") && !String.IsNullOrEmpty(fc[key]))
                        stage3id = Convert.ToInt16(fc[key]);
                }
                if (insert)
                {
                    BigBlue2.Data.QPECategory newqpe = new QPECategory();
                    if (stage1id != 0)
                        newqpe.Stage1QPECategoryId = stage1id;
                    if (stage2id != 0)
                        newqpe.Stage2QPECategoryId = stage2id;
                    if (stage3id != 0)
                        newqpe.Stage3QPECategoryId = stage3id;
                    newqpe.QPEId = nonConformance.Id;
                    _entities.QPECategories.Add(newqpe);
                }
            }

            if (!String.IsNullOrEmpty(fc["AtFaultReasonId"]))
                nonConformance.at_fault_reason_id = Convert.ToInt16(fc["AtFaultReasonId"]);
            nonConformance.accu_at_fault = (Convert.ToBoolean(fc["AccutransAtFault"]) == true) ? "YES" : "NO";
            nonConformance.cust_notified = fc["CustomerNotified"].Contains("true") ? true : false;
            _entities.SaveChanges();
            MvcMailerSmtpExtension ext = new MvcMailerSmtpExtension(new SmtpBoyEntities());
            if (sendemail)
                _mailer.QPEClosed(nonConformance).Send(ext);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Index(short? projectLocationId, Guid? customerId, Guid? employeeId, int? stage1Id, int? stage2Id, 
            int? stage3Id, string user, DateTime? startDate, DateTime? endDate, bool? customerComplaint, bool? NonIssue, string pageSize = "10", 
            string sort = "Date", string sortDir = "DESC")
        {
            if (Request.IsAjaxRequest())
            {
                var nonConformances = _entities.NonConformances as IQueryable<NonConformance>;

                if (employeeId.HasValue)
                {
                    nonConformances = nonConformances.Where(nc => nc.EmployeeId == employeeId.Value || nc.EmployeeId2 == employeeId.Value ||
                                                                    nc.EmployeeId3 == employeeId || nc.EmployeeId4 == employeeId);
                }

                if (customerId.HasValue)
                {
                    nonConformances = nonConformances.Where(nc => nc.CustomerId == customerId.Value || 
                        (nc.Project != null && nc.Project.CustomerId == customerId.Value));
                }

                if (projectLocationId.HasValue)
                {
                    nonConformances = nonConformances.Where(nc => nc.ProjectLocationId == projectLocationId.Value ||
                        (nc.Project != null && nc.Project.ProjectLocationId == projectLocationId.Value));
                }

                if (stage1Id.HasValue)
                {
                    nonConformances = nonConformances.Where(nc => 
                        nc.QPECategories.Any(c => c.Stage1QPECategoryId == stage1Id.Value));
                }

                if (stage2Id.HasValue)
                {
                    nonConformances = nonConformances.Where(nc =>
                        nc.QPECategories.Any(c => c.Stage2QPECategoryId == stage2Id.Value));
                }

                if (stage3Id.HasValue)
                {
                    nonConformances = nonConformances.Where(nc =>
                        nc.QPECategories.Any(c => c.Stage3QPECategoryId == stage3Id.Value));
                }

                if (!String.IsNullOrEmpty(user))
                {
                    nonConformances = nonConformances.Where(nc => nc.CreatedBy == user);
                }

                if (startDate.HasValue)
                {
                    nonConformances = nonConformances.Where(nc => nc.Date >= startDate.Value);
                }

                if (endDate.HasValue)
                {
                    endDate = endDate.Value.EndOfDay();
                    nonConformances = nonConformances.Where(nc => nc.Date <= endDate.Value);
                }

                if (customerComplaint.HasValue && customerComplaint.Value)
                {
                    nonConformances = nonConformances.Where(nc => nc.CustomerComplaint);
                }

                if (NonIssue.HasValue && NonIssue.Value == false)
                {
                    nonConformances = nonConformances.Where(nc => nc.non_issue == false);
                }

                var items = from nc in nonConformances.ToList()
                            select new GridItem(nc);

                var gridModel = new GridModel<GridItem>(items, pageSize == "All" ? Int32.MaxValue : Int32.Parse(pageSize), sort, 
                    sortDir);

                return PartialView("Grid", gridModel);
            }
            else
            {
                var employees = _entities.NonConformances.Select(nc => nc.Employee).Distinct()
                    .OrderBy(e => e.Contact.LastName).ThenBy(e => e.Contact.FirstName);

                var customers = _entities.NonConformances.Select(nc => nc.Customer).Distinct().OrderBy(c => c.Name);

                var stage1 = _entities.NonConformances.SelectMany(nc => nc.QPECategories)
                    .Select(c => c.Stage1QPECategory).Distinct()
                    .OrderBy(c => c.Name);

                var stage2 = _entities.NonConformances.SelectMany(nc => nc.QPECategories)
                    .Select(c => c.Stage2QPECategory).Distinct()
                    .OrderBy(c => c.Name);

                var stage3 = _entities.NonConformances.SelectMany(nc => nc.QPECategories)
                    .Select(c => c.Stage3QPECategory).Distinct()
                    .OrderBy(c => c.Name);

                var users = _entities.NonConformances.OrderBy(nc => nc.CreatedBy).Select(nc => nc.CreatedBy).Distinct();

                var projectLocations = _entities.ProjectLocations.Active();

                var nonConformances = _entities.NonConformances;

                DateTime filterdt = DateTime.Now.AddDays(-30);
                var items = from nc in nonConformances.Where(x => x.DateCreated >= filterdt).ToList()
                            select new GridItem(nc);

                var gridModel = new GridModel<GridItem>(items, pageSize == "All" ? Int32.MaxValue : Int32.Parse(pageSize), sort, sortDir);

                var model = new IndexModel(gridModel, employees, stage1, stage2, stage3, users, customers, projectLocations);

                return View(model);
            }
        }



        //[HttpPost]
        //public ActionResult UpdateRoutingList(int nonConformanceId, bool opsMgr, bool vpOps, bool execVp, bool vpAdmin,
        //    bool safetyTrainingComp, bool laFieldSup, bool txFieldSup, bool dispatch, bool accountingPayroll)
        //{
        //    try
        //    {
        //        var nonConformance = _entities.NonConformances.Single(nc => nc.Id == nonConformanceId);

        //        nonConformance.OpsMgr = opsMgr;
        //        nonConformance.VpOps = vpOps;
        //        nonConformance.ExecVp = execVp;
        //        nonConformance.VpAdmin = vpAdmin;
        //        nonConformance.SafetyTrainingComp = safetyTrainingComp;
        //        nonConformance.LaFieldSup = laFieldSup;
        //        nonConformance.TxFieldSup = txFieldSup;
        //        nonConformance.Dispatch = dispatch;
        //        nonConformance.AccountingPayroll = accountingPayroll;

        //        _entities.SaveChanges();

        //        return Content("true");
        //    }
        //    catch (Exception ex)
        //    {
        //        return Content(ex.Message);
        //    }
        //}
    }
}
