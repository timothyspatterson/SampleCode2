﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using System.Web.Security;
using BigBlue2.Web.Models.Employees;
using BigBlue2.Services.Email;
using BigBlue2.Web.Models;
using BigBlue2.Services.Employees;
using BigBlue2.Services.Validation;
using BigBlue2.Services;
using OfficeOpenXml;
using System.IO;

namespace BigBlue2.Web.Controllers
{
    [Authorize(Roles = "VacationMgmt")]
    public class TimeOffController : Controller
    {
        private BigBlue2.Data.BigBlueEntities _entities = null;
        private readonly IEmailer _emailer;

        private string _emailTo = "vacationentry@accutransinc.com";
        private string _emailFrom = "Dispatch@accutransinc.com";
        private string _emailsubject = "Time Off Request Change";

        public TimeOffController(BigBlue2.Data.BigBlueEntities entities, IEmailer emailer)
        {
            _entities = entities;
            _emailer = emailer;

        }

        public ActionResult Index(Guid? Employee, DateTime? StartDate, DateTime? EndDate, string sort = "EndDate", string sortDir = "DESC", string timeOffType = "VACATION")
        {
            if (StartDate == null) StartDate = DateTime.Now.AddDays(-14);
            if (EndDate == null) EndDate = DateTime.Now.AddYears(3);

            IQueryable<BigBlue2.Data.EmployeeTimeOff> query = _entities.EmployeeTimeOffs;

            if (Employee.HasValue)
                query = query.Where(x => x.employee_row_id == Employee);

            query = query.Where(x => x.start_dt >= StartDate && x.end_dt <= EndDate);
            query = query.Where(x => x.time_off_type == timeOffType);

            var timeoffs = from e in query.ToList() 
                            select new Models.TimeOff.IndexModel.GridItem(e);

            var gridModel = new BigBlue2.Web.Models.GridModel<Models.TimeOff.IndexModel.GridItem>(timeoffs, 0, sort, sortDir);

            if (Request.IsAjaxRequest())
            {
                return PartialView("Grid", gridModel);
            }
            else
            {
                var model = new Models.TimeOff.IndexModel()
                {
                    GridModel = gridModel,
                    FilterStartDate = StartDate.Value, 
                    FilterEndDate = EndDate.Value,
                    Employees = GetEmployeeSelectList()
                };

                return View(model);
            }
        }

        public ActionResult Create()
        {
            Models.TimeOff.VacationEntry v = new Models.TimeOff.VacationEntry();
            v.EntryDate = v.StartDate = v.EndDate = DateTime.Now;
            v.HoursPerDay = 8;
            v.UpdatedOn = DateTime.Now;
            v.UpdatedUser = User.Identity.Name;

            v.Employees = GetEmployeeSelectList();

            return View(v);
        }

        public SelectList GetEmployeeSelectList()
        {
            return new SelectList(_entities.Employees.Active().ToList(), "Id", "FullName");
            /*
            if (this.HttpContext.Cache["EmployeeSelectList"] == null)
            {
                this.HttpContext.Cache.Insert("EmployeeSelectList", new SelectList(_entities.Employees.Active().ToList(), "Id", "FullName"), null,
                    DateTime.Now.AddHours(1), System.Web.Caching.Cache.NoSlidingExpiration);
            }
            return (SelectList)this.HttpContext.Cache["EmployeeSelectList"];
             * */
        }

        [HttpPost]
        public ActionResult Create(Models.TimeOff.VacationEntry ve)
        {
            Guid newrowid = Guid.NewGuid();

            // save the fullname in the table ONLY for backgward compat, debugging, grids, and slight performance reasons.  the name is not actually used for anything 
            // as far as relationships

            var existing = _entities.EmployeeTimeOffs.Where(x => x.employee_row_id == ve.EmployeeId &&
                ((x.start_dt <= ve.StartDate && x.end_dt >= ve.StartDate) ||
                (x.start_dt <= ve.EndDate && x.end_dt >= ve.EndDate)));

            if (existing.Any())
            {
                var first = existing.First();

                var errorMessage = String.Format("{0} already has vacation scheduled from {1} to {2}",
                    first.employee_fullname, first.start_dt, first.end_dt);

                ModelState.AddModelError("StartDate", errorMessage);
                return Create();
            }

            //var emp = _entities.EmployeeContacts.Where(x=>x.EmployeeId == ve.EmployeeId).First();
            var emp = _entities.EmployeeSummaries.Where(x => x.Id == ve.EmployeeId).First();
            ve.EmployeeName = emp.FullName;

            BigBlue2.Data.EmployeeTimeOff timeoff = new EmployeeTimeOff()
            {
                row_id = newrowid,
                employee_row_id = ve.EmployeeId,
                employee_fullname = ve.EmployeeName,
                approved_by = ve.ApprovedBy,
                end_dt = ve.EndDate,
                entry_dt = DateTime.Now,
                start_dt = ve.StartDate,
                time_off_type = "VACATION",
                total_days = ve.TotalDays,
                update_dt = DateTime.Now,
                update_user = User.Identity.Name
            };

            BigBlue2.Data.EmployeeScheduleOverride schov = new EmployeeScheduleOverride()
            {
                comments = "Vacation Request (" + emp.FullName + ")",
                create_dt = DateTime.Now,
                create_user = User.Identity.Name,
                employee_row_id = ve.EmployeeId,
                end_dt = ve.EndDate,
                start_dt = ve.StartDate,
                override_reason = 1,
                override_type = 1,
                rotation_override = "Off",
                update_dt = DateTime.Now,
                update_user = User.Identity.Name
            };

            // save to DB so you can retrieve the INT column
            _entities.EmployeeTimeOffs.Add(timeoff);
            _entities.EmployeeScheduleOverrides.Add(schov);
            _entities.SaveChanges();

            int vacationid = _entities.EmployeeTimeOffs.Where(x=>x.row_id == newrowid).First().vacation_id;
            ve.VacationNo = "VACT-" + vacationid.ToString("00000");
            DateTime startdt = ve.StartDate;
            while (startdt < ve.EndDate)
            {
                BigBlue2.Data.LaborPosting lp = new LaborPosting()
                {
                    ProjectNo = ve.VacationNo,
                    EmployeeId = ve.EmployeeId,
                    ArrivalDate = startdt,
                    DepartDate = ve.EndDate,
                    ActualHours = 0,
                    PaidHours = 0,
                    Mileage = 0,
                    DispatchHours = 0,
                    TrainingHours = 0,
                    Travel = 0,
                    IsTraining = false,
                    Inspect = 0,
                    Holiday = 0,
                    NonBillHours = 0,
                    Other = 0,
                    SafetyHours = 0,
                    SupervisingHours = 0,
                    VacationHours = ve.HoursPerDay,
                    Comments = string.Empty,
                    CreatedBy = User.Identity.Name,
                    UpdatedBy = User.Identity.Name,
                    DateCreated = DateTime.Now,
                    DateUpdated = DateTime.Now
                };
                _entities.LaborPostings.Add(lp);
                startdt = startdt.AddDays(1);
            }
            _entities.SaveChanges();
            BigBlue2.Services.Payroll.PayrollEngine pe = new Services.Payroll.PayrollEngine();
            foreach (var lpRow in _entities.LaborPostings.Where(q1 => q1.ProjectNo == ve.VacationNo))
                pe.AddToBBPE(lpRow.Id);
            
            SendEmail(ve, false);
           

            return RedirectToAction("Index");
        }

        public ActionResult GenerateExcelFile()
        {
            var package = new ExcelPackage();

            var worksheet = package.Workbook.Worksheets.Add("EmployeeTimeOff");

            worksheet.Cells[1, 1].Value = "VacationNo";
            worksheet.Cells[1, 2].Value = "Employee";
            worksheet.Cells[1, 3].Value = "Entry Date";
            worksheet.Cells[1, 4].Value = "Start Date";
            worksheet.Cells[1, 5].Value = "End Date";
            worksheet.Cells[1, 6].Value = "Approved By";
            worksheet.Cells[1, 7].Value = "Total Days";
            worksheet.Cells[1, 8].Value = "Update User";
            worksheet.Cells[1, 9].Value = "Update Date";



            var timeoffs = _entities.EmployeeTimeOffs.OrderByDescending(x=>x.start_dt).ToList();

            for (int i = 2; i <= timeoffs.Count + 1; i++)
            {
                worksheet.Cells[i, 1].Value = "VACT-" + timeoffs[i - 2].vacation_id.ToString("00000");
                worksheet.Cells[i, 2].Value = timeoffs[i - 2].employee_fullname;
                worksheet.Cells[i, 3].Value = timeoffs[i - 2].entry_dt.ToString("MM/dd/yy HH:mm");
                worksheet.Cells[i, 4].Value = timeoffs[i - 2].start_dt.ToString("MM/dd/yy HH:mm");
                worksheet.Cells[i, 5].Value = timeoffs[i - 2].end_dt.ToString("MM/dd/yy HH:mm");
                worksheet.Cells[i, 6].Value = timeoffs[i - 2].approved_by;
                worksheet.Cells[i, 7].Value = timeoffs[i - 2].total_days;
                worksheet.Cells[i, 8].Value = timeoffs[i - 2].update_user;
                worksheet.Cells[i, 9].Value = timeoffs[i - 2].update_dt.Value.ToString("MM/dd/yy HH:mm");
                
            }

            worksheet.Cells.AutoFitColumns(0);

            return File(package.GetAsByteArray(), "application/vnd.ms-excel", "timeoff.xlsx");
        }

        public ActionResult Delete(int vid, Guid vrowid)
        {
            var v = _entities.EmployeeTimeOffs.Where(x => x.vacation_id == vid).First();
            Models.TimeOff.VacationEntry ve = new Models.TimeOff.VacationEntry()
            {
                VacationNo = "VACT-" + v.vacation_id.ToString("00000"),
                EmployeeName = v.employee_fullname,
                StartDate = v.start_dt,
                EndDate = v.end_dt,
                TotalDays = v.total_days,
                ApprovedBy = v.approved_by
            };
            //_entities.DeleteVacationEntry(vrowid, vid);
            _entities.deleteVacationEntry1(vrowid, vid);
            
            // TODO:  need to delete the associated override.

            SendEmail(ve, true);
            
            return RedirectToAction("Index");
        }

        private void SendEmail(Models.TimeOff.VacationEntry ve, bool isdelete)
        {
            System.Net.Mail.MailMessage mm = new System.Net.Mail.MailMessage()
            {
                Body = CreateVacationBody(ve, false),
                Subject = _emailsubject,
                IsBodyHtml = true
            };
            mm.To.Add(_emailTo);
            mm.From = new System.Net.Mail.MailAddress(_emailFrom);
            _emailer.Send(mm);
        }

        private string CreateVacationBody(Models.TimeOff.VacationEntry ve, bool isdelete)
        {
            string action = "ADDED";
            if (isdelete) action = "REMOVED";

            string body = "<html><body>";
            body = "A Vacation Request was recently " + action + " in the BigBlue system by [" + User.Identity.Name + "] on [" + System.DateTime.Now + "]<br><br>";
            if (isdelete)
                body += "Project: " + "VACT-" + ve.VacationNo + "<br />";
            body += "Employee:  " + ve.EmployeeName + "<br>";
            body += "Start Date:  " + ve.StartDate + "<br>";
            body += "End Date:  " + ve.EndDate + "<br>";
            body += "Total Days:  " + ve.TotalDays + "<br>";
            body += "Approved By:  " + ve.ApprovedBy + "<br>";
            body += "Hours: " + ve.HoursPerDay + "<br>";
            body += "</body></html>";
            return body;
        }

        private List<Guid> GetA()
        {
            List<Guid> includeids = new List<Guid>();

            // include all active employees

            // include all accutrans only

            // include all non-dispatch

            return includeids;
        }

        // only include active employees
        // only include Accutrans (cpny id 1) employees
        // do not include office and/or dispatch (per brandon 12/2012)
        private List<Guid> getIncludedEmployees()
        {
            List<Guid> ids = new List<Guid>();
            var list = _entities.Employees.Active();
            foreach (var x in list)
            {
                if (x.CompanyId == 1 && x.DepartmentCode != "DSPT" && x.DepartmentCode != "OFFICE")
                {
                    ids.Add(x.Id);
                }
            }

            return ids;
        }


        [Authorize(Roles="Calendar")]
        public ActionResult Calendar(DateTime? StartDate, DateTime? EndDate)
        {

            List<Models.TimeOff.CalendarDayModel> days = new List<Models.TimeOff.CalendarDayModel>();

            if (StartDate == null) StartDate = DateTime.Now;
            if (EndDate == null) EndDate = DateTime.Now.AddDays(3);


            List<Guid> includedEE = getIncludedEmployees();

            IQueryable<BigBlue2.Data.EmployeeTimeOff> query = _entities.EmployeeTimeOffs;
            query = query.Where(x => x.start_dt >= StartDate && x.start_dt <= EndDate && includedEE.Contains(x.employee_row_id) );
            
            List<BigBlue2.Data.EmployeeTimeOff> eetimeoffs = query.ToList();
            DateTime tstart = StartDate.Value;
            while (tstart <= EndDate)
            {
                var c = new Models.TimeOff.CalendarDayModel() { DayName = tstart.DayOfWeek.ToString(), EffectiveDate = tstart };

                // check to see if any employees have time off on that day
                var ees = eetimeoffs.Where(x => x.start_dt <= tstart && x.end_dt >= tstart);

                Models.TimeOff.EmployeeDayEvent eday = new Models.TimeOff.EmployeeDayEvent();
                foreach (var ee in ees)
                {
                    eday = new Models.TimeOff.EmployeeDayEvent();
                    eday.Name = ee.employee_fullname;
                    eday.PermGroup = ee.Employee.PermanentTankermanGroup.Name;
                    eday.Info1 = "Entered by: " + ee.update_user + " on " + ee.entry_dt.ToString("MM/dd/yy HH:mm");
                    eday.Info2 = "Total Days: " + ee.total_days.ToString();
                    eday.Info3 = "Approved by: " + ee.approved_by;
                    eday.InfoId = "Record Id: " + ee.vacation_id.ToString();
                    eday.InfoComments = "Time Off Type - " + ee.time_off_type;
                    eday.EventCode = "V";
                    c.EmployeeDays.Add(eday);
                }

                var oquery = _entities.EmployeeScheduleOverrides.Where(x => (x.start_dt <= tstart && x.end_dt >= tstart) && includedEE.Contains(x.employee_row_id));
                foreach (var ee in oquery)
                {
                    eday = new Models.TimeOff.EmployeeDayEvent();
                    eday.Name = ee.Employee.FullName;
                    eday.PermGroup = ee.Employee.PermanentTankermanGroup.Name;
                    switch (ee.override_type.Value)
                    {
                        case 1:
                            eday.EventCode = "OFF";
                            eday.EventDesc = "OFF from " + ee.start_dt.ToString("MM/dd") + " to " + ee.end_dt.ToString("MM/dd");
                            break;
                        case 2:
                            eday.EventCode = "ON";
                            eday.EventDesc = "ON from " + ee.start_dt.ToString("MM/dd") + " to " + ee.end_dt.ToString("MM/dd");
                            break;
                    }

                    eday.InfoId = "Record Id:  " + ee.sch_auto_id.ToString();
                    eday.Info1 = "Created On:  " + ee.create_dt.Value.ToString("MM/dd/yy HH:mm") + " by " + ee.create_user;
                    eday.Info2 = "Updated On:  " + ee.update_dt.ToString("MM/dd/yy HH:mm") + " by " + ee.update_user;
                    //eday.Info3 = "Overide Reason" + ee.override_reason;
                    eday.Info3 = "";
                    eday.InfoComments = ee.comments;
                    c.EmployeeDays.Add(eday);

                    if (!c.GroupingLists.Contains(eday.DisplayGrouping1)) c.GroupingLists.Add(eday.DisplayGrouping1);
                }
                
                c.EmployeeDays = c.EmployeeDays.OrderBy(x => x.Name).ToList();
                c.GroupingLists.Sort();

                days.Add(c);
                tstart = tstart.AddDays(1);
            }

            var cm = new Models.TimeOff.CalendarModel()
            {
                FilterStartDate = StartDate.Value,
                FilterEndDate = EndDate.Value,
                CalendarDays = days
            };

            
            if (Request.IsAjaxRequest())
            {
                return PartialView("dayview", cm);
            }
            else
            {
                return View(cm);
            }

           
        }

    }

}
