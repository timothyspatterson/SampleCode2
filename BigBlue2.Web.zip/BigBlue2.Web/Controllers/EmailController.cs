﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BigBlue2.Data;
using BigBlue2.Web.Mailers;
using Mvc.Mailer;
using BigBlue2.Web.Infrastructure;

namespace BigBlue2.Web.Controllers
{
    [WebApiAuthorize]
    public class EmailController : ApiController
    {
        private readonly BigBlueEntities _entities;
        private readonly IQPEMailer _mailer;
        private readonly IScheduledEmails _scheduledEmails;

        public EmailController(BigBlueEntities entities, IQPEMailer mailer, IScheduledEmails scheduledEmails)
        {
            _entities = entities;
            _mailer = mailer;
            _scheduledEmails = scheduledEmails;
        }

        [HttpPost]
        public void NotifyQPEClosed(int id)
        {
            var qpe = _entities.NonConformances.Find(id);

            if (qpe == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound, "Invalid QPE"));
            }
            else
            {
                MvcMailerSmtpExtension ext = new MvcMailerSmtpExtension(new SmtpBoyEntities());
                _mailer.QPEClosed(qpe).Send(ext);
            }
        }

        [HttpGet]
        public bool DoNotFinalizeProjectsEmail()
        {
            MvcMailerSmtpExtension ext = new MvcMailerSmtpExtension(new SmtpBoyEntities());
            _scheduledEmails.DoNotFinalizeProjects().Send(ext);

            return true;
        }
    }
}
