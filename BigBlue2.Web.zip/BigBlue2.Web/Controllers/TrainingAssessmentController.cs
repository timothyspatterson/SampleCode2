﻿using BigBlue2.Data;
using BigBlue2.Services.Account;
using BigBlue2.Web.Mailers;
using BigBlue2.Web.Models.TrainingAssement;
using BigBlue2.Web.Models.TrainingAssessment;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Data.Objects;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BigBlue2.Web.Controllers
{
    public class TrainingAssessmentController : Controller
    {
        //
        // GET: /TrainingAssessment/

        private readonly BigBlueEntities _entities;
        private readonly IMembershipService _membershipService;
        private readonly ITraineeReviewMailer _traineeReviewMailer;

        public TrainingAssessmentController(BigBlueEntities entities, IMembershipService membershipService,
            ITraineeReviewMailer traineeReviewMailer)
        {
            _entities = entities;
            _membershipService = membershipService;
            _traineeReviewMailer = traineeReviewMailer;
        }

        [HttpGet]
        public ActionResult Index()
        {
            var reviews = _entities.TrainingAssessments.OrderByDescending(r => r.DateOfAssessment);

            return View(reviews);
        }


        public ActionResult Create(Guid? employeeId, string projectNo)
        {
            IQueryable<BigBlue2.Data.EmployeeSummary> employees;
            IQueryable<Project> projects;
            ProjectSummary project;

            employees = _entities.EmployeeSummaries.Active();

                if (employeeId.HasValue && !String.IsNullOrWhiteSpace(projectNo))
                {
                    projects = _entities.EmployeeToProjects.ProjectsByEmployee(employeeId.Value);
                    project = _entities.ProjectSummaries.SingleOrDefault(p => p.ProjectNo == projectNo);

                    return View(new CreateModel(employees, projects, project));
                }
                else
                {
                    return View(new CreateModel(employees));
                }
        }


        [HttpPost]
        public ActionResult Create(CreateInput input)
        {

            if (ModelState.IsValid)
            {
                TrainingAssessment ta = _entities.TrainingAssessments.Create();
                ta.alignmentStartUp_comments = input.AlignmentStartUpComments;
                ta.alignmentStartUp_val = (int)input.AlignmentStartUp;
                ta.bir_comments = input.BIRComments;
                ta.bir_val = (int)input.BIR;
                ta.connection_comments = input.ConnectionComments;
                ta.connection_val = (int)input.Connection;
                ta.CreatedBy = User.Identity.Name;
                ta.DateCreated = input.DateOfReview;
                ta.DateOfAssessment = input.DateOfReview;
                ta.disconnection_comments = input.DisconnectionComments;
                ta.disconnection_val = (int)input.Disconnection;

                ta.finishShutdown_comments = input.FinishShutdownComments;
                ta.finishShutdown_val = (int)input.FinishShutdown;
                ta.fir_comments = input.FIRComments;
                ta.fir_val = (int)input.FIR;
                ta.knowledge_comments = input.Knowledge;
                ta.lineClearing_comments = input.LineClearingComments;
                ta.lineClearing_val = (int)input.LineClearing;
                ta.makeReady_comments = input.MakeReadyComments;
                ta.makeReady_val = (int)input.MakeReady;
                ta.midtransfer_comments = input.MidTransferComments;
                ta.midtransfer_val = (int)input.MidTransfer;
                ta.mooring_val = (int)input.Mooring;
                ta.morring_comments = input.MooringComments;
                ta.ppe_comments = input.PPEComments;
                ta.ppe_val = (int)input.PPE;
                ta.preparedness_val = (int)input.Preparedness;
                ta.pretransfer_comments = input.PreTransferComments;
                ta.pretransfer_val = (int)input.PreTransfer;
                ta.professionalism_val = (int)input.Professionalism;

                //ta.Project = input.pr
                ta.ProjectNo = input.ProjectNo;
                ta.punctual_val = (int)input.Punctual;
                ta.retention_comments = input.Retention;
                ta.skillLevel_comments = input.SkillLevel;
                ta.safety_comments = input.SafetyComments;
                ta.safety_val = (int)input.Safety;
                ta.TraineeEmployeeId = input.TraineeEmployeeId;
                ta.TrainerEmployeeId = input.TrainerEmployeeId;
                ta.workethic_val = (int)input.WorkEthic;

                ta.LoadDischarge = (int)input.LoadDischarge;
                ta.OpenClose = (int)input.OpenClose;
                ta.SingleDouble = (int)input.SingleDouble;
                ta.SubOSubD = (int)input.SubOSubD;
                ta.SplitStraight = (int)input.SplitStraight;
                ta.LGDL = (int)input.LGDL;

                _entities.TrainingAssessments.Add(ta);
                try
                {
                    _entities.SaveChanges();
                }
                catch (DbEntityValidationException e)
                {
                    foreach (var eve in e.EntityValidationErrors)
                    {
                        Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                            eve.Entry.Entity.GetType().Name, eve.Entry.State);
                        foreach (var ve in eve.ValidationErrors)
                        {
                            Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                                ve.PropertyName, ve.ErrorMessage);
                        }
                    }
                    throw;
                }
                return RedirectToAction("Index");
            }
            else
            {
                return Create(input.TraineeEmployeeId, input.ProjectNo);
            }
        }

        [HttpPost]
        public JsonResult GridData(string sidx, string sord, int page, int rows, string fullName, string projectNo,
            string facility, string operation, string product, DateTime? dateOfReview, string createdBy)
        {
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            int totalRecords = _entities.TrainingAssessments.Count();
            int totalPages = (int)Math.Ceiling((float)totalRecords / (float)pageSize);

            var query = _entities.TrainingAssessments.AsQueryable();

            if (!String.IsNullOrEmpty(fullName))
            {
                query = query.Where(r => r.Employee.Contact.FirstName.StartsWith(fullName) ||
                    r.Employee.Contact.LastName.StartsWith(fullName));
            }

            if (!String.IsNullOrEmpty(projectNo))
            {
                query = query.Where(r => r.ProjectNo.StartsWith(projectNo));
            }

            if (!String.IsNullOrEmpty(facility))
            {
                query = query.Where(r => r.Project.Location.Name.StartsWith(facility) ||
                    r.Project.Port.Name.StartsWith(facility));
            }

            if (!String.IsNullOrEmpty(operation))
            {
                query = query.Where(r => r.Project.Operation.Name.StartsWith(operation));
            }

            if (!String.IsNullOrEmpty(product))
            {
                query = query.Where(r => r.Project.Product.StartsWith(operation));
            }

            if (dateOfReview.HasValue)
            {
                var date = dateOfReview.Value.Date;
                query = query.Where(r => EntityFunctions.TruncateTime(r.DateOfAssessment) == date);
            }

            if (!String.IsNullOrEmpty(createdBy))
            {
                query = query.Where(r => r.CreatedBy == createdBy);
            }

            if (sord == "asc")
            {
                if (sidx == "FullName")
                {
                    query = query.OrderBy(r => r.Employee.Contact.LastName)
                        .ThenBy(r => r.Employee.Contact.FirstName)
                        .ThenBy(r => r.Employee.Contact.MiddleName);
                }
                else if (sidx == "ProjectNo")
                {
                    query = query.OrderBy(r => r.ProjectNo);
                }
                else if (sidx == "Facility")
                {
                    query = query.OrderBy(r => r.Project.Location.Name).ThenBy(r => r.Project.Port.Name);
                }
                else if (sidx == "Operation")
                {
                    query = query.OrderBy(r => r.Project.Operation);
                }
                else if (sidx == "Product")
                {
                    query = query.OrderBy(r => r.Project.Product);
                }
                else if (sidx == "CreatedBy")
                {
                    query = query.OrderBy(r => r.CreatedBy);
                }
                else
                {
                    query = query.OrderBy(r => r.DateOfAssessment);
                }
            }
            else
            {
                if (sidx == "FullName")
                {
                    query = query.OrderByDescending(r => r.Employee.Contact.LastName)
                        .ThenBy(r => r.Employee.Contact.FirstName)
                        .ThenBy(r => r.Employee.Contact.MiddleName);
                }
                else if (sidx == "ProjectNo")
                {
                    query = query.OrderByDescending(r => r.ProjectNo);
                }
                else if (sidx == "Facility")
                {
                    query = query.OrderByDescending(r => r.Project.Location.Name).ThenBy(r => r.Project.Port.Name);
                }
                else if (sidx == "Operation")
                {
                    query = query.OrderByDescending(r => r.Project.Operation);
                }
                else if (sidx == "Product")
                {
                    query = query.OrderByDescending(r => r.Project.Product);
                }
                else if (sidx == "CreatedBy")
                {
                    query = query.OrderByDescending(r => r.CreatedBy);
                }
                else
                {
                    query = query.OrderByDescending(r => r.DateOfAssessment);
                }
            }

            var reviews = query
                .Skip(pageIndex * pageSize).Take(pageSize).ToList();

            var jsonData = new
            {
                total = totalPages,
                page,
                records = totalRecords,
                rows = (
                    from review in reviews
                    select new
                    {
                        id = review.Id,
                        cell = new string[] 
                        { 
                            review.Employee.FullName,
                            review.ProjectNo,
                            review.Project.Facility,
                            review.Project.Operation.Name,
                            review.Project.Product,
                            review.DateOfAssessment.ToString("MM/dd/yyyy HH:mm"),
                            review.CreatedBy,
                            review.Id.ToString()
                        }
                    }).ToArray()
            };
            return Json(jsonData);
        }

        [HttpPost]
        //[Authorize(Roles = "Administrator")]
        public void Delete(int[] ids)
        {
            foreach (int id in ids)
            {
                var review = new TrainingAssessment() { Id = id };
                _entities.Entry(review).State = System.Data.EntityState.Deleted;
            }

            _entities.SaveChanges();
        }
    }
}
