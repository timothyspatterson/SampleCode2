﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Reporting.WebForms;
using BigBlue2.Data;
using System.Web.Mvc;

namespace BigBlue2.Web.Reports
{
    public class NonConformanceDataSource
    {
        private readonly BigBlueEntities _entities;

        public NonConformanceDataSource()
        {
            _entities = DependencyResolver.Current.GetService<BigBlueEntities>();
        }

        public IEnumerable<NonConformanceReportModel> GetNonConformances(params int[] id)
        {
            var nonConformances = _entities.NonConformances.Where(nc => id.Contains(nc.Id));

            return from nc in nonConformances.ToList()
                   select new NonConformanceReportModel(nc);
        }

        public IEnumerable<NonConformanceComment> GetComments(int nonConformanceId, string type)
        {
            return _entities.NonConformanceComments.Where(c => 
                c.NonConformanceId == nonConformanceId && c.Type == type).OrderByDescending(c => c.DateCreated);
        }

        public IEnumerable<NonConformanceNotification> GetNotifications(int nonConformanceId)
        {
            return _entities.NonConformanceNotifications.Where(n => n.NonConformanceId == nonConformanceId);
        }

        public IEnumerable<QPECategoryModel> GetCategories(int qpeId)
        {
            return from c in _entities.QPECategories.Where(c => c.QPEId == qpeId).ToList()
                   select new QPECategoryModel(c);
        }
    }

    public class QPECategoryModel
    {
        public String Stage1 { get; set; }

        public String Stage2 { get; set; }

        public String Stage3 { get; set; }

        public QPECategoryModel(QPECategory category)
        {
            if (category.Stage1QPECategory != null)
            {
                Stage1 = category.Stage1QPECategory.Name;
            }
            if (category.Stage2QPECategory != null)
            {
                Stage2 = category.Stage2QPECategory.Name;
            }
            Stage3 = category.Stage3QPECategory.Name;
        }
    }

    public class NonConformanceReportModel
    {
        public int NonConformanceId { get; set; }

        public DateTime DateTime { get; set; }

        public string Employees { get; set; }

        public string Vendor { get; set; }

        public string Customer { get; set; }

        public string Barge { get; set; }

        public string Cargo { get; set; }

        public string Facility { get; set; }

        public string Dispatcher { get; set; }

        public string FollowedUpBy { get; set; }

        public DateTime? CompletionDate { get; set; }

        public string Description { get; set; }

        public bool CustomerComplaint { get; set; }

        public bool OpsMgr { get; set; }

        public bool VpOps { get; set; }

        public bool ExecVp { get; set; }

        public bool VpAdmin { get; set; }

        public bool SafetyTrainingComp { get; set; }

        public bool LaFieldSup { get; set; }

        public bool TxFieldSup { get; set; }

        public bool Dispatch { get; set; }

        public bool AccountingPayroll { get; set; }

        public bool NonIssue { get; set; }

        public NonConformanceReportModel(BigBlue2.Data.NonConformance nc)
        {
            NonConformanceId = nc.Id;
            DateTime = nc.Date;
            Dispatcher = nc.CreatedBy;
            FollowedUpBy = nc.ClosedBy;
            CompletionDate = nc.DateClosed.HasValue ? (DateTime?)nc.DateClosed.Value : null;

            string emps = "";
            if (nc.Employee != null)
                emps += nc.Employee.FullName;
            if (nc.Employee2 != null)
                emps += ", " + nc.Employee2.FullName;
            if (nc.Employee3 != null)
                emps += ", " + nc.Employee3.FullName;
            if (nc.Employee4 != null)
                emps += ", " + nc.Employee4.FullName;
            if (!String.IsNullOrEmpty(emps))
            {
                Employees = emps;
            }

            if (nc.Vendor != null)
            {
                Vendor = nc.Vendor.Name;
            }

            Description = nc.Description;
            CustomerComplaint = nc.CustomerComplaint;

            OpsMgr = nc.OpsMgr;
            VpOps = nc.VpOps;
            ExecVp = nc.ExecVp;
            VpAdmin = nc.VpAdmin;
            SafetyTrainingComp = nc.SafetyTrainingComp;
            LaFieldSup = nc.LaFieldSup;
            TxFieldSup = nc.TxFieldSup;
            Dispatch = nc.Dispatch;
            AccountingPayroll = nc.AccountingPayroll;
            NonIssue = (nc.non_issue.HasValue ? nc.non_issue.Value : false);

            if (nc.ProjectSummary == null)
            {
                Customer = nc.Customer.Name;
                Barge = nc.Barge.Name;
                Cargo = nc.ProductName;

                if (nc.Port != null)
                {
                    Facility = String.Format("{0} {1}", nc.Location.Name, nc.Port.Name);
                }
                else
                {
                    Facility = nc.Location.Name;
                }

            }
            else
            {
                Customer = nc.ProjectSummary.CustomerName;
                Barge = nc.ProjectSummary.BargeName;
                Cargo = nc.ProjectSummary.Product;
                if (nc.Port != null)
                {
                    Facility = String.Format("{0} {1}", nc.ProjectSummary.LocationName, nc.ProjectSummary.PortName);
                }
                else
                {
                    Facility = nc.ProjectSummary.LocationName;
                }
            }
        }
    }
}