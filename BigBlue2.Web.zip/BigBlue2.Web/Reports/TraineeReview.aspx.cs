﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using BigBlue2.Web.Models;

namespace BigBlue2.Web.Reports
{
    public partial class TraineeReview : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Request.QueryString["server"] == "y")
                {
                    string idlist = String.Join(",", Request.QueryString.GetValues("ids"));
                    IReportServerCredentials irsc = new CustomReportCredentials("ccaillet", "Tyler@11", "accutrans");
                    this.reportViewer.ServerReport.ReportServerCredentials = irsc;
                    this.reportViewer.ProcessingMode = ProcessingMode.Remote;
                    this.reportViewer.ServerReport.ReportServerUrl = new Uri("http://192.168.14.10:8100/reportserver/");
                    this.reportViewer.ServerReport.ReportPath = "/BigBlueReports/TraineeReport";

                    //This is a fix for a reporting issue I was having. Making the report accepting a list instead of a single object. I don't particularly like this.
                    List<Microsoft.Reporting.WebForms.ReportParameter> parmList = new List<ReportParameter>();
                    parmList.Add(new Microsoft.Reporting.WebForms.ReportParameter("ids", idlist, false));
                    this.reportViewer.ServerReport.SetParameters(parmList);

                    //this.reportViewer.ServerReport.SetParameters(new ReportParameter("ids", idlist, false));

                    this.reportViewer.ServerReport.Refresh();
                }
                else
                {
                    var dataSource = new TraineeReviewDataSource();
                    List<int> ids = new List<int>();

                    foreach (string id in Request.QueryString.GetValues("id"))
                    {
                        ids.Add(Convert.ToInt32(id));
                    }

                    var reviews = dataSource.GetAudits(ids.ToArray());

                    reportViewer.LocalReport.DataSources.Clear();
                    reportViewer.LocalReport.DataSources.Add(new ReportDataSource("TraineeReviews", reviews));
                }
            }
        }
    }
}