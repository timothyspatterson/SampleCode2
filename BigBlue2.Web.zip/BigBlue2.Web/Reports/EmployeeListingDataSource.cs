﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Reporting.WebForms;
using BigBlue2.Data;
using System.Web.Mvc;

namespace BigBlue2.Web.Reports
{
    public class EmployeeListingDataSource
    {
        private readonly BigBlueEntities _entities;

        public EmployeeListingDataSource()
        {
            _entities = DependencyResolver.Current.GetService<BigBlueEntities>();
        }

        public IEnumerable<EmployeeListingReportModel> GetEmployeeListing()
        {
            var emps = _entities.EmployeeSummaries;

            return from e in emps.ToList()
                   select new EmployeeListingReportModel(e);
        }

    }


    public class EmployeeListingReportModel
    {
        public string FullName { get; set; }
        public string SSN { get; set; }
        public DateTime? HireDate { get; set; }
        public DateTime? BirthDate { get; set; }
        public DateTime? LicAcquired { get; set; }
        public DateTime? LicExpired { get; set; }
        public string Trans50 { get; set; }
        public string Grade { get; set; }
        public string Spills { get; set; }

        public EmployeeListingReportModel(BigBlue2.Data.EmployeeSummary e)
        {
            FullName = e.FullName;
            SSN = "****" + e.Ssn.Substring(5, 6);
            HireDate = e.HireDate;
            BirthDate = e.DateOfBirth;
            LicAcquired = e.DateLicenseAcquired;
            LicExpired = e.DateLicenseExpired;
            Trans50 = e.Trans50;
            Grade = e.Grade;
            Spills = e.Spills;
        }
    }
}