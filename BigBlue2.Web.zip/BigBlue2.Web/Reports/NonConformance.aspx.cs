﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using BigBlue2.Services.NonConformances;
using BigBlue2.Web.Models;

namespace BigBlue2.Web.Reports
{
    public partial class NonConformance : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Request.QueryString["server"] == "y")
                {
                    string idlist = String.Join(",", Request.QueryString.GetValues("ids"));
                    IReportServerCredentials irsc = new CustomReportCredentials("ccaillet", "Tyler@11", "accutrans");
                    this.ReportViewer1.ServerReport.ReportServerCredentials = irsc;
                    this.ReportViewer1.ProcessingMode = ProcessingMode.Remote;
                    this.ReportViewer1.ServerReport.ReportServerUrl = new Uri("http://192.168.14.10:8100/reportserver/");
                    this.ReportViewer1.ServerReport.ReportPath = "/BigBlueReports/NonConformanceMaster";

                    //This is a fix for a reporting issue I was having. Making the report accepting a list instead of a single object.
                    List<Microsoft.Reporting.WebForms.ReportParameter> parmList = new List<ReportParameter>();
                    parmList.Add(new Microsoft.Reporting.WebForms.ReportParameter("ids", idlist, false));
                    this.ReportViewer1.ServerReport.SetParameters(parmList);

                    //this.ReportViewer1.ServerReport.SetParameters(new ReportParameter("ids", idlist, false));

                    this.ReportViewer1.ServerReport.Refresh();
                }
                //else
                //    this.ReportViewer1.Visible = false;

            }
        }

        protected void On_Selecting(object sender, ObjectDataSourceMethodEventArgs e)
        {
            var values = new List<int>();

            for (int i = 0; i < Request.QueryString.Keys.Count; i++)
            {
                values.Add(Convert.ToInt32(Request.QueryString[i]));
            }

            e.InputParameters.Add("id", values.ToArray());
        }

        protected void ProcessSubReport(object sender, SubreportProcessingEventArgs e)
        {
            var datasource = new NonConformanceDataSource();
            
            switch (e.ReportPath)
            {
                case "NonConformanceComments":
                    var comments = datasource.GetComments(Convert.ToInt32(e.Parameters["NonConformanceId"].Values[0]), 
                        CommentTypes.Comment);
                    e.DataSources.Add(new ReportDataSource("NonConformanceComments", comments));
                    break;

                case "NonConformanceCorrectiveActions":
                    var correctiveActions = datasource.GetComments(Convert.ToInt32(e.Parameters["NonConformanceId"].Values[0]),
                        CommentTypes.CorrectiveAction);
                    e.DataSources.Add(new ReportDataSource("NonConformanceComments", correctiveActions));
                    break;

                case "NonConformanceImmediateActions":
                    var immediateActions = datasource.GetComments(Convert.ToInt32(e.Parameters["NonConformanceId"].Values[0]),
                        CommentTypes.ImmediateActionTaken);
                    e.DataSources.Add(new ReportDataSource("NonConformanceComments", immediateActions));
                    break;

                case "NonConformanceNotifications":
                    var notifications = datasource.GetNotifications(Convert.ToInt32(e.Parameters["NonConformanceId"].Values[0]));
                    e.DataSources.Add(new ReportDataSource("Notifications", notifications));
                    break;

                case "NonConformanceCategories" :
                    var categories = datasource.GetCategories(Convert.ToInt32(e.Parameters["NonConformanceId"].Values[0]));
                    e.DataSources.Add(new ReportDataSource("Categories", categories));
                    break;
            }            
        }
    }
}