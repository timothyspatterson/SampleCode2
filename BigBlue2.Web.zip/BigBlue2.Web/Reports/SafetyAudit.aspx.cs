﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BigBlue2.Data;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Microsoft.Reporting.WebForms;
using BigBlue2.Web.Models;

namespace BigBlue2.Web.Reports
{
    public partial class SafetyAudit : System.Web.UI.Page
    {
        private readonly BigBlueEntities _entities;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Request.QueryString["server"] == "y")
                {
                    string idlist = String.Join(",", Request.QueryString.GetValues("ids"));
                    IReportServerCredentials irsc = new CustomReportCredentials("ccaillet", "Tyler@11", "accutrans");
                    this.ReportViewer1.ServerReport.ReportServerCredentials = irsc;
                    this.ReportViewer1.ProcessingMode = ProcessingMode.Remote;
                    this.ReportViewer1.ServerReport.ReportServerUrl = new Uri("http://192.168.14.10:8100/reportserver/");
                    this.ReportViewer1.ServerReport.ReportPath = "/BigBlueReports/SafetyAuditMaster";

                    //this.ReportViewer1.ServerReport.SetParameters(new ReportParameter("ids", idlist, false));

                    //This is a fix for a reporting issue I was having. Making the report accepting a list instead of a single object. I don't particularly like this.
                    List<Microsoft.Reporting.WebForms.ReportParameter> parmList = new List<ReportParameter>();
                    parmList.Add(new Microsoft.Reporting.WebForms.ReportParameter("ids", idlist, false));
                    this.ReportViewer1.ServerReport.SetParameters(parmList);

                    this.ReportViewer1.ServerReport.Refresh();
                }
            }
        }

        public SafetyAudit()
        {
            _entities = DependencyResolver.Current.GetService<BigBlueEntities>();
        }

        protected void On_Selecting(object sender, ObjectDataSourceMethodEventArgs e)
        {
            var values = new List<int>();

            for (int i = 0; i < Request.QueryString.Keys.Count; i++)
            {
                values.Add(Convert.ToInt32(Request.QueryString[i]));
            }

            e.InputParameters.Add("id", values.ToArray());
        }
    }
}