﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using BigBlue2.Services;

namespace BigBlue2.Web.Reports
{
    public class TraineeReviewDataSource
    {
        public IEnumerable<TraineeReviewReportModel> GetAudits(params int[] id)
        {
            var entities = DependencyResolver.Current.GetService<BigBlueEntities>();

            return from r in entities.TraineeReviews.Where(r => id.Contains(r.Id)).ToList()
                   select new TraineeReviewReportModel()
                   {
                       Trainee = r.Employee.FullName,
                       BargeName = r.Project.PrimaryBarge.Name,
                       Facility = r.Project.Facility,
                       Operation = r.Project.Operation.Name,
                       CreatedBy = r.CreatedBy,
                       DateCreated = r.DateCreated,
                       DriversLicense = ConvertAnswerToString(r.DriversLicense),
                       SafetyCouncilCards = ConvertAnswerToString(r.SafetyCouncilCards),
                       FoodDrink = ConvertAnswerToString(r.FoodDrink),
                       ToolsEquipment = ConvertAnswerToString(r.ToolsEquipment),
                       FireExtinguishers = ConvertAnswerToString(r.FireExtinguishers),
                       Uniform = ConvertAnswerToString(r.Uniform),
                       MMD = ConvertAnswerToString(r.MMD),
                       PPE = ConvertAnswerToString(r.PPE),
                       TallyRecordBook = ConvertAnswerToString(r.TallyRecordBook),
                       LocationOfESD = ConvertAnswerToString(r.LocationOfESD),
                       ReportingDelaysDiscrepancies = ConvertAnswerToString(r.ReportingDelaysDiscrepancies),
                       VesselProperlySecuredMoored = ConvertAnswerToString(r.VesselProperlySecuredMoored),
                       EyeWashEmergencyShowerLocation = ConvertAnswerToString(r.EyeWashEmergencyShowerLocation),
                       VerifyCompareOrders = ConvertAnswerToString(r.VerifyCompareOrders),
                       SafeAccessToVessel = ConvertAnswerToString(r.SafeAccessToVessel),
                       BargeHousekeeping = ConvertAnswerToString(r.BargeHousekeeping),
                       ValvesPlugsBleeder = ConvertAnswerToString(r.ValvesPlugsBleeder),
                       BargeDocumentation = ConvertAnswerToString(r.BargeDocumentation),
                       ValveAlignment = ConvertAnswerToString(r.ValveAlignment),
                       FluidLevel = ConvertAnswerToString(r.FluidLevel),
                       EngineCheck = ConvertAnswerToString(r.EngineCheck),
                       InitialRatesAndShutdown = ConvertAnswerToString(r.InitialRatesAndShutdown),
                       BreakingVacuum = ConvertAnswerToString(r.BreakingVacuum),
                       Pigging = ConvertAnswerToString(r.Pigging),
                       PrimingRepriming = ConvertAnswerToString(r.PrimingRepriming),
                       BlowingDraining = ConvertAnswerToString(r.BlowingDraining),
                       HoseArmConnection = ConvertAnswerToString(r.HoseArmConnection),
                       GaugeRodDeployment = ConvertAnswerToString(r.GaugeRodDeployment),
                       BoltAlignment = ConvertAnswerToString(r.BoltAlignment),
                       LeakDetection = ConvertAnswerToString(r.LeakDetection),
                       GasketPlacement = ConvertAnswerToString(r.GasketPlacement),
                       DOICompletion = ConvertAnswerToString(r.DOICompletion),
                       EngineOperations = ConvertAnswerToString(r.EngineOperations),
                       ReprimingOperations = ConvertAnswerToString(r.ReprimingOperations),
                       DeterminingRates = ConvertAnswerToString(r.DeterminingRates),
                       PumpBleedingOperations = ConvertAnswerToString(r.PumpBleedingOperations),
                       EstimatingCompletion = ConvertAnswerToString(r.EstimatingCompletion),
                       MonitoringTankLevels = ConvertAnswerToString(r.MonitoringTankLevels),
                       StrippingOperations = ConvertAnswerToString(r.StrippingOperations),
                       StandbyNotices = ConvertAnswerToString(r.StandbyNotices),
                       DrainingClearingBlowingDockHose = ConvertAnswerToString(r.DrainingClearingBlowingDockHose),
                       ControllingN2AirFlow = ConvertAnswerToString(r.ControllingN2AirFlow),
                       SecuringValves = ConvertAnswerToString(r.SecuringValvesHatches),
                       ShutdownValveAlignment = ConvertAnswerToString(r.ShutdownValveAlignment),
                       MonitoringLevels = ConvertAnswerToString(r.MonitoringLevels),
                       SecuringGaugeRods = ConvertAnswerToString(r.SecuringValves),
                       VerifyingOrdersPriorDisconnecting = ConvertAnswerToString(r.VerifyingOrdersPriorDisconnecting),
                       ScouringGaugeRods = ConvertAnswerToString(r.ScouringGaugeRods),
                       DisconnectSequence = ConvertAnswerToString(r.DisconnectSequence),
                       SecuringDripPanCovers = ConvertAnswerToString(r.SecuringDripPanCovers),
                       RemovingBondingCable = ConvertAnswerToString(r.RemovingBondingCable),
                       EnsuringProperDrainage = ConvertAnswerToString(r.EnsuringProperDrainage),
                       SecuringValvesHatches = ConvertAnswerToString(r.SecuringValvesHatches),
                       SecuringVaporControlDevices = ConvertAnswerToString(r.VesselProperlySecuredMoored),
                       PlacementOfDocumentation = ConvertAnswerToString(r.PlacementOfDocumentation),
                       PPEComments = r.PPEComments,
                       MechanicsComments = r.MechanicsComments,
                       JudgementComments = r.JudgementComments,
                       DemeanorComments = r.DemeanorComments,
                       WorkEthicComments = r.WorkEthicComments,
                       SkillLevelComments = r.SkillLevelComments,
                       KnowledgeComments = r.KnowledgeComments,
                       RetentionComments = r.RetentionComments,
                       Comments = r.Comments,
                       DateOfReview = r.DateOfReview
                   };
        }

        private string ConvertAnswerToString(int answerInt)
        {
            YesNoNA answer = (YesNoNA)answerInt;

            switch (answer)
            {
                case YesNoNA.NA :
                    return "N/A";

                case YesNoNA.Yes :
                    return "Yes";

                case YesNoNA.No :
                    return "No";
            }

            return "";
        }
    }

    public class TraineeReviewReportModel
    {
        public string Trainee { get; set; }
        public string Facility { get; set; }
        public string BargeName { get; set; }
        public string Operation { get; set; }
        public string CreatedBy { get; set; }
        public DateTime DateCreated { get; set; }
        public string DriversLicense { get; set; }
        public string SafetyCouncilCards { get; set; }
        public string FoodDrink { get; set; }
        public string ToolsEquipment { get; set; }
        public string FireExtinguishers { get; set; }
        public string Uniform { get; set; }
        public string MMD { get; set; }
        public string PPE { get; set; }
        public string TallyRecordBook { get; set; }
        public string LocationOfESD { get; set; }
        public string ReportingDelaysDiscrepancies { get; set; }
        public string VesselProperlySecuredMoored { get; set; }
        public string EyeWashEmergencyShowerLocation { get; set; }
        public string VerifyCompareOrders { get; set; }
        public string SafeAccessToVessel { get; set; }
        public string BargeHousekeeping { get; set; }
        public string ValvesPlugsBleeder { get; set; }
        public string BargeDocumentation { get; set; }
        public string ValveAlignment { get; set; }
        public string FluidLevel { get; set; }
        public string EngineCheck { get; set; }
        public string InitialRatesAndShutdown { get; set; }
        public string BreakingVacuum { get; set; }
        public string Pigging { get; set; }
        public string PrimingRepriming { get; set; }
        public string BlowingDraining { get; set; }
        public string HoseArmConnection { get; set; }
        public string GaugeRodDeployment { get; set; }
        public string BoltAlignment { get; set; }
        public string LeakDetection { get; set; }
        public string GasketPlacement { get; set; }
        public string DOICompletion { get; set; }
        public string EngineOperations { get; set; }
        public string ReprimingOperations { get; set; }
        public string DeterminingRates { get; set; }
        public string PumpBleedingOperations { get; set; }
        public string EstimatingCompletion { get; set; }
        public string MonitoringTankLevels { get; set; }
        public string StrippingOperations { get; set; }
        public string StandbyNotices { get; set; }
        public string DrainingClearingBlowingDockHose { get; set; }
        public string ControllingN2AirFlow { get; set; }
        public string SecuringValves { get; set; }
        public string ShutdownValveAlignment { get; set; }
        public string MonitoringLevels { get; set; }
        public string SecuringGaugeRods { get; set; }
        public string VerifyingOrdersPriorDisconnecting { get; set; }
        public string ScouringGaugeRods { get; set; }
        public string DisconnectSequence { get; set; }
        public string SecuringDripPanCovers { get; set; }
        public string RemovingBondingCable { get; set; }
        public string EnsuringProperDrainage { get; set; }
        public string SecuringValvesHatches { get; set; }
        public string SecuringVaporControlDevices { get; set; }
        public string PlacementOfDocumentation { get; set; }
        public string PPEComments { get; set; }
        public string MechanicsComments { get; set; }
        public string JudgementComments { get; set; }
        public string DemeanorComments { get; set; }
        public string WorkEthicComments { get; set; }
        public string SkillLevelComments { get; set; }
        public string KnowledgeComments { get; set; }
        public string RetentionComments { get; set; }
        public string Comments { get; set; }
        public DateTime DateOfReview { get; set; }
    }
}