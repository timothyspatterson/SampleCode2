﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using BigBlue2.Data;
using System.Web.Mvc;

namespace BigBlue2.Web.Reports
{
    public partial class AccuShipTimeSheet : System.Web.UI.Page
    {
        private readonly BigBlueEntities _entities;

        public AccuShipTimeSheet()
        {
            _entities = DependencyResolver.Current.GetService<BigBlueEntities>();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                string projectNo = Request.QueryString["projectNo"];

                var project = _entities.Projects.SingleOrDefault(p => p.No == projectNo);

                if (project != null)
                {
                    var times = new EmployeeTimesDatasource().GetTimes(project.No);

                    var parameters = new List<ReportParameter>();

                    decimal? totalHours = project.LDDetail.ActualHours + project.LDDetail.AddHours;
                    decimal? holidayHours = times.Sum(x => x.HolidayHours.Value);

                    parameters.Add(new ReportParameter("ProjectNo", projectNo));
                    parameters.Add(new ReportParameter("FPQNo", project.FPQueues.Any() ? 
                        project.FPQueues.First().FPQNo.ToString() : ""));
                    parameters.Add(new ReportParameter("InvoiceNo", project.InvoiceNumber));
                    parameters.Add(new ReportParameter("DateOfJob", project.DateOfProject.ToString()));
                    parameters.Add(new ReportParameter("Customer", project.Customer.Name));
                    parameters.Add(new ReportParameter("Facility", project.Facility));
                    parameters.Add(new ReportParameter("Port", project.Port.Name));
                    parameters.Add(new ReportParameter("PoNo", project.CustomerPoNo));
                    parameters.Add(new ReportParameter("ProjectNotes", project.BillingNotes));
                    parameters.Add(new ReportParameter("ActualHours", project.LDDetail.ActualHours.ToString()));
                    parameters.Add(new ReportParameter("AdditionalHours", project.LDDetail.AddHours.ToString()));
                    parameters.Add(new ReportParameter("TotalHours", totalHours.ToString()));
                    parameters.Add(new ReportParameter("HolidayHours", holidayHours.ToString()));
                    parameters.Add(new ReportParameter("StartDate", times.Min(t => t.ArrivalDate).ToString()));
                    parameters.Add(new ReportParameter("EndDate", times.Max(t => t.DepartDate).ToString()));

                    reportViewer.LocalReport.SetParameters(parameters);

                    reportViewer.LocalReport.DataSources.Clear();
                    reportViewer.LocalReport.DataSources.Add(new ReportDataSource("EmployeeTimes", times));

                    reportViewer.LocalReport.Refresh();
                }
            }
        }
    }
}