﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using BigBlue2.Services.NonConformances;
using BigBlue2.Web.Models;

namespace BigBlue2.Web.Reports
{
    public partial class PhoneListing : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Request.QueryString["server"] == "y")
                {
                    //string idlist = String.Join(",", Request.QueryString.GetValues("ids"));
                    IReportServerCredentials irsc = new CustomReportCredentials("ccaillet", "Tyler@11", "accutrans");
                    this.ReportViewer1.ServerReport.ReportServerCredentials = irsc;
                    this.ReportViewer1.ProcessingMode = ProcessingMode.Remote;
                    this.ReportViewer1.ServerReport.ReportServerUrl = new Uri("http://192.168.14.10:8100/reportserver/");
                    this.ReportViewer1.ServerReport.ReportPath = "/BigBlueReports/PhoneListing";

                    

                    this.ReportViewer1.ServerReport.Refresh();
                }
                //else
                //    this.ReportViewer1.Visible = false;

            }
        }

      
    }
}