﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;
using System.Web.Mvc;

namespace BigBlue2.Web.Reports
{
    public class SafetyAuditsDataSource
    {
        public IEnumerable<SafetyAuditSummary> GetAudits(params int[] id)
        {
            var entities = DependencyResolver.Current.GetService<BigBlueEntities>();

            return entities.SafetyAuditSummaries.Where(a => id.Contains(a.id));
        }
    }
}