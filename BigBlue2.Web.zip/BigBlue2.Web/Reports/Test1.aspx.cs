﻿using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BigBlue2.Web.Reports
{
    public partial class Test1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                IReportServerCredentials irsc = new BigBlue2.Web.Models.CustomReportCredentials("ccaillet", "Tyler@11", "accutrans");
                this.reportViewer.ServerReport.ReportServerCredentials = irsc;
                this.reportViewer.ProcessingMode = ProcessingMode.Remote;
                this.reportViewer.ServerReport.ReportServerUrl = new Uri("http://192.168.14.10:8100/reportserver/");
                this.reportViewer.ServerReport.ReportPath = "/Test/TestReport1";
                this.reportViewer.ServerReport.Refresh();
            }
        }
    }

}