﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;
using System.Web.Mvc;

namespace BigBlue2.Web.Reports
{
    public class EmployeeTimesDatasource
    {
        public IEnumerable<EmployeeTime> GetTimes(string projectNo)
        {
            var entities = DependencyResolver.Current.GetService<BigBlueEntities>();

            var postings = entities.LaborPostings.Where(l => l.ProjectNo == projectNo).ToList();

            return from p in postings
                   select new EmployeeTime(p);
        }

        public class EmployeeTime
        {
            public string Employee { get; set; }

            public decimal? ActualHours { get; set; }

            public decimal? PaidHours { get; set; }

            public decimal? NonBillHours { get; set; }

            public decimal? Mileage { get; set; }

            public decimal? Inspection { get; set; }

            public decimal? Travel { get; set; }

            public decimal? HolidayHours { get; set; }

            public DateTime ArrivalDate { get; set; }

            public DateTime DepartDate { get; set; }

            public EmployeeTime(LaborPosting posting)
            {
                Employee = posting.Employee.FullName;
                ActualHours = posting.ActualHours;
                PaidHours = posting.PaidHours;
                NonBillHours = posting.NonBillHours;
                Mileage = posting.Mileage;
                Inspection = posting.Inspect;
                Travel = posting.Travel;
                HolidayHours = posting.Holiday;
                ArrivalDate = posting.ArrivalDate;
                DepartDate = posting.DepartDate;
            }
        }
    }
}