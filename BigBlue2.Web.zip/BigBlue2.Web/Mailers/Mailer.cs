﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Mvc.Mailer;
using System.Net.Mail;
using BigBlue2.Data;
using BigBlue2.Services.Config;

namespace BigBlue2.Web.Mailers
{
    public class Mailer : MailerBase, IQPEMailer, ITraineeReviewMailer, ITransitionQueueMailer
    {
        private readonly IQPEConfig _qpeConfig;
        private readonly INewTransitionQueueItemEmailConfig _transitionQueueConfig;

        public Mailer(IQPEConfig config, INewTransitionQueueItemEmailConfig transitionQueueConfig)
            : base()
        {
            _qpeConfig = config;
            _transitionQueueConfig = transitionQueueConfig;
            MasterName = "_EmailLayout";
        }

        public virtual MailMessage TransitionQueueEntrySubmitted(TransitionQueueEntry entry)
        {
            var mailMessage = new MailMessage
            {
                Subject = "Transition Queue Entry Submitted by " + entry.Employee.FullName
            };

            foreach (string email in _transitionQueueConfig.EmailAddress.Split(';'))
            {
                mailMessage.To.Add(email);
            }

            ViewData.Model = entry;
            PopulateBody(mailMessage, viewName: "TransitionQueueEntrySubmitted");

            return mailMessage;
        }

        public virtual MailMessage TraineeReviewCreated(TraineeReview review)
        {
            var mailMessage = new MailMessage { Subject = "Trainee Review Created for " + review.Employee.FullName };

            mailMessage.To.Add(review.Project.ProjectLocation.EmailAddress);

            ViewData.Model = review;
            PopulateBody(mailMessage, viewName: "TraineeReviewCreated");

            return mailMessage;
        }

        public virtual MailMessage QPEClosed(NonConformance qpe)
        {
            var mailMessage = new MailMessage { Subject = "QPE Closed by " + qpe.ClosedBy };

            foreach (var email in _qpeConfig.EmailAddresses)
            {
                mailMessage.To.Add(email);
            }
            if (qpe.accu_at_fault.ToUpper() == "YES")
            {
                foreach (var e in _qpeConfig.AtFaultEmailAddresses)
                    mailMessage.To.Add(e);
            }

            ViewData.Model = qpe;
            PopulateBody(mailMessage, viewName: "QPEClosed");
            return mailMessage;
        }

        public virtual MailMessage QPEOpened(NonConformance qpe)
        {
            
            throw new NotImplementedException();
            
        }

       
        
       

    }

    public class MvcMailerSmtpExtension : ISmtpClient
    {
        private readonly SmtpBoyEntities _entities;
        public event SendCompletedEventHandler SendCompleted;
        public MvcMailerSmtpExtension(SmtpBoyEntities entities)
        {
            _entities = entities;
        }

        public void Send(MailMessage mailMessage)
        {
            BigBlue2.Services.Email.SmtpBoyEmailer emailer = new Services.Email.SmtpBoyEmailer(_entities);
            emailer.Send(mailMessage);
        }

        public void SendAsync(MailMessage mailMessage)
        {

        }

        public void SendAsync(MailMessage mailMessage, object userState)
        {

        }

        public void Dispose()
        {
            _entities.Dispose();
        }

    }
}