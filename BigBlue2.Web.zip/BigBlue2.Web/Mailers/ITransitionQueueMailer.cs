﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using BigBlue2.Data;

namespace BigBlue2.Web.Mailers
{
    public interface ITransitionQueueMailer
    {
        MailMessage TransitionQueueEntrySubmitted(TransitionQueueEntry entry);
    }
}
