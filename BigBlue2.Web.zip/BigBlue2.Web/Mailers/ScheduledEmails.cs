﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Mvc.Mailer;
using System.Net.Mail;
using BigBlue2.Data;
using BigBlue2.Services.Config;
using BigBlue2.Services.Projects;

namespace BigBlue2.Web.Mailers
{
    public class ScheduledEmails : MailerBase, IScheduledEmails
    {
        private readonly BigBlueEntities _entities;
        private readonly IDoNotFinalizeEmailConfig _config;

        public ScheduledEmails(BigBlueEntities entities, IDoNotFinalizeEmailConfig config)
            : base()
        {
            MasterName = "_EmailLayout";
            _entities = entities;
            _config = config;
        }

        public MailMessage DoNotFinalizeProjects()
        {
            var mailMessage = new MailMessage
            {
                Subject = "Do Not Finalize Projects - " + DateTime.Now.ToString()
            };

            foreach (var email in _config.EmailAddresses)
            {
                mailMessage.To.Add(email);
            }

            var projects = _entities.Projects.Where(p => p.StatusId != ProjectStatusId.Cancelled &&
                p.StatusId != ProjectStatusId.Finalized && p.DoNotFinalize);

            ViewData.Model = projects;
            PopulateBody(mailMessage, viewName: "DoNotFinalizeProjects");

            return mailMessage;
        }
    }
}