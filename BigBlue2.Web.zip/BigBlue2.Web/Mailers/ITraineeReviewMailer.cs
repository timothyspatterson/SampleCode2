using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Mvc.Mailer;
using System.Net.Mail;
using BigBlue2.Data;

namespace BigBlue2.Web.Mailers
{ 
    public interface ITraineeReviewMailer
    {		
		MailMessage TraineeReviewCreated(TraineeReview review);
	}
}