﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using BigBlue2.Data;

namespace BigBlue2.Web.Mailers
{
    public interface IQPEMailer
    {
        MailMessage QPEClosed(NonConformance qpe);
        MailMessage QPEOpened(NonConformance qpe);
    }
}
