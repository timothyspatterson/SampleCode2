﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Services.Email;
using System.Security.Policy;

namespace BigBlue2.Web.Infrastructure
{
    public class UrlService : IUrlService, IEmployeeUrl
    {
        private string _baseUrl;

        public UrlService()
        {
            string port = System.Web.HttpContext.Current.Request.ServerVariables["SERVER_PORT"];

            if (port == null || port == "80" || port == "443")
            {
                port = "";
            }
            else
            {
                port = ":" + port;
            }

            string protocol = System.Web.HttpContext.Current.Request.ServerVariables["SERVER_PORT_SECURE"];

            if (protocol == null || protocol == "0")
            {
                protocol = "http://";
            }
            else
                protocol = "https://";

            _baseUrl = protocol + System.Web.HttpContext.Current.Request.ServerVariables["SERVER_NAME"] + port + System.Web.HttpContext.Current.Request.ApplicationPath;

            if (_baseUrl.EndsWith("/"))
            {
                _baseUrl = _baseUrl.Substring(0, _baseUrl.Length - 1);
            }
        }

        public string GetSafetyAuditUrl(int safetyAuditId)
        {
            return String.Format("{0}/Reports/SafetyAudit.aspx?id={1}", _baseUrl, safetyAuditId);
        }

        public string GetNonConformanceUrl(int nonConformanceId)
        {
            return String.Format("{0}/NonConformances/Details/{1}", _baseUrl, nonConformanceId);
        }

        public string EmployeeUrlFor(Guid employeeId)
        {
            return String.Format("{0}/Employees/Edit/{1}", _baseUrl, employeeId);
        }
    }
}