﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace BigBlue2.Web.Infrastructure
{
    public static class HtmlHelperExtensions
    {
        public static MvcHtmlString ReadOnlyTextBox(this HtmlHelper helper, string name, string value)
        {
            return ReadOnlyTextBox(helper, name, value, String.Empty);
        }

        public static MvcHtmlString ReadOnlyTextBox(this HtmlHelper helper, string name, string value, string className)
        {
            return helper.TextBox(name, value, new { disabled = "disabled", @class = className });

        }

        public static string FormattedPhoneNumber(this string number)
        {
            string s = number.Replace("-", "").Replace("(","").Replace(")","");
            if (number.Length == 10)
                return s.Substring(0, 3) + "-" + s.Substring(3, 3) + "-" + s.Substring(6, 4);
            return s;
        }

    }
}