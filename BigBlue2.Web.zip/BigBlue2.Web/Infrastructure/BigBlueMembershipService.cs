﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using BigBlue2.Services.Account;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
namespace BigBlue2.Web.Infrastructure
{
    public class BigBlueMembershipService : IMembershipService
    {
       
        public bool ValidateUser(string username, string password)
        {
            /*
            // first check AD.  If valid, return true;
            if (isValidAD(username, password))
            {
               return true;
            }
            else
                */
                return Membership.ValidateUser(username, password);
        }

        private bool isValidAD(string username, string password)
        {
            bool isValid = false;
            using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, "Accutrans.local"))
            {
                // validate the credentials
                isValid = pc.ValidateCredentials(username, password);
            }
            return isValid;

        }

        public string CurrentUser
        {
            get
            {
                if (Membership.GetUser().UserName == "cody2")
                    return "bforet";
                else
                    return Membership.GetUser().UserName;
            }
        }

        public bool UserNameExists(string userName)
        {
            return Membership.GetUser(userName) != null;
        }

        public void CreateUser(string userName, string password)
        {
            Membership.CreateUser(userName, password);
        }

        public void ChangePassword(string userName, string password)
        {
            var user = Membership.GetUser(userName);

            var temp = user.ResetPassword();

            user.ChangePassword(temp, password);
        }
    }
}