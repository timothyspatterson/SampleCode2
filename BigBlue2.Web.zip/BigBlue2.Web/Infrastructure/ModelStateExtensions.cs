﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Services;
using System.ComponentModel.DataAnnotations;

namespace BigBlue2.Web
{
    public static class ModelStateExtensions
    {
        public static void AddValidationErrors(this ModelStateDictionary modelState, 
            BigBlue2.Services.ValidationException ex)
        {
            foreach(var entry in ex.ValidationErrors)
            {
                modelState.AddModelError(entry.Key, entry.Value);
            }
        }

        public static void AddValidationResults(this ModelStateDictionary modelState, IEnumerable<ValidationResult> results)
        {
            foreach (var result in results)
            {
                foreach (string name in result.MemberNames)
                {
                    modelState.AddModelError(name, result.ErrorMessage);
                }
            }
        }
    }
}