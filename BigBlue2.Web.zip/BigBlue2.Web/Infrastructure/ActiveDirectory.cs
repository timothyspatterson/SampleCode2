﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Web;
  
namespace BigBlue2.Web.Infrastructure
{
    public class ActiveDirectory
    {
        public static string usernameExists(string username)
        {
                    try
            {
                string path = "ldap://accutrans.local:389, DC=Accutrans, DC=local, OU=Users";

                using (DirectoryEntry ou = new DirectoryEntry(path))
                {

                    DirectorySearcher mySearcher = new DirectorySearcher() { Filter = "(&(objectClass=user)(anr=" + username + "))" };
                    SearchResultCollection results = mySearcher.FindAll();

                    if (results.Count == 0)
                        return "No";
                    else
                        return "Yes";                   

                }
            }
            catch (Exception exc)
            {
               return exc.Message;
            }
        }

        private string createUser(string username)
        {
            try
            {
                using (var pc = new PrincipalContext(ContextType.Domain, "accutrans", "msalo", "z28death"))
                {
                    //pc.UserName = "msalo";

                    UserPrincipal usr = UserPrincipal.FindByIdentity(pc, username);
                    if (usr != null)
                    {
                        return string.Empty;
                    }

                    using (var up = new UserPrincipal(pc))
                    {
                        up.SamAccountName = username;
                        up.SetPassword("@1password");
                        up.Enabled = true;
                        up.ExpirePasswordNow();
                        up.Save();
                    }
                }
                return "Done";
            }
            catch (System.Exception ex)
            {
                return ex.Message;
            }
        }
    }
}