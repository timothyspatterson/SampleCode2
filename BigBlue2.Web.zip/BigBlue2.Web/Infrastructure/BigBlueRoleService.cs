﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using BigBlue2.Services.Account;

namespace BigBlue2.Web.Infrastructure
{
    public class BigBlueRoleService : IRoleService
    {
        public bool IsUserInRole(string username, SecurityRoles role)
        {
            return Roles.IsUserInRole(username, role.ToString());
        }

        public bool IsUserInRole(SecurityRoles role)
        {
            return Roles.IsUserInRole(role.ToString());
        }
    }
}