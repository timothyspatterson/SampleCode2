﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;

namespace BigBlue2.Web.Models.BigBoard
{
    public class IndexModel
    {
        public IEnumerable<IGrouping<string, BigBoardLive>> BigBoardLiveData { get; set; }

        public int TotalJobsWorking { get; set; }

        public Dictionary<string, int> TotalJobWorkingByGroup { get; set; }
    }
}