﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BigBlue2.Web.Models.EmployeeSnapshot
{
    public class employeeList
    {
        //public List<BigBlue2.Data.EmployeeSummary> employeeSummary { get; set; }
        public IEnumerable<IGrouping<string, BigBlue2.Data.EmployeeSummary>> tankerManGroups { get; set; }
    }

    public class QPEStageData
    {
        public int QPEid { get; set; }
        public DateTime createDate { get; set; }
        public string QPEStage1 { get; set; }
        public string QPEStage2 { get; set; }
        public string QPEStage3 { get; set; }
    }

    public class safetyAudits
    {
        public int safetyAuditID { get; set; }
        public DateTime createDate { get; set; }
        public string bargeName { get; set; }
        public string PPEUs { get; set; }
        public string TransferUs { get; set; }
        public string WorkPracticesUs { get; set; }
    }

    public class Attaboys
    {
        public int attaboyID { get; set; }
        public string description { get; set; }
        public DateTime createDate { get; set; }
        public string createdBy { get; set; }
    }

    public class SnapshotDetails
    {
        public string FullName { get; set; }
        public Guid employeeId { get; set; }
        [DisplayName("Start Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime startDate { get; set; }
        [DisplayName("End Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime endDate { get; set; }
        public List<QPEStageData> QPEStages { get; set; }
        public List<safetyAudits> SafetyAudits { get; set; }
        public List<Attaboys> Attaboys { get; set; }
        public List<OverRides> overrides { get; set; }
        public List<trainReviews> trainingReviews { get; set; }
    }

    public class OverRides
    {
        public int overrideID { get; set; }
        public string overrideType { get; set; }
        public string details { get; set; }
        public DateTime createDate { get; set; }
    }

    public class QPEDetails
    {
        public int id { get; set; }
        public string project_no { get; set; }
        public string customer { get; set; }
        public string product { get; set; }
        public string projectLocation { get; set; }
        public string location { get; set; }
        public string barge { get; set; }
        public string port { get; set; }
        public string boat { get; set; }
        public string operation { get; set; }
        public string employee { get; set; }
        public DateTime dateTime { get; set; }
        public string vendor { get; set; }
        public DateTime dateCreated { get; set; }
        public string createdBy { get; set; }
        public string stage1Categories { get; set; }
        public string stage2Categories { get; set; }
        public string stage3Categories { get; set; }
        public string description { get; set; }
        public List<QPEComments> comments { get; set; }
        public List<QPEImmediateActions> immediateActions { get; set; }
        public List<QPECorrectiveActions> correctiveActions { get; set; }
        public List<QPENotifications> notifications { get; set; }
        public QPEroutingList routingList { get; set; }
        public bool IsClosed { get; set; }
        public bool customerComplaint { get; set; }
        public bool nonIssue { get; set; }
    }

    public class QPEComments
    {
        public string comments { get; set; }
        public string createdBy { get; set; }
        public DateTime dateTime { get; set; }
    }

    public class QPEImmediateActions
    {
        public string actions { get; set; }
        public string createdBy { get; set; }
        public DateTime dateTime { get; set; }
    }

    public class QPECorrectiveActions
    {
        public string actions { get; set; }
        public string createdBy { get; set; }
        public DateTime dateTime { get; set; }
    }

    public class QPENotifications
    {
        public string company { get; set; }
        public string personContacted { get; set; }
        public DateTime dateNotified { get; set; }
        public string notifiedBY { get; set; }
    }

    public class QPEroutingList
    {
        public bool OPSMgr { get; set; }
        public bool VPOps { get; set; }
        public bool ExeVP { get; set; }
        public bool VPAdmin { get; set; }
        public bool SafetyTraingComp { get; set; }
        public bool LAFieldSup { get; set; }
        public bool TXFieldSup { get; set; }
        public bool AccountingPayroll { get; set; }
        public bool dispatch { get; set; }

    }

    public class employeeOverridesDetails
    {
        public string employee { get; set; }
        public DateTime start_dt { get; set; }
        public DateTime end_dt { get; set; }
        public string overrideType { get; set; }
        public string comments { get; set; }
        public string update_by { get; set; }
        public string created_by { get; set; }
        public string rotation_override { get; set; }
    }

    public class trainReviews
    {
        public int trainingReviewId { get; set; }
        public string facility { get; set; }
        public string project_no { get; set; }
        public string created_by { get; set; }
        public DateTime review_dt { get; set; }
        public string operation { get; set; }
        public string product { get; set; }
    }




}