﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;

namespace BigBlue2.Web.Models.SafetyAudits
{
    public class GridItem
    {
        public int SafetyAuditId { get; private set; }

        public string Employee { get; private set; }

        public string Project { get; private set; }

        public DateTime DateOfAudit { get; private set; }

        public string CreatedBy { get; private set; }

        public GridItem(SafetyAudit safetyAudit)
        {
            SafetyAuditId = safetyAudit.Id;
            CreatedBy = safetyAudit.CreatedBy;
            Project = safetyAudit.Project.Name;
            DateOfAudit = safetyAudit.DateTime;
            Employee = safetyAudit.Employee.Contact.FullName;
        }
    }
}