﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;

namespace BigBlue2.Web.Models.SafetyAudits
{
    public class FieldsModel
    {
        public SafetyAudit SafetyAudit { get; set; }

        public bool Editable { get; set; }

        public FieldsModel()
        {
            Editable = true;
        }

        public FieldsModel(SafetyAudit audit)
        {
            SafetyAudit = audit;
            Editable = false;
        }
    }
}