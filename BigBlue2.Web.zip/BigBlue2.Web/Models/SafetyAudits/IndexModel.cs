﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;
using System.Web.Mvc;
using System.Web.Security;
using BigBlue2.Web.Models;

namespace BigBlue2.Web.Models.SafetyAudits
{
    public class IndexModel
    {
        public GridModel<GridItem> GridModel { get; private set; }

        public SelectList Employees { get; set; }

        public SelectList Customers { get; set; }

        public SelectList Users { get; set; }

        public IndexModel(IEnumerable<SafetyAudit> safetyAudits, IEnumerable<Employee> employees, 
            IEnumerable<Customer> customers, IEnumerable<string> users, int pageSize, string sort, string sortDir)
        {
            var items = from a in safetyAudits
                        select new GridItem(a);

            GridModel = new GridModel<GridItem>(items, pageSize, sort, sortDir);

            Employees = new SelectList(employees, "Id", "FullName");

            Customers = new SelectList(customers, "Id", "Name");

            Users = new SelectList(users);
        }
    }
}