﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BigBlue2.Web.Models
{
    public class ValidatedPartialViewModel
    {
        public bool IsValid { get; set; }

        public string Html { get; set; }
    }
}