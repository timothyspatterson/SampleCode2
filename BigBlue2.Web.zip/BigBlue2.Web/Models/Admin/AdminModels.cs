﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BigBlue2.Web.Models.Admin
{
    public class AdminIndexModel
    {
        public string[] Users;
        public string[] Roles;
    }

    public class ANTRecipient
    {
        public bool Selected { get; set; }
        public string Name { get; set; }
        public string Info { get; set; }
        public bool AcceptedPolicy { get; set; }
        public List<ANTRecipient> Employees { get; set; }
    }

    public class ANTMoundIndexModel
    {
        public List<ANTRecipient> Locations { get; set; }       
        public string Message { get; set; }
    }



    
}