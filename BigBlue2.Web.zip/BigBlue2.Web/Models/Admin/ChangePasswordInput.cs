﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using DataAnnotationsExtensions;
using System.ComponentModel;

namespace BigBlue2.Web.Models.Admin
{
    public class ChangePasswordInput
    {
        [Required]
        public string UserName { get; set; }

        [Required]
        [DisplayName("Current Password")]
        public string CurrentPassword { get; set; }

        [Required]
        [MinLength(4)]
        [DisplayName("New Password")]
        public string NewPassword { get; set; }

        [Required]
        [EqualTo("NewPassword")]
        [DisplayName("Confirm Password")]
        public string ConfirmNewPassword { get; set; }

        [DisplayName("Admin Reset")]
        public bool AdminReset { get; set; }
    }
}