﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using BigBlue2.Data;

namespace BigBlue2.Web.Models.Admin
{
    public class EditModel
    {
        public MembershipUser MembershipUser { get; private set; }

        public Employee Employee { get; private set; }

        public IEnumerable<string> UserRoles { get; private set; }

        public IEnumerable<string> AllRoles { get; private set; }

        public EditModel(MembershipUser user, Employee employee, IEnumerable<string> userRoles, 
            IEnumerable<string> allRoles)
        {
            MembershipUser = user;
            Employee = employee;
            UserRoles = userRoles;
            AllRoles = allRoles;
        }
    }
}