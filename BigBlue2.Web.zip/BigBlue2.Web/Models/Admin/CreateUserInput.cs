﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using DataAnnotationsExtensions;

namespace BigBlue2.Web.Models.Admin
{
    public class CreateUserInput
    {
        [Required]
        public Guid EmployeeId { get; set; }

        [Required]
        [MinLength(4)]
        public string Username { get; set; }

        [Required]
        [MinLength(4)]
        public string Password { get; set; }

        [Required]
        [EqualTo("Password")]
        public string ConfirmPassword { get; set; }
    }
}