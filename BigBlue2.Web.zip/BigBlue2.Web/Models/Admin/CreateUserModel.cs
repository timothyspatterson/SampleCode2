﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;

namespace BigBlue2.Web.Models.Admin
{
    public class CreateUserModel
    {
        public SelectList Employees { get; private set; }

        public CreateUserModel(IEnumerable<Employee> employees)
        {
            Employees = new SelectList(employees, "Id", "FullName");
        }
    }
}