﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using BigBlue2.Services.Payroll;

namespace BigBlue2.Web.Models.Payroll
{
    public class payDetails
    {
        public int auto_id { get; set; }
        public decimal Actual { get; set; }
        public decimal Paid { get; set; }
        public decimal Free { get; set; }
        //paycode mileage type $
        public decimal mileage { get; set; }
        //paycode inspection type $
        public decimal Inspection { get; set; }
        public decimal Travel { get; set; }
        public decimal Holiday { get; set; }
        //public decimal Other { get; set; }
        //paycode perdiem type $
        public decimal Perdiem { get; set; }
        public decimal Vacation { get; set; }
        //public decimal Dispatching { get; set; }
        //public decimal Education { get; set; }
        //public decimal Supervising { get; set; }
        //public decimal Safety { get; set; }
        //public decimal ShiftMeeting { get; set; }
        //public decimal Training { get; set; }
        public DateTime event_dt { get; set; }
        public DateTime arrivalDate { get; set; }
        //public DateTime departDate { get; set; }
        //public bool freeHours { get; set; }
        public string barge { get; set; }
    }

    public class EmployeeModel
    {
        public Guid EmployeeId { get; private set; }

        //public SelectList WorkWeeks { get; private set; }

        //public IEnumerable<CustomLaborPosting> LaborPostings { get; private set; }
        public string fullName { get; private set; }
        public List<payDetails> payDetails { get; set; }
        public SelectList WorkWeeks { get; private set; }

        public EmployeeModel()
        {
             
        }

        public EmployeeModel(DateTime pay_dt, Guid employee_id, IEnumerable<WorkWeek> workWeeks)
        {
            WorkWeeks = new SelectList(workWeeks, "StartDate", "DisplayText");

            this.payDetails = getPayDetails(employee_id, pay_dt);
        }

        public List<payDetails> getPayDetails(Guid employee_id, DateTime pay_dt)
        {
            List<payDetails> pdList = new List<payDetails>();

            using (BigBlueEntities bbe = new BigBlueEntities())
            { 
                var model = from bbpe in bbe.BigBluePayEvents
                            join vw in bbe.EmployeeSummaries on new { employee_row_id = bbpe.employee_row_id } equals new { employee_row_id = vw.Id }
                            where bbpe.employee_row_id == employee_id && bbpe.pay_dt == pay_dt
                            orderby bbpe.event_dt
                            select new { bbpe = bbpe, vw = vw };
                this.payDetails = new List<payDetails>();
                this.EmployeeId = employee_id;
                foreach (var r in model)
                {
                    this.fullName = r.vw.FullName;
                    payDetails pdItem;
                    bool newRow = false;
                    if (pdList.Where(q1 => q1.auto_id == r.bbpe.laborPosting_auto_id).Count() == 0)
                    {
                        pdItem = new payDetails();
                        pdItem.auto_id = r.bbpe.laborPosting_auto_id;
                        if (r.bbpe.event_dt.HasValue) pdItem.arrivalDate = r.bbpe.event_dt.Value;
                        newRow = true;
                    }
                    else
                        pdItem = pdList.Where(q1 => q1.auto_id == r.bbpe.laborPosting_auto_id).First();
                    var barge = bbe.Projects.Where(q1 => q1.No == r.bbpe.project_no);
                    if (barge.Count() > 0)
                        pdItem.barge = barge.First().PrimaryBarge.Name;
                    else
                        pdItem.barge = "NONE";

                    getPayDetails(ref pdItem, r.bbpe.paycode_id, r.bbpe.unit_amt.Value * r.bbpe.unit_no.Value, r.bbpe.freehours_flag);
                    //if (r.bbpe.event_dt.HasValue) pdItem.departDate = r.bbpe.event_dt.Value;
                    if (newRow)
                        pdList.Add(pdItem);
                }

                payDetails totals = new payDetails();
                totals.barge = "Totals";
                //totals.Dispatching = pdList.Sum(q1 => q1.Dispatching);
                //totals.Education = pdList.Sum(q1 => q1.Education);
                totals.Holiday = pdList.Sum(q1 => q1.Holiday);
                totals.Free = pdList.Sum(q1 => q1.Free);
                totals.Actual = pdList.Sum(q1 => q1.Actual);
                totals.Paid = pdList.Sum(q1 => q1.Paid);
                totals.Inspection = pdList.Sum(q1 => q1.Inspection);
                //totals.Labor = pdList.Sum(q1 => q1.Labor);
                totals.mileage = pdList.Sum(q1 => q1.mileage);
                //totals.Other = pdList.Sum(q1 => q1.Other);
                totals.Perdiem = pdList.Sum(q1 => q1.Perdiem);
                //totals.Safety = pdList.Sum(q1 => q1.Safety);
                //totals.ShiftMeeting = pdList.Sum(q1 => q1.ShiftMeeting);
                //totals.Supervising = pdList.Sum(q1 => q1.Supervising);
                //totals.Training = pdList.Sum(q1 => q1.Training);
                totals.Travel = pdList.Sum(q1 => q1.Travel);
                totals.Vacation = pdList.Sum(q1 => q1.Vacation);

                pdList.Add(totals);
            }

            return pdList;
        }

        private void getPayDetails(ref payDetails pd, int pay_id, decimal pay_value, bool? freeHours)
        {
            switch (pay_id)
            {
                case 1:
                    if (freeHours.HasValue && !freeHours.Value)
                        pd.Actual += pay_value;
                    else
                        pd.Free += pay_value;
                    pd.Paid += pay_value;
                    break;
                case 2:
                    pd.mileage += pay_value;
                    break;
                case 3:
                    pd.Inspection += pay_value;
                    break;
                case 4:
                    pd.Paid += pay_value;
                    pd.Travel += pay_value;
                    break;
                case 5:
                    pd.Holiday += pay_value;
                    pd.Paid += pay_value;
                    break;
                case 6:
                    pd.Paid += pay_value;
                    break;
                case 7:
                    pd.Perdiem += pay_value;
                    break;
                case 8:
                    pd.Paid += pay_value;
                    pd.Vacation += pay_value;
                    break;
                case 9:
                    pd.Actual += pd.Actual;
                    pd.Paid += pay_value;
                    break;
                case 10:
                    pd.Actual += pd.Actual;
                    pd.Paid += pay_value;
                    break;
                case 11:
                    pd.Actual += pd.Actual;
                    pd.Paid += pay_value;
                    break;
                case 12:
                    pd.Actual += pd.Actual;
                    pd.Paid += pay_value;
                    break;
                case 13:
                    pd.Actual += pd.Actual;
                    pd.Paid += pay_value;
                    break;
                case 14:
                    pd.Actual += pd.Actual;
                    pd.Paid += pay_value;
                    break;
            }
        }
    }
}