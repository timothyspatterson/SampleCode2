﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Services;
using System.ComponentModel.DataAnnotations;

namespace BigBlue2.Web.Models.TraineeReviews
{
    public class CreateInput
    {
        public DateTime ReviewDate { get; set; }

        public DateTime ReviewTime { get; set; }

        public DateTime DateOfReview
        {
            get
            {
                return ReviewDate.Date.Add(ReviewTime.TimeOfDay);
            }
        }

        public Guid TraineeEmployeeId { get; set; }

        public string ProjectNo { get; set; }

        [Required(ErrorMessage="Driver's License answer is required")]
        public YesNoNA? DriversLicense { get; set; }

        [Required(ErrorMessage = "Safety Council Cards answer is required")]
        public YesNoNA? SafetyCouncilCards { get; set; }

        [Required(ErrorMessage = "Food/Drink answer is required")]
        public YesNoNA? FoodDrink { get; set; }

        [Required(ErrorMessage = "Tools/Equipment answer is required")]
        public YesNoNA? ToolsEquipment { get; set; }

        [Required(ErrorMessage = "Fire Extinguishers answer is required")]
        public YesNoNA? FireExtinguishers { get; set; }

        [Required(ErrorMessage = "Uniform answer is required")]
        public YesNoNA? Uniform { get; set; }

        [Required(ErrorMessage = "MMD answer is required")]
        public YesNoNA? MMD { get; set; }

        [Required(ErrorMessage = "PPE answer is required")]
        public YesNoNA? PPE { get; set; }

        [Required(ErrorMessage = "Tally/Record Book answer is required")]
        public YesNoNA? TallyRecordBook { get; set; }

        [Required(ErrorMessage = "Location of ESD answer is required")]
        public YesNoNA? LocationOfESD { get; set; }

        [Required(ErrorMessage = "Reporting Delays/Discrepancies answer is required")]
        public YesNoNA? ReportingDelaysDiscrepancies { get; set; }

        [Required(ErrorMessage = "Vessel Properly Secured/Moored answer is required")]
        public YesNoNA? VesselProperlySecuredMoored { get; set; }

        [Required(ErrorMessage = "Eye Wash/Emergency Shower Location answer is required")]
        public YesNoNA? EyeWashEmergencyShowerLocation { get; set; }

        [Required(ErrorMessage = "Verify Compare Orders - Tug, Dock, Relief answer is required")]
        public YesNoNA? VerifyCompareOrders { get; set; }

        [Required(ErrorMessage = "Safe Access to Vessel answer is required")]
        public YesNoNA? SafeAccessToVessel { get; set; }

        [Required(ErrorMessage = "Barge Housekeeping answer is required")]
        public YesNoNA? BargeHousekeeping { get; set; }

        [Required(ErrorMessage = "Valves, Plugs, Bleeder answer is required")]
        public YesNoNA? ValvesPlugsBleeder { get; set; }

        [Required(ErrorMessage = "Barge Documentation answer is required")]
        public YesNoNA? BargeDocumentation { get; set; }

        [Required(ErrorMessage = "Valve Alignment answer is required")]
        public YesNoNA? ValveAlignment { get; set; }

        [Required(ErrorMessage = "Fluid Level answer is required")]
        public YesNoNA? FluidLevel { get; set; }

        [Required(ErrorMessage = "Engine Check answer is required")]
        public YesNoNA? EngineCheck { get; set; }

        [Required(ErrorMessage = "Inital Rates & Shutdown answer is required")]
        public YesNoNA? InitialRatesAndShutdown { get; set; }

        [Required(ErrorMessage = "Breaking Vacuum answer is required")]
        public YesNoNA? BreakingVacuum { get; set; }

        [Required(ErrorMessage = "Pigging answer is required")]
        public YesNoNA? Pigging { get; set; }

        [Required(ErrorMessage = "Priming/Re-priming answer is required")]
        public YesNoNA? PrimingRepriming { get; set; }

        [Required(ErrorMessage = "Blowing/Draining answer is required")]
        public YesNoNA? BlowingDraining { get; set; }

        [Required(ErrorMessage = "Hose/Arm Connection answer is required")]
        public YesNoNA? HoseArmConnection { get; set; }

        [Required(ErrorMessage = "Gauge Rod Deployment answer is required")]
        public YesNoNA? GaugeRodDeployment { get; set; }

        [Required(ErrorMessage = "Bolt Alignment answer is required")]
        public YesNoNA? BoltAlignment { get; set; }

        [Required(ErrorMessage = "Leak Detection answer is required")]
        public YesNoNA? LeakDetection { get; set; }

        [Required(ErrorMessage = "Gasket Placement answer is required")]
        public YesNoNA? GasketPlacement { get; set; }

        [Required(ErrorMessage = "DOI Completion answer is required")]
        public YesNoNA? DOICompletion { get; set; }

        [Required(ErrorMessage = "Engine Operations answer is required")]
        public YesNoNA? EngineOperations { get; set; }

        [Required(ErrorMessage = "Re-priming Operations answer is required")]
        public YesNoNA? ReprimingOperations { get; set; }

        [Required(ErrorMessage = "Determing Rates answer is required")]
        public YesNoNA? DeterminingRates { get; set; }

        [Required(ErrorMessage = "Pump Bleeding Operations answer is required")]
        public YesNoNA? PumpBleedingOperations { get; set; }

        [Required(ErrorMessage = "Estimating Completion answer is required")]
        public YesNoNA? EstimatingCompletion { get; set; }

        [Required(ErrorMessage = "Monitoring Tank Levels answer is required")]
        public YesNoNA? MonitoringTankLevels { get; set; }

        [Required(ErrorMessage = "Stripping Operations answer is required")]
        public YesNoNA? StrippingOperations { get; set; }

        [Required(ErrorMessage = "Standby Notices answer is required")]
        public YesNoNA? StandbyNotices { get; set; }

        [Required(ErrorMessage = "Draining, Clearing, Blowing Dock Hose or Arm answer is required")]
        public YesNoNA? DrainingClearingBlowingDockHose { get; set; }

        [Required(ErrorMessage = "Controlling N2/Air Flow answer is required")]
        public YesNoNA? ControllingN2AirFlow { get; set; }

        [Required(ErrorMessage = "Securing Valves answer is required")]
        public YesNoNA? SecuringValves { get; set; }

        [Required(ErrorMessage = "Valve Alignment answer is required")]
        public YesNoNA? ShutDownValveAlignment { get; set; }

        [Required(ErrorMessage = "Securing Gauge Rods answer is required")]
        public YesNoNA? SecuringGaugeRods { get; set; }

        [Required(ErrorMessage = "Monitoring Levels answer is required")]
        public YesNoNA? MonitoringLevels { get; set; }

        [Required(ErrorMessage = "Scouring Gauge Rods answer is required")]
        public YesNoNA? ScouringGaugeRods { get; set; }

        [Required(ErrorMessage = "Verifying Orders Prior Disconnecting answer is required")]
        public YesNoNA? VerifyingOrdersPriorDisconnecting { get; set; }

        [Required(ErrorMessage = "Disconnect Sequence answer is required")]
        public YesNoNA? DisconnectSequence { get; set; }

        [Required(ErrorMessage = "Securing Drip Pan Covers answer is required")]
        public YesNoNA? SecuringDripPanCovers { get; set; }

        [Required(ErrorMessage = "Removing Bonding Cable answer is required")]
        public YesNoNA? RemovingBondingCable { get; set; }

        [Required(ErrorMessage = "Ensuring Proper Drainage answer is required")]
        public YesNoNA? EnsuringProperDrainage { get; set; }

        [Required(ErrorMessage = "Securing Valves Hatches answer is required")]
        public YesNoNA? SecuringValvesHatches { get; set; }

        [Required(ErrorMessage = "Securing Vapor Control Devices answer is required")]
        public YesNoNA? SecuringVaporControlDevices { get; set; }

        [Required(ErrorMessage = "Placement of Documentation answer is required")]
        public YesNoNA? PlacementOfDocumentation { get; set; }

        [Required(ErrorMessage = "PPE Comments are required")]
        public String PPEComments { get; set; }

        [Required(ErrorMessage = "Mechanics Comments are required")]
        public String MechanicsComments { get; set; }

        [Required(ErrorMessage = "Judgement Comments are required")]
        public String JudgementComments { get; set; }

        [Required(ErrorMessage = "Demeanor Comments are required")]
        public String DemeanorComments { get; set; }

        [Required(ErrorMessage = "Work Ethic Comments are required")]
        public String WorkEthicComments { get; set; }

        [Required(ErrorMessage = "Skill Level Comments are required")]
        public String SkillLevelComments { get; set; }

        [Required(ErrorMessage = "Knowledge Comments are required")]
        public String KnowledgeComments { get; set; }

        [Required(ErrorMessage = "Retention Comments are required")]
        public String RetentionComments { get; set; }

        public string Comments { get; set; }
    }
}