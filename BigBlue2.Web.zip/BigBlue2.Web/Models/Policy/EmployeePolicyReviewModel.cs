﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BigBlue2.Web.Models.Policy
{
    public class EmployeePolicyReviewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public bool IsReviewed { get; set; }
        public bool IsAccepted { get; set; }
        public string AcceptType { get; set; }
        public DateTime AcceptDate { get; set; }
        public string Notes { get; set; }
    }
}