﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BigBlue2.Web.Models.Policy
{
    public class PolicyWidget
    {
        public int PolicyId { get; set; }
        public string PolicyName { get; set; }
        public string PolicyChangeAction { get; set; }
        public string StatusMessage { get; set; }
        public bool IsAccepted { get; set; }
        public DateTime ? ReviewDate { get; set; }
        public string Info1Label { get; set; }
        public string Info2Label { get; set; }
        public string Info1Value { get; set; }
        public string Info2Value { get; set; }
        public string PolicyIcon { get; set; }
    }
}