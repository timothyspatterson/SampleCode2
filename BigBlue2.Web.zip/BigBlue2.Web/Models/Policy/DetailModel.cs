﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BigBlue2.Web.Models.Policy
{
    public class DetailModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<EmployeePolicyReviewModel> EmployeeList { get; set; }
    }
}