﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BigBlue2.Web.Models.Policy
{
    public class IndexModel
    {
        public List<BigBlue2.Data.EmployeePolicy> Policies { get; set; }
    }
}