﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;

namespace BigBlue2.Web.Models.Notifications
{
    public class CreateForProjectModel
    {
        public SelectList Boats { get; private set; }

        public SelectList Customers { get; private set; }

        public SelectList Ports { get; private set; }

        public SelectList Locations { get; private set; }

        public SelectList ProjectLocations { get; private set; }

        public SelectList Barges { get; private set; }

        public CreateForProjectModel(IEnumerable<Boat> boats, IEnumerable<Customer> customers, IEnumerable<Port> ports,
            IEnumerable<Location> locations, IEnumerable<ProjectLocation> projectLocations, IEnumerable<Barge> barges)
        {
            Boats = new SelectList(boats, "Id", "Name");
            Customers = new SelectList(customers, "Id", "Name");
            Ports = new SelectList(ports, "Id", "Name");
            Locations = new SelectList(locations, "Id", "Name");
            ProjectLocations = new SelectList(projectLocations, "Id", "Name");
            Barges = new SelectList(barges, "Id", "Name");
        }
    }
}