﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;

namespace BigBlue2.Web.Models.Notifications
{
    public class TankermanModel
    {
        public IEnumerable<AcceptedNotification> AcceptedNotifications { get; set; }

        public IEnumerable<TankermanNotification> NotAcceptedNotifications { get; set; }

        public TankermanModel()
        {
            AcceptedNotifications = new List<AcceptedNotification>();
            NotAcceptedNotifications = new List<TankermanNotification>();
        }
    }
}