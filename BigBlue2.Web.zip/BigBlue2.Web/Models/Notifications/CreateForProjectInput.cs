﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using System.ComponentModel;

namespace BigBlue2.Web.Models.Notifications
{
    public class CreateForProjectInput :IValidatableObject
    {
        public Guid? BoatId { get; set; }

        public Guid? CustomerId { get; set; }

        public Guid? PortId { get; set; }

        public Guid? LocationId { get; set; }

        public Guid? BargeId { get; set; }

        public short? ProjectLocationId { get; set; }

        [Required]
        [AllowHtml]
        [DisplayName("message")]
        public string Message { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (!BoatId.HasValue && !CustomerId.HasValue && !PortId.HasValue && !LocationId.HasValue &&
                !BargeId.HasValue && !ProjectLocationId.HasValue)
            {
                yield return new ValidationResult("You must specify one of the following:",
                    new string[] { "BoatId", "CustomerId", "PortId", "LocationId", "BargeId", "ProjectLocationId", "" });
            }

            yield break;
        }
    }
}