﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;

namespace BigBlue2.Web.Models.Notifications
{
    public class CreateForTankermanModel
    {
        public SelectList TankermanGroups { get; private set; }

        public CreateForTankermanModel(IEnumerable<TankermanGroup> groups)
        {
            TankermanGroups = new SelectList(groups, "Id", "Name");
        }
    }
}