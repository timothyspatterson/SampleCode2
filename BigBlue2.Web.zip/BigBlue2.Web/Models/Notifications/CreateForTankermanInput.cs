﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace BigBlue2.Web.Models.Notifications
{
    public class CreateForTankermanInput
    {
        public int? TankermanGroupId { get; set; }

        [Required]
        [AllowHtml]
        public string Message { get; set; }
    }
}