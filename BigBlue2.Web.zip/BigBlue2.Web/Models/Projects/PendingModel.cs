﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;

namespace BigBlue2.Web.Models.Projects
{
    public class PendingModel
    {
        public int Total { get; set; }

        public IEnumerable<IGrouping<string, ProjectSummary>> Projects { get; set; }

        public Dictionary<string, int> TotalsByGroup { get; set; }
    }
}