﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BigBlue2.Web.Models.Projects
{
    public class ProjectInfoModel
    {
        public string Facility { get; set; }

        public string Barge { get; set; }

        public string Operation { get; set; }  
    }
}