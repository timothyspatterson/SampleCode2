﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BigBlue2.Web.Models.Shared
{
    public class RadioButtonModel
    {
        public string Name { get; private set; }

        public string DisplayName { get; private set; }

        public string Value { get; private set; }

        public RadioButtonModel(string name, string displayName, string value)
        {
            Name = name;
            DisplayName = displayName;
            Value = value;
        }

        public RadioButtonModel(string name, string displayName) : this(name, displayName, null)
        {

        }
    }
}