﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace BigBlue2.Web.Models.Shared
{
    public class FeedbackModel
    {
        public string Type { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Message is required")]
        [System.Web.Mvc.AllowHtml]
        public string Message { get; set; }
        public string CreatedBy { get; set; }
        public DateTime DateCreated { get; set; }
    }
}