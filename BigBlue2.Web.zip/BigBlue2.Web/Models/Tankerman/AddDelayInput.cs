﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace BigBlue2.Web.Models.Tankerman
{
    public class AddDelayInput : IValidatableObject
    {
        public int DelayTypeId { get; set; }

        public string DelayDescription { get; set; }

        [Required]
        [DisplayName("start date")]
        public DateTime? DelayStartDate { get; set; }

        [Required]
        [DisplayName("end date")]
        public DateTime? DelayEndDate { get; set; }

        public DateTime Start
        {
            get
            {
                return DelayStartDate.Value.Date.Add(DelayStartTime.Value.TimeOfDay);
            }
        }

        public DateTime End
        {
            get
            {
                return DelayEndDate.Value.Date.Add(DelayEndTime.Value.TimeOfDay);
            }
        }

        [Required]
        [DisplayName("start time")]
        public DateTime? DelayStartTime { get; set; }

        [Required]
        [DisplayName("end time")]
        public DateTime? DelayEndTime { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (End <= Start)
            {
                yield return new ValidationResult("End date and time must be greater than start date and time", new[] { "" });
            }
        }
    }
}