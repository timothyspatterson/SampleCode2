﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;

namespace BigBlue2.Web.Models.Tankerman
{
    public class StatusModel
    {
        public bool AssignedToProject { get; set; }

        public string ProjectDispatchInfo { get; set; }

        public string RotationNo { get; set; }

        public string StatusMessage { get; set; }

        public Barge PrimaryBarge { get; set; }

        public string Location { get; set; }

        public string Port { get; set; }

        public string Dock { get; set; }

        public string Boat { get; set; }

        public string Product { get; set; }

        public string Operation { get; set; }

        public string MaxDraft { get; set; }

        public IEnumerable<Barge> Barges { get; set; }

        public bool BargeConfirmed { get; set; }

        public string ProjectNo { get; set; }

        public Guid EmployeeRowId { get; set; } 

        public string EmployeeName { get; set; }

        public DateTime? DateTimesLastSubmitted { get; set; }

        public IEnumerable<ProjectNotification> Notifications { get; set; }

        public StatusModel()
        {
            Notifications = new List<ProjectNotification>();
        }
    }
}