﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;
using System.Web.Mvc;

namespace BigBlue2.Web.Models.Tankerman
{
    public class EnterTimesModel
    {
        #region Barge Times
        public string ProjectName { get; set; }

        public string ProjectNo { get; set; }

        public string ArriveDate { get; set; }

        public string ArriveTime { get; set; }

        public string DockDate { get; set; }

        public string DockTime { get; set; }

        public string ConnectDate { get; set; }

        public string ConnectTime { get; set; } 

        public string ConnectXOverDate { get; set; }

        public string ConnectXOverTime { get; set; } 

        public string ConnectVaporDate { get; set; }

        public string ConnectVaporTime { get; set; }

        public string StartTransferDate { get; set; }

        public string StartTransferTime { get; set; }

        public string FinishTransferDate { get; set; }

        public string FinishTransferTime { get; set; }

        public string DisconnectDate { get; set; }

        public string DisconnectTime { get; set; }

        public string DisconnectXOverDate { get; set; }

        public string DisconnectXOverTime { get; set; }

        public string DisconnectVaporDate { get; set; }

        public string DisconnectVaporTime { get; set; }

        public string BargeReleasedDate { get; set; }

        public string BargeReleasedTime { get; set; }

        #endregion

        #region Drafts
        public string DraftsOpenedBP { get; set; }
        public string DraftsOpenedBS { get; set; }
        public string DraftsOpenedSP { get; set; }
        public string DraftsOpenedSS { get; set; }

        public string DraftsClosedBP { get; set; }
        public string DraftsClosedBS { get; set; }
        public string DraftsClosedSP { get; set; }
        public string DraftsClosedSS { get; set; }
        #endregion

        #region Inspection
        public DateTime? COI { get; set; }

        public DateTime? CFR { get; set; }

        public DateTime? Pipe { get; set; }

        public DateTime? Vapor { get; set; }

        public DateTime? XOver { get; set; }

        public string FuelLevel { get; set; }

        public string OilLevel { get; set; }

        public int? RPM { get; set; }

        public int? OilPressure { get; set; }

        public int? DischargePressure { get; set; }

        public int? Temp { get; set; }
        #endregion

        #region Employee Times
        public string TankermanArriveTime { get; set; }
        public string TankermanArriveDate { get; set; }
        public string TankermanDepartTime { get; set; }
        public string TankermanDepartDate { get; set; }
        public decimal Mileage { get; set; }
        #endregion

        public SelectList DelayTypes { get; set; }

        public SelectList Levels { get; set; }

        public IEnumerable<TransitionQueueDelayEntry> Delays { get; set; }

        public EnterTimesModel(Project project, IEnumerable<DelayType> delayTypes, decimal mileage)
        {
            ProjectName = project.ProjectName;
            ProjectNo = project.No;

            DateTime date;

            if (!String.IsNullOrEmpty(project.LDDetail.ArriveDate))
            {
                date = Convert.ToDateTime(project.LDDetail.ArriveDate);
                ArriveDate = date.Date.ToString("MM/dd/yy");
                ArriveTime = date.TimeOfDay.ToString();
            }

            if (!String.IsNullOrEmpty(project.LDDetail.DockDate))
            {
                date = Convert.ToDateTime(project.LDDetail.DockDate);
                DockDate = date.Date.ToString("MM/dd/yy");
                DockTime = date.TimeOfDay.ToString();
            }

            if (!String.IsNullOrEmpty(project.LDDetail.ConnectDate))
            {
                date = Convert.ToDateTime(project.LDDetail.ConnectDate);
                ConnectDate = date.Date.ToString("MM/dd/yy");
                ConnectTime = date.TimeOfDay.ToString();
            }

            if (!String.IsNullOrEmpty(project.LDDetail.ConnectXDate))
            {
                date = Convert.ToDateTime(project.LDDetail.ConnectXDate);
                ConnectXOverDate = date.Date.ToString("MM/dd/yy");
                ConnectXOverTime = date.TimeOfDay.ToString();
            }

            if (!String.IsNullOrEmpty(project.LDDetail.ConnectVapor))
            {
                date = Convert.ToDateTime(project.LDDetail.ConnectVapor);
                ConnectVaporDate = date.Date.ToString("MM/dd/yy");
                ConnectVaporTime = date.TimeOfDay.ToString();
            }

            if (!String.IsNullOrEmpty(project.LDDetail.StartTransferDate))
            {
                date = Convert.ToDateTime(project.LDDetail.StartTransferDate);
                StartTransferDate = date.Date.ToString("MM/dd/yy");
                StartTransferTime = date.TimeOfDay.ToString();
            }

            if (!String.IsNullOrEmpty(project.LDDetail.FinishTransferDate))
            {
                date = Convert.ToDateTime(project.LDDetail.FinishTransferDate);
                FinishTransferDate = date.Date.ToString("MM/dd/yy");
                FinishTransferTime = date.TimeOfDay.ToString();
            }

            if (!String.IsNullOrEmpty(project.LDDetail.DisconnectDate))
            {
                date = Convert.ToDateTime(project.LDDetail.DisconnectDate);
                DisconnectDate = date.Date.ToString("MM/dd/yy");
                DisconnectTime = date.TimeOfDay.ToString();
            }

            if (!String.IsNullOrEmpty(project.LDDetail.DisconnectXDate))
            {
                date = Convert.ToDateTime(project.LDDetail.DisconnectXDate);
                DisconnectXOverDate = date.Date.ToString("MM/dd/yy");
                DisconnectXOverTime = date.TimeOfDay.ToString();
            }

            if (!String.IsNullOrEmpty(project.LDDetail.DisconnectVaporDate))
            {
                date = Convert.ToDateTime(project.LDDetail.DisconnectVaporDate);
                DisconnectVaporDate = date.Date.ToString("MM/dd/yy");
                DisconnectVaporTime = date.TimeOfDay.ToString();
            }

            if (!String.IsNullOrEmpty(project.LDDetail.BargeReleasedDate))
            {
                date = Convert.ToDateTime(project.LDDetail.BargeReleasedDate);
                BargeReleasedDate = date.Date.ToString("MM/dd/yy");
                BargeReleasedTime = date.TimeOfDay.ToString();
            }

            DraftsClosedBP = project.LDDetail.ClosedDraftsBpNormalized;
            DraftsClosedBS = project.LDDetail.ClosedDraftsBsNormalized;
            DraftsClosedSP = project.LDDetail.ClosedDraftsSpNormalized;
            DraftsClosedSS = project.LDDetail.ClosedDraftsSsNormalized;

            DraftsOpenedBP = project.LDDetail.ClosedDraftsBpNormalized;
            DraftsOpenedBS = project.LDDetail.ClosedDraftsBsNormalized;
            DraftsOpenedSP = project.LDDetail.ClosedDraftsSpNormalized;
            DraftsOpenedSS = project.LDDetail.ClosedDraftsSsNormalized;

            Mileage = mileage;

            //if (project.BargeInspection != null)
            //{
            //    if (DateTime.TryParse(project.BargeInspection.COI, out date))
            //    {
            //        COI = date;
            //    }

            //    if (DateTime.TryParse(project.BargeInspection.CFR, out date))
            //    {
            //        CFR = date;
            //    }

            //    if (DateTime.TryParse(project.BargeInspection.Pipe, out date))
            //    {
            //        Pipe = date;
            //    }

            //    if (DateTime.TryParse(project.BargeInspection.Vapor, out date))
            //    {
            //        Vapor = date;
            //    }

            //    if (DateTime.TryParse(project.BargeInspection.XOver, out date))
            //    {
            //        XOver = date;
            //    }

            //    if (!String.IsNullOrEmpty(project.BargeInspection.FuelLevel))
            //    {
            //        FuelLevel = project.BargeInspection.FuelLevel;
            //    }

            //    if (!String.IsNullOrEmpty(project.BargeInspection.OilLevel))
            //    {
            //        OilLevel = project.BargeInspection.OilLevel;
            //    }

            //    int result;

            //    if (Int32.TryParse(project.BargeInspection.RPM, out result))
            //    {
            //        RPM = result;
            //    }

            //    if (Int32.TryParse(project.BargeInspection.OilPressure, out result))
            //    {
            //        OilPressure = result;
            //    }

            //    if (Int32.TryParse(project.BargeInspection.DischargePressure, out result))
            //    {
            //        DischargePressure = result;
            //    }

            //    if (Int32.TryParse(project.BargeInspection.Temp, out result))
            //    {
            //        Temp = result;
            //    }
            //}

            DelayTypes = new SelectList(delayTypes, "Id", "Name");

            Levels = new SelectList(GenerateLevels());
        }

        private IEnumerable<string> GenerateLevels()
        {
            yield return "EMPTY";
            yield return "1/4";
            yield return "1/2";
            yield return "3/4";
            yield return "FULL";
        }
    }
}