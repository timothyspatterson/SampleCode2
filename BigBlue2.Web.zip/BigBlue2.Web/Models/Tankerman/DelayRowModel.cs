﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;

namespace BigBlue2.Web.Models.Tankerman
{
    public class DelayRowModel
    {
        public int DelayTypeId { get; set; }

        public string Description { get; set; }

        public DateTime StartTime { get; set; }

        public DateTime EndTime { get; set; }

        public string Key
        {
            get
            {
                return String.Format("{0}{1}{2}", DelayTypeId, StartTime, EndTime);
            }
        }

        public DelayRowModel() { }

        public DelayRowModel(TransitionQueueDelayEntry delay)
        {
            DelayTypeId = delay.DelayTypeId;
            Description = delay.Description;
            StartTime = delay.StartTime;
            EndTime = delay.EndTime;
        }
    }
}