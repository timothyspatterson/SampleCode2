﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using BigBlue2.Data;

namespace BigBlue2.Web.Models.Tankerman
{
    public class EnterTimesInput : IValidatableObject
    {
        public EnterTimesInput()
        {
            Delays = new List<TransitionQueueDelayEntry>();
        }

        #region BargeTimes
        public DateTime? ArriveDate { get; set; }

        public DateTime? ArriveTime
        {
            get;
            set;
        }
        public DateTime? Arrive
        {
            get
            {
                if (ArriveDate.HasValue && ArriveTime.HasValue)
                {
                    return ArriveDate.Value.Date.Add(ArriveTime.Value.TimeOfDay);
                }

                return null;
            }
        }

        public DateTime? DockDate { get; set; }
        public DateTime? DockTime { get; set; }
        public DateTime? Dock
        {
            get
            {
                if (DockDate.HasValue && DockTime.HasValue)
                {
                    return DockDate.Value.Date.Add(DockTime.Value.TimeOfDay);
                }

                return null;
            }
        }

        public DateTime? ConnectDate { get; set; }
        public DateTime? ConnectTime { get; set; }
        public DateTime? Connect
        {
            get
            {
                if (ConnectDate.HasValue && ConnectTime.HasValue)
                {
                    return ConnectDate.Value.Date.Add(ConnectTime.Value.TimeOfDay);
                }

                return null;
            }
        }

        public DateTime? ConnectXOverDate { get; set; }
        public DateTime? ConnectXOverTime { get; set; }
        public DateTime? ConnectXOver
        {
            get
            {
                if (ConnectXOverDate.HasValue && ConnectXOverTime.HasValue)
                {
                    return ConnectXOverDate.Value.Date.Add(ConnectXOverTime.Value.TimeOfDay);
                }

                return null;
            }
        }

        public DateTime? ConnectVaporDate { get; set; }
        public DateTime? ConnectVaporTime { get; set; }
        public DateTime? ConnectVapor
        {
            get
            {
                if (ConnectVaporDate.HasValue && ConnectVaporTime.HasValue)
                {
                    return ConnectVaporDate.Value.Date.Add(ConnectVaporTime.Value.TimeOfDay);
                }

                return null;
            }
        }

        public DateTime? StartTransferDate { get; set; }
        public DateTime? StartTransferTime { get; set; }
        public DateTime? StartTransfer
        {
            get
            {
                if (StartTransferDate.HasValue && StartTransferTime.HasValue)
                {
                    return StartTransferDate.Value.Date.Add(StartTransferTime.Value.TimeOfDay);
                }

                return null;
            }
        }

        public DateTime? FinishTransferDate { get; set; }
        public DateTime? FinishTransferTime { get; set; }
        public DateTime? FinishTransfer
        {
            get
            {
                if (FinishTransferDate.HasValue && FinishTransferTime.HasValue)
                {
                    return FinishTransferDate.Value.Date.Add(FinishTransferTime.Value.TimeOfDay);
                }

                return null;
            }
        }

        public DateTime? DisconnectDate { get; set; }
        public DateTime? DisconnectTime { get; set; }
        public DateTime? Disconnect
        {
            get
            {
                if (DisconnectDate.HasValue && DisconnectTime.HasValue)
                {
                    return DisconnectDate.Value.Date.Add(DisconnectTime.Value.TimeOfDay);
                }

                return null;
            }
        }

        public DateTime? DisconnectXOverDate { get; set; }
        public DateTime? DisconnectXOverTime { get; set; }
        public DateTime? DisconnectXOver
        {
            get
            {
                if (DisconnectXOverDate.HasValue && DisconnectXOverTime.HasValue)
                {
                    return DisconnectXOverDate.Value.Date.Add(DisconnectXOverTime.Value.TimeOfDay);
                }

                return null;
            }
        }

        public DateTime? DisconnectVaporDate { get; set; }
        public DateTime? DisconnectVaporTime { get; set; }
        public DateTime? DisconnectVapor
        {
            get
            {
                if (DisconnectVaporDate.HasValue && DisconnectVaporTime.HasValue)
                {
                    return DisconnectVaporDate.Value.Date.Add(DisconnectVaporTime.Value.TimeOfDay);
                }

                return null;
            }
        }

        public DateTime? BargeReleasedDate { get; set; }
        public DateTime? BargeReleasedTime { get; set; }
        public DateTime? BargeReleased
        {
            get
            {
                if (BargeReleasedDate.HasValue && BargeReleasedTime.HasValue)
                {
                    return BargeReleasedDate.Value.Date.Add(BargeReleasedTime.Value.TimeOfDay);
                }

                return null;
            }
        }
        #endregion

        #region Drafts
        public string DraftsOpenedBP { get; set; }
        public string DraftsOpenedBS { get; set; }
        public string DraftsOpenedSP { get; set; }
        public string DraftsOpenedSS { get; set; }

        public string DraftsClosedBP { get; set; }
        public string DraftsClosedBS { get; set; }
        public string DraftsClosedSP { get; set; }
        public string DraftsClosedSS { get; set; }
        #endregion Drafts

        #region Inspection
        public DateTime? COI { get; set; }

        public DateTime? CFR { get; set; }

        public DateTime? Pipe { get; set; }

        public DateTime? Vapor { get; set; }

        public DateTime? XOver { get; set; }

        public string FuelLevel { get; set; }

        public string OilLevel { get; set; }

        public int? RPM { get; set; }

        public int? OilPressure { get; set; }

        public int? DischargePressure { get; set; }

        public int? Temp { get; set; }
        #endregion

        #region Employee Times
        public DateTime? TankermanArriveDate { get; set; }

        public DateTime? TankermanArriveTime
        {
            get;
            set;
        }
        public DateTime? TankermanArrive
        {
            get
            {
                if (TankermanArriveDate.HasValue && TankermanArriveTime.HasValue)
                {
                    return TankermanArriveDate.Value.Date.Add(TankermanArriveTime.Value.TimeOfDay);
                }

                return null;
            }
        }

        public DateTime? TankermanDepartDate { get; set; }

        public DateTime? TankermanDepartTime
        {
            get;
            set;
        }
        public DateTime? TankermanDepart
        {
            get
            {
                if (TankermanDepartDate.HasValue && TankermanDepartTime.HasValue)
                {
                    return TankermanDepartDate.Value.Date.Add(TankermanDepartTime.Value.TimeOfDay);
                }

                return null;
            }
        }
        #endregion

        public string Comments { get; set; }

        public string ProjectNo { get; set; }

        public List<TransitionQueueDelayEntry> Delays { get; set; }

        private bool CheckDateAndTimeSubmittedProperly(DateTime? date, DateTime? time)
        {
            if (date.HasValue && time.HasValue)
            {
                return true;
            }

            if (!date.HasValue && !time.HasValue)
            {
                return true;
            }

            return false;
        }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (!CheckDateAndTimeSubmittedProperly(ArriveDate, ArriveTime))
            {
                yield return new ValidationResult("Arrive date and time must both be completed or both blank", new[] {"ArriveTime", "ArriveDate", "", "BargeTimes"});
            }

            if (!CheckDateAndTimeSubmittedProperly(DockDate, DockTime))
            {
                yield return new ValidationResult("Dock date and time must both be completed or both blank", new[] { "DockTime", "DockDate", "", "BargeTimes" });
            }

            if (!CheckDateAndTimeSubmittedProperly(ConnectDate, ConnectTime))
            {
                yield return new ValidationResult("Connect date and time must both be completed or both blank", new[] { "ConnectTime", "ConnectDate", "", "BargeTimes" });
            }

            if (!CheckDateAndTimeSubmittedProperly(ConnectXOverDate, ConnectXOverTime))
            {
                yield return new ValidationResult("Connect x-over date and time must both be completed or both blank", new[] { "ConnectXOverTime", "ConnectXOverDate", "", "BargeTimes" });
            }

            if (!CheckDateAndTimeSubmittedProperly(ConnectVaporDate, ConnectVaporTime))
            {
                yield return new ValidationResult("Connect vapor date and time must both be completed or both blank", new[] { "ConnectVaporTime", "ConnectVaporDate", "", "BargeTimes" });
            }

            if (!CheckDateAndTimeSubmittedProperly(StartTransferDate, StartTransferTime))
            {
                yield return new ValidationResult("Start transfer date and time must both be completed or both blank", new[] { "StartTransferTime", "StartTransferDate", "", "BargeTimes" });
            }

            if (!CheckDateAndTimeSubmittedProperly(FinishTransferDate, FinishTransferTime))
            {
                yield return new ValidationResult("Finish transfer date and time must both be completed or both blank", new[] { "FinishTransferTime", "FinishTransferDate", "", "BargeTimes" });
            }

            if (!CheckDateAndTimeSubmittedProperly(DisconnectDate, DisconnectTime))
            {
                yield return new ValidationResult("Disconnect date and time must both be completed or both blank", new[] { "DisconnectTime", "DisconnectDate", "", "BargeTimes" });
            }

            if (!CheckDateAndTimeSubmittedProperly(DisconnectXOverDate, DisconnectXOverTime))
            {
                yield return new ValidationResult("Disconnect x-over date and time must both be completed or both blank", new[] { "DisconnectXOverTime", "DisconnectXOverDate", "", "BargeTimes" });
            }

            if (!CheckDateAndTimeSubmittedProperly(DisconnectVaporDate, DisconnectVaporTime))
            {
                yield return new ValidationResult("Disconnect vapor date and time must both be completed or both blank", new[] { "DisconnectVaporTime", "DisconnectVaporDate", "", "BargeTimes" });
            }

            if (!CheckDateAndTimeSubmittedProperly(BargeReleasedDate, BargeReleasedTime))
            {
                yield return new ValidationResult("Barge released date and time must both be completed or both blank", new[] { "BargeReleasedTime", "BargeReleasedTime", "", "BargeTimes" });
            }

            if (!CheckDateAndTimeSubmittedProperly(TankermanArriveDate, TankermanArriveTime))
            {
                yield return new ValidationResult("Tankerman arrive date and time must both be completed or both blank", new[] { "TankermanArriveTime", "TankermanArriveTime", "", "EmployeeTimes" });
            }

            if (!CheckDateAndTimeSubmittedProperly(TankermanDepartDate, TankermanDepartTime))
            {
                yield return new ValidationResult("Tankerman depart date and time must both be completed or both blank", new[] { "TankermanArriveTime", "TankermanArriveTime", "", "EmployeeTimes" });
            }

            if (TankermanArrive.HasValue && TankermanDepart.HasValue && TankermanArrive > TankermanDepart)
            {
                yield return new ValidationResult("Tankerman depart date must be after tankerman arrive date", new[] { "TankermanArriveTime", "TankermanArriveTime", "", "EmployeeTimes" });
            }
        }
    }
}