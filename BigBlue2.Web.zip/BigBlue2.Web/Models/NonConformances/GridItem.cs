﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;

namespace BigBlue2.Web.Models.NonConformances
{
    public class GridItem
    {
        public int NonConformanceId { get; set; }

        public string CreatedBy { get; set; }

        public string Employee { get; set; }

        public string Vendor { get; set; }

        public string Customer { get; set; }

        public DateTime Date { get; set; }

        public bool IsClosed { get; set; }

        public bool CustomerComplaint { get; set; }

        public GridItem(NonConformance nonConformance)
        {
            NonConformanceId = nonConformance.Id;

            CreatedBy = nonConformance.CreatedBy;

            if (nonConformance.Employee != null)
            {
                Employee = nonConformance.Employee.FullName;
            }
            if (nonConformance.Vendor != null)
            {
                Vendor = nonConformance.Vendor.Name;
            }
            //Category = nonConformance.Category.Name;

            Customer = nonConformance.Customer.Name;

            Date = nonConformance.Date;

            IsClosed = nonConformance.IsClosed;

            CustomerComplaint = nonConformance.CustomerComplaint;
        }
    }
}