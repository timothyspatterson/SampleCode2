﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;
using BigBlue2.Services;
using System.Web.Mvc;
using System.Web.Security;

namespace BigBlue2.Web.Models.NonConformances
{
    public class AddNotificationModel
    {
        public int NonConformanceId { get; set; }

        public SelectList Customers { get; set; }

        public string CreatedBy { get; set; }

        public string DateNotified { get; set; }

        public AddNotificationModel(int nonConformanceId, IEnumerable<Customer> customers)
        {
            NonConformanceId = nonConformanceId;
            Customers = new SelectList(customers.OrderBy(c => c.Name), "Id", "Name");
            CreatedBy = Membership.GetUser().UserName;
            DateNotified = DateTime.Now.To24HourDateTimeString();
        }
    }
}