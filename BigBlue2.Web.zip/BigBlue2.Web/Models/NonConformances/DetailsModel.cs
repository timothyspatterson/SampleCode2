﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;
using BigBlue2.Services;
using System.Web.Mvc;

namespace BigBlue2.Web.Models.NonConformances
{
    public class DetailsModel
    {
        public int NonConformanceId { get; set; }

        public string Customer { get; set; }

        public string ProjectLocation { get; set; }

        public string Barge { get; set; }

        public string Boat { get; set; }

        public string Product { get; set; }

        public string Operation { get; set; }

        public string Date { get; set; }

        public string Employees { get; set; }

        public string Vendor { get; set; }

        public string Description { get; set; }

        public bool IsClosed { get; set; }

        public string ClosedBy { get; set; }

        public string DateClosed { get; set; }

        public string ReopenedBy { get; set; }

        public string DateReopened { get; set; }

        public string CreatedBy { get; set; }

        public bool OpsMgr { get; set; }

        public bool VpOps { get; set; }

        public bool ExecVp { get; set; }

        public bool VpAdmin { get; set; }

        public bool SafetyTrainingComp { get; set; }

        public bool LaFieldSup { get; set; }

        public bool TxFieldSup { get; set; }

        public bool Dispatch { get; set; }

        public bool AccountingPayroll { get; set; }

        public bool NonIssue { get; set; }

        public bool CustomerComplaint { get; set; }

        public bool CustomerNotified { get; set; }

        public bool AccutransAtFault { get; set; }

        public int? AtFaultReasonId { get; set; }

        public int Stage1CategoryId { get; set; }

        public IEnumerable<NonConformanceComment> Comments { get; set; }

        public IEnumerable<NonConformanceComment> ImmediateActionsTaken { get; set; }

        public IEnumerable<NonConformanceComment> CorrectiveActions { get; set; }

        public IEnumerable<NotificationGridItem> Notifications { get; set; }

        public IEnumerable<QPECategory> Categories { get; set; }

        public IEnumerable<NonConformanceFaultArea> AtFaultAreas { get; set; }

        public AddNotificationModel AddNotificationModel { get; set; }

        public IEnumerable<Stage1QPECategory> Stage1Categories { get; set; }
        public IEnumerable<Stage2QPECategory> Stage2Categories { get; set; }
        public IEnumerable<Stage3QPECategory> Stage3Categories { get; set; }
        public DetailsModel(NonConformance nonConformance, IEnumerable<Customer> customers, IEnumerable<Stage1QPECategory> stage1Categories, IEnumerable<Stage2QPECategory> stage2Categories, IEnumerable<Stage3QPECategory> stage3Categories, IEnumerable<NonConformanceFaultArea> atfaultAreas) 
        {
            //Stage1Categories = new SelectList(stage1Categories, "Id", "Name");
            //Stage2Categories = new SelectList(stage2Categories, "Id", "Name");
            //Stage3Categories = new SelectList(stage3Categories, "Id", "Name");
            Stage1Categories = stage1Categories;
            Stage2Categories = stage2Categories;
            Stage3Categories = stage3Categories;
            AtFaultAreas = atfaultAreas;
            Comments = new List<NonConformanceComment>();
            ImmediateActionsTaken = new List<NonConformanceComment>();
            CorrectiveActions = new List<NonConformanceComment>();
            Notifications = new List<NotificationGridItem>();

            if (nonConformance.ProjectSummary == null)
            {
                Customer = nonConformance.Customer.Name;
                ProjectLocation = nonConformance.ProjectLocation.Name;
                Barge = nonConformance.Barge.Name;
                Boat = nonConformance.Boat.Name;
                Product = nonConformance.ProductName;
                Operation = nonConformance.Operation.Name;
            }
            else
            {
                Customer = nonConformance.ProjectSummary.CustomerName;
                ProjectLocation = nonConformance.ProjectSummary.ProjectLocationName;
                Barge = nonConformance.ProjectSummary.BargeName;
                Boat = nonConformance.ProjectSummary.BoatName;
                Product = nonConformance.ProjectSummary.Product;
                Operation = nonConformance.ProjectSummary.Operation;
            }

            Date = nonConformance.Date.To24HourDateTimeString();
            string emps = "";
            if (nonConformance.Employee != null)
                emps += nonConformance.Employee.FullName;
            if (nonConformance.Employee2 != null)
                emps += ", " + nonConformance.Employee2.FullName; 
            if (nonConformance.Employee3 != null)
                emps += ", " + nonConformance.Employee3.FullName;
            if (nonConformance.Employee4 != null)
                emps += ", " + nonConformance.Employee4.FullName;
            if (!String.IsNullOrEmpty(emps))
            {
                Employees = emps;
            }
            if (nonConformance.Vendor != null)
            {
                Vendor = nonConformance.Vendor.Name;
            }
            Categories = nonConformance.QPECategories;
            Description = nonConformance.Description;
            IsClosed = nonConformance.IsClosed;
            CreatedBy = nonConformance.CreatedBy;
            NonConformanceId = nonConformance.Id;

            OpsMgr = nonConformance.OpsMgr;
            VpOps = nonConformance.VpOps;
            ExecVp = nonConformance.ExecVp;
            VpAdmin = nonConformance.VpAdmin;
            SafetyTrainingComp = nonConformance.SafetyTrainingComp;
            LaFieldSup = nonConformance.LaFieldSup;
            TxFieldSup = nonConformance.TxFieldSup;
            Dispatch = nonConformance.Dispatch;
            AccountingPayroll = nonConformance.AccountingPayroll;
            NonIssue = (nonConformance.non_issue.HasValue ? nonConformance.non_issue.Value : false);
            CustomerNotified = (nonConformance.cust_notified.HasValue ? nonConformance.cust_notified.Value : false);
            AccutransAtFault = (!String.IsNullOrEmpty(nonConformance.accu_at_fault) && nonConformance.accu_at_fault.ToLower() == "yes") ? true : false;
            AtFaultReasonId = nonConformance.at_fault_reason_id;
            ClosedBy = nonConformance.ClosedBy;
            DateClosed = nonConformance.DateClosed.HasValue ? nonConformance.DateClosed.Value.To24HourDateTimeString() : null;
            ReopenedBy = nonConformance.ReopenedBy;
            DateReopened = nonConformance.DateReopened.HasValue ? nonConformance.DateReopened.Value.To24HourDateTimeString() : null;

            Notifications = from n in nonConformance.Notifications.OrderByDescending(n => n.DateCreated)
                            select new NotificationGridItem(n);

            var groupedComments = nonConformance.Comments.GroupBy(c => c.Type);

            foreach (var comments in groupedComments)
            {
                if (comments.Key == BigBlue2.Services.NonConformances.CommentTypes.Comment)
                {
                    Comments = comments.OrderByDescending(c => c.DateCreated);
                }
                else if (comments.Key == BigBlue2.Services.NonConformances.CommentTypes.CorrectiveAction)
                {
                    CorrectiveActions = comments.OrderByDescending(c => c.DateCreated);
                }
                else if (comments.Key == BigBlue2.Services.NonConformances.CommentTypes.ImmediateActionTaken)
                {
                    ImmediateActionsTaken = comments.OrderByDescending(c => c.DateCreated);
                }
            }

            AddNotificationModel = new AddNotificationModel(nonConformance.Id, customers);
        }
    }
}