﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;
using System.Web.Mvc;
using System.Web.Security;

namespace BigBlue2.Web.Models.NonConformances
{
    public class IndexModel
    {
        public GridModel<GridItem> GridModel { get; set; }

        public SelectList Employees { get; set; }

        public SelectList Stage1Categories { get; set; }

        public SelectList Stage2Categories { get; set; }

        public SelectList Stage3Categories { get; set; }

        public SelectList Users { get; set; }

        public SelectList Customers { get; set; }

        public SelectList ProjectLocations { get; set; }

        public IndexModel(GridModel<GridItem> gridModel, IEnumerable<Employee> employees,
            IEnumerable<Stage1QPECategory> stage1Categories, IEnumerable<Stage2QPECategory> stage2Categories,
            IEnumerable<Stage3QPECategory> stage3Categories, IEnumerable<string> users, IEnumerable<Customer> customers,
            IEnumerable<ProjectLocation> projectLocations)
        {
            GridModel = gridModel;

            Employees = new SelectList(employees, "Id", "FullName");
            Stage1Categories = new SelectList(stage1Categories, "Id", "Name");
            Stage2Categories = new SelectList(stage2Categories, "Id", "Name");
            Stage3Categories = new SelectList(stage3Categories, "Id", "Name");
            Users = new SelectList(users);
            Customers = new SelectList(customers, "Id", "Name");
            ProjectLocations = new SelectList(projectLocations, "Id", "Name");
        }
    }
}