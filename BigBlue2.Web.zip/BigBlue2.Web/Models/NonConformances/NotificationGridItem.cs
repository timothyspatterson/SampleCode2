﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;
using BigBlue2.Services;

namespace BigBlue2.Web.Models.NonConformances
{
    public class NotificationGridItem
    {
        public int NotificationId { get; set; }

        public string Company { get; set; }

        public string PersonContacted { get; set; }

        public string NotifiedBy { get; set; }

        public string DateTime { get; set; }

        public NotificationGridItem(NonConformanceNotification notification)
        {
            NotificationId = notification.Id;
            Company = notification.Company;
            PersonContacted = notification.PersonContacted;
            NotifiedBy = notification.CreatedBy;
            DateTime = notification.DateNotified.To24HourDateTimeString();
        }
    }
}