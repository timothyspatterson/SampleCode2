﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;
using System.Web.Mvc;
using BigBlue2.Services;
using BigBlue2.Services.Employees;

namespace BigBlue2.Web.Models.Employees
{
    public class FormFieldsModel
    {
        private readonly SelectList _suffixes = new SelectList(new[] { "JR", "SR", "II", "III", "IV" });

        public EmployeeDto Employee { get; set; }

        public SelectList Suffixes
        {
            get
            {
                return _suffixes;
            }
        }

        public SelectList States { get; set; }

        public SelectList TankermanGroups { get; set; }

        public SelectList Departments { get; set; }

        public SelectList Locations { get; set; }

        public SelectList Companies { get; set; }

        public SelectList SubLocations { get; set; }

        public SelectList Schedules { get; set; }

        public FormFieldsModel(EmployeeDto employee, BigBlueEntities entities)
        {
            var groups = entities.TankermanGroups.Active();
            var departments = entities.Departments.Active();
            var locations = entities.ProjectLocations;
            var companies = entities.Companies;
            var subLocations = entities.SubLocations.Active();
            var schedules = entities.Schedules.Active();

            Employee = employee;
            States = new SelectList(BigBlue2.Services.States.Abbreviations);
            TankermanGroups = new SelectList(groups, "Id", "Name");
            Departments = new SelectList(departments, "Code", "Name");
            Locations = new SelectList(locations, "Id", "Name");
            Companies = new SelectList(companies, "Id", "Name");
            SubLocations = new SelectList(subLocations, "Id", "Name");
            Schedules = new SelectList(schedules, "Id", "Name");
        }
    }
}