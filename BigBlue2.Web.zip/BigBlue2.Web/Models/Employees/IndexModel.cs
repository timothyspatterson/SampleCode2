﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;
using System.Web.Mvc;

namespace BigBlue2.Web.Models.Employees
{
    public class IndexModel
    {


        public GridModel<GridItem> GridModel { get; set; }

        public SelectList TankermanGroups { get; set; }

        public SelectList Departments { get; set; }

        public class GridItem
        {
            public Guid Id { get; set; }

            public string Name { get; set; }

            public bool IsTrainee { get; set; }

            public string PermanentGroup { get; set; }

            public string Department { get; set; }

            public string Address { get; set; }

            public string City { get; set; }

            public string State { get; set; }

            public string Zip { get; set; }

            public string Phone { get; set; }

            public DateTime? TermDate { get; set; }

            public string UserName { get; set; }

            public GridItem(Employee e)
            {
                Id = e.Id;
                Address = e.EmployeeAddresses.Any() ? e.EmployeeAddresses.FirstOrDefault().Address.Address1 :
                    string.Empty;
                City = e.EmployeeAddresses.Any() ? e.EmployeeAddresses.FirstOrDefault().Address.City :
                    string.Empty;
                Department = e.Department==null ? "NONE" : e.Department.Name;
                IsTrainee = e.IsTrainee.HasValue ? e.IsTrainee.Value : false;
                Name = e.Contact.FullName;
                PermanentGroup = e.PermanentTankermanGroup==null ? "NONE" : e.PermanentTankermanGroup.Name;
                Phone = e.Contact.Phone1;
                State = e.EmployeeAddresses.Any() ? e.EmployeeAddresses.FirstOrDefault().Address.State :
                    string.Empty;
                Zip = e.EmployeeAddresses.Any() ? e.EmployeeAddresses.FirstOrDefault().Address.ZipCode :
                    string.Empty;
                TermDate = e.TermDate;

                UserName = e.UserName;
                

            }
        }
    }
}