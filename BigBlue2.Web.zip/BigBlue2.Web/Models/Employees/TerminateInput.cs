﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace BigBlue2.Web.Models.Employees
{
    public class TerminateInput
    {
        public Guid Id { get; set; }

        [Required]
        [DisplayName("date terminated")]
        public DateTime? TermDate { get; set; }

        [Required]
        [DisplayName("reason")]
        [MaxLength(2000)]
        public string TermReason { get; set; }
    }
}