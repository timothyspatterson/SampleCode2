﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;

namespace BigBlue2.Web.Models.Employees
{
    public class StatsModel
    {
        public string EmployeeName { get; set; }

        public IEnumerable<EmployeeLoadDischargeStat> Stats { get; set; }

        public int CurrentYearDlLoads { get; set; }

        public int CurrentYearLfgLoads { get; set; }

        public int CurrentYearDlDischarges { get; set; }

        public int CurrentYearLfgDischarges { get; set; }

        public int CurrentYear { get; set; }
    }
}