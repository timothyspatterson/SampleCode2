﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BigBlue2.Web.Models.Account
{
    public class Link
    {
        public Guid EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string UserFirstName { get; set; }
        public string UserLastName { get; set; }
        public string UserMiddleName { get; set; }

        public string ADUser { get; set; }
    }
}