﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using DataAnnotationsExtensions;

namespace BigBlue2.Web.Models.Account
{
    public class RegisterInput
    {
        [Required]
        [DisplayName("ssn last 4 digits")]
        [Digits]
        public string SsnLast4 { get; set; }

        [Required]
        [DisplayName("driver's license number")]
        public string DlNumber { get; set; }

        public string DlState { get; set; }
    }
}