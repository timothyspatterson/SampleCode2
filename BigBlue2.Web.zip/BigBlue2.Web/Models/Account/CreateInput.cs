﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using DataAnnotationsExtensions;

namespace BigBlue2.Web.Models.Account
{
    public class CreateInput
    {
        public Guid EmployeeId { get; set; }

        [Required]
        [DisplayName("user name")]
        [StringLength(20, MinimumLength=4)]
        public string UserName { get; set; }

        [Required]
        [DisplayName("password")]
        public string Password { get; set; }

        [EqualTo("Password")]
        [DisplayName("confirm password")]
        public string ConfirmPassword { get; set; }
    }
}