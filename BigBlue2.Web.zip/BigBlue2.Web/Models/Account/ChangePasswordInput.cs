﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace BigBlue2.Web.Models.Account
{
    public class ChangePasswordInput : IValidatableObject
    {
        [Required]
        [DisplayName("current password")]
        public string CurrentPassword { get; set; }

        [Required]
        [DisplayName("new password")]
        public string NewPassword { get; set; }

        [Required]
        [DisplayName("confirm new password")]
        public string ConfirmNewPassword { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (NewPassword != ConfirmNewPassword)
            {
                yield return new ValidationResult("New password and confirm password must match.", new[] { "ConfirmPassword" });
            }
        }
    }
}