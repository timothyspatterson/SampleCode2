﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Data;
using System.Web.Helpers;

namespace BigBlue2.Web.Models
{
    public class GridModel<T> where T : class
    {
        public int PageSize { get; set; }

        public IEnumerable<T> GridItems { get; set; }

        public string Sort { get; set; }

        public string SortDir { get; set; }

        public GridModel(IEnumerable<T> items, int pageSize, string sort, string sortDir)
        {
            GridItems = items;

            PageSize = pageSize;

            Sort = sort;

            SortDir = sortDir;
        }
    }
}