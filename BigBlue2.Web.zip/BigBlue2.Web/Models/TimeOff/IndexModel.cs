﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BigBlue2.Data;
using System.ComponentModel.DataAnnotations;

namespace BigBlue2.Web.Models.TimeOff
{

    public class IndexModel
    {
        public GridModel<GridItem> GridModel { get; set; }
        public SelectList Employees { get; set; }
        public DateTime FilterStartDate { get; set; }
        public DateTime FilterEndDate { get; set; }

        public class GridItem
        {
            public int Id { get; set; }
            public Guid RowId { get; set; }
            public string VacationNo { get; set; }
            public string EmployeeName { get; set; }
            public DateTime EntryDate { get; set; }
            public DateTime StartDate { get; set; }
            public DateTime EndDate { get; set; }
            public int TotalDays { get; set; }
            public string ApprovedBy { get; set; }
            public string UpdatedUser { get; set; }
            public DateTime UpdatedOn { get; set; }

            public GridItem(BigBlue2.Data.EmployeeTimeOff t)
            {
                Id = t.vacation_id;
                RowId = t.row_id;
                VacationNo = "VACT-" + t.vacation_id.ToString();
                EmployeeName = t.employee_fullname;
                EntryDate = t.entry_dt;
                StartDate = t.start_dt;
                EndDate = t.end_dt;
                TotalDays = t.total_days;
                ApprovedBy = t.approved_by;
                UpdatedOn = t.update_dt.Value;
                UpdatedUser = t.update_user;
            }
        }

    }

    public class VacationEntry
    {
        public SelectList Employees { get; set; }

        public string VacationNo { get; set; }
        public string EmployeeName { get; set; }
        public Guid EmployeeId { get; set; }
        public DateTime EntryDate { get; set; }
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString="{0:MM/dd/yyyy}")]
        public DateTime StartDate { get; set; }
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString="{0:MM/dd/yyyy}")]
        public DateTime EndDate { get; set; }
        public int TotalDays { get; set; }
        public int HoursPerDay { get; set; }
        public string ApprovedBy { get; set; }
        public string UpdatedUser { get; set; }
        public DateTime UpdatedOn { get; set; }


    }

}