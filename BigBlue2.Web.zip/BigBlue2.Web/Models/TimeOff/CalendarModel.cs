﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BigBlue2.Web.Models.TimeOff
{
    public class CalendarModel
    {
        public DateTime FilterStartDate { get; set; }
        public DateTime FilterEndDate { get; set; }
        public List<CalendarDayModel> CalendarDays { get; set; }
        public List<string> GroupingLists
        {
            get
            {
                List<string> groups = new List<string>();

                foreach (CalendarDayModel cm in CalendarDays)
                {
                    foreach (string group in cm.GroupingLists)
                    {
                        if (!groups.Contains(group)) groups.Add(group);
                    }
                }
                groups.Sort();
                return groups;
            }
        }
        public CalendarModel() { CalendarDays = new List<CalendarDayModel>(); }

    }

    public class CalendarDayModel
    {
        public DateTime EffectiveDate { get; set; }
        public string DayName { get; set; }
        public List<EmployeeDayEvent> EmployeeDays { get; set; }
        public List<string> GroupingLists { get; set; }
        public CalendarDayModel() { EmployeeDays = new List<EmployeeDayEvent>(); GroupingLists = new List<string>(); }
    }

    public class EmployeeDayEvent
    {
        public string PermGroup { get; set; }
        public string DisplayGrouping1 
        {
            get { return PermGroup; }
        }

        public Guid EmployeeRowId { get; set; }
        public string Name { get; set; }
        public string EventDesc { get; set; }
        public string EventCode { get; set; }

        // using 1, 2, 3 for generic purposes.
        public string Info1 { get; set; }
        public string Info2 { get; set; }
        public string Info3 { get; set; }
        public string InfoId { get; set; }
        public string InfoComments { get; set; }
    }

}