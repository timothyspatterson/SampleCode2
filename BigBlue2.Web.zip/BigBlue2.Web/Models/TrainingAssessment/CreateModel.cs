﻿using BigBlue2.Data;
using BigBlue2.Web.Models.Projects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BigBlue2.Web.Models.TrainingAssement
{
    public class CreateModel
    {
        public SelectList Employees { get; private set; }

        public SelectList Projects { get; private set; }

        public ProjectInfoModel ProjectInfo { get; private set; }

        public CreateModel(IEnumerable<EmployeeSummary> employees)
            : this(employees, null, null)
        {
        }

        public CreateModel(IEnumerable<EmployeeSummary> employees, IEnumerable<Project> projects, ProjectSummary project)
        {
            Employees = new SelectList(employees, "Id", "FullName");

            if (projects != null)
            {
                Projects = new SelectList(projects, "No", "Name");
            }

            if (project != null)
            {
                ProjectInfo = new ProjectInfoModel()
                {
                    Barge = project.BargeName,
                    Facility = project.Facility,
                    Operation = project.Operation
                };
            }
        }
    }
}