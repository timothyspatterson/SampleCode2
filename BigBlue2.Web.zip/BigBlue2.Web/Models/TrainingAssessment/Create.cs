﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BigBlue2.Web.Models.TrainingAssement
{
    public class LookUps
    {
        public static IEnumerable<SelectListItem> traineeList { get; set; }
        public static IEnumerable<SelectListItem> trainer { get; set; }
        public static IEnumerable<SelectListItem> barge { get; set; }
        public static IEnumerable<SelectListItem> product { get; set; }
    }

    public class assset_rating
    {
        public string rating { get; set; }
        public string comments { get; set; }
    }

    public class Create
    {

        public BigBlue2.Data.Employee trainee { get; set; }
        public System.DateTime reviewDate { get; set; }
        public BigBlue2.Data.Employee trainer { get; set; }
        public List<BigBlue2.Data.Barge> bargeList { get; set; }
        public BigBlue2.Data.Employee barge { get; set; }
        public string facility { get; set; }
        public BigBlue2.Data.Employee product { get; set; }

        public string load { get; set; }
        public string single { get; set; }
        public string open { get; set; }
        public string subo { get; set; }
        public string straight { get; set; }
        public string dl { get; set; }
        public string discharge { get; set; }
        public string doubleup { get; set; }
        public string closed { get; set; }
        public string subd { get; set; }
        public string split { get; set; }
        public string lg { get; set; }
        public string professionalism { get; set; }
        public string work_ethic { get; set; }
        public string preparedness { get; set; }
        public string punctual { get; set; }

        public assset_rating safety { get; set; }
        public assset_rating PPE { get; set; }
        public assset_rating FIR { get; set; }
        public assset_rating BIR { get; set; }
        public assset_rating Mooring { get; set; }
        public assset_rating connection { get; set; }
        public assset_rating pretransfer { get; set; }
        public assset_rating alignmentstartup { get; set; }
        public assset_rating midtransfer { get; set; }
        public assset_rating finishShutdown { get; set; }
        public assset_rating lineCleaning { get; set; }
        public assset_rating disconnection { get; set; }
        public assset_rating makeReady { get; set; }

        public string skillLevel { get; set; }
        public string knowledge { get; set; }
        public string retention { get; set; }

    }
}