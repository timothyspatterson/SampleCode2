﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BigBlue2.Services;
using System.ComponentModel.DataAnnotations;

namespace BigBlue2.Web.Models.TrainingAssessment
{
    public class CreateInput
    {
        public DateTime ReviewDate { get; set; }

        public DateTime ReviewTime { get; set; }

        public DateTime DateOfReview
        {
            get
            {
                return ReviewDate.Date.Add(ReviewTime.TimeOfDay);
            }
        }

        public Guid TraineeEmployeeId { get; set; }
        public Guid TrainerEmployeeId { get; set; }

        public string ProjectNo { get; set; }

        [Required(ErrorMessage = "Load/Discharge answer is required")]
        public int? LoadDischarge { get; set; }

        [Required(ErrorMessage = "Open/Close answer is required")]
        public int? OpenClose { get; set; }

        [Required(ErrorMessage = "Single/Double answer is required")]
        public int? SingleDouble { get; set; }

        [Required(ErrorMessage = "Sub O/Sub D answer is required")]
        public int? SubOSubD { get; set; }

        [Required(ErrorMessage = "Split/Straight answer is required")]
        public int? SplitStraight { get; set; }

        [Required(ErrorMessage = "LG/DL answer is required")]
        public int? LGDL { get; set; }

        [Required(ErrorMessage = "Professionalism answer is required")]
        public SatNIU? Professionalism { get; set; }

        [Required(ErrorMessage = "Work Ethic answer is required")]
        public SatNIU? WorkEthic { get; set; }

        [Required(ErrorMessage = "Preparedness answer is required")]
        public SatNIU? Preparedness { get; set; }

        [Required(ErrorMessage = "Punctual answer is required")]
        public SatNIU? Punctual { get; set; }

        [Required(ErrorMessage = "Safety answer is required")]
        public SatNIU? Safety { get; set; }

        public string SafetyComments { get; set; }

        [Required(ErrorMessage = "PPE answer is required")]
        public SatNIU? PPE { get; set; }

        public string PPEComments { get; set; }

        [Required(ErrorMessage = "FIR answer is required")]
        public SatNIU? FIR { get; set; }

        public string FIRComments { get; set; }

        [Required(ErrorMessage = "BIR answer is required")]
        public SatNIU? BIR { get; set; }

        public string BIRComments { get; set; }

        [Required(ErrorMessage = "Mooring answer is required")]
        public SatNIU? Mooring { get; set; }

        public string MooringComments { get; set; }

        [Required(ErrorMessage = "Connection answer is required")]
        public SatNIU? Connection { get; set; }

        public string ConnectionComments { get; set; }

        [Required(ErrorMessage = "PreTransfer answer is required")]
        public SatNIU? PreTransfer { get; set; }

        public string PreTransferComments { get; set; }

        [Required(ErrorMessage = "Alignment Start Up answer is required")]
        public SatNIU? AlignmentStartUp { get; set; }

        public string AlignmentStartUpComments { get; set; }

        [Required(ErrorMessage = "MidTransfer Start Up answer is required")]
        public SatNIU? MidTransfer { get; set; }

        public string MidTransferComments { get; set; }

        [Required(ErrorMessage = "Finish Shutdown  Start Up answer is required")]
        public SatNIU? FinishShutdown { get; set; }

        public string FinishShutdownComments { get; set; }

        [Required(ErrorMessage = "Line Clearing  Start Up answer is required")]
        public SatNIU? LineClearing { get; set; }

        public string LineClearingComments { get; set; }

        [Required(ErrorMessage = "Disconnection  Start Up answer is required")]
        public SatNIU? Disconnection { get; set; }

        public string DisconnectionComments { get; set; }

        [Required(ErrorMessage = "Make Ready Start Up answer is required")]
        public SatNIU? MakeReady { get; set; }

        public string MakeReadyComments { get; set; }

        public string SkillLevel { get; set; }

        public string Knowledge { get; set; }

        public string Retention { get; set; }
    }
}